shader_type spatial;
render_mode unshaded, cull_back;

// Self-lit cartoon shading with a "small planet" curve. Light comes from a
// fixed direction in view space, so the look is identical on every device.

uniform vec4 albedo : source_color = vec4(1.0);
uniform float shade_strength = 0.36;

const float CURVE = 0.0010;
const float START = 12.0;
const vec3 L = vec3(-0.45, 0.75, 0.48);

void vertex() {
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	float nl = dot(normalize(NORMAL), normalize(L));
	float lit = smoothstep(-0.2, 0.5, nl);
	vec3 base = albedo.rgb * (1.0 - shade_strength + shade_strength * 1.35 * lit);
	vec3 warm = base * vec3(1.07, 1.03, 0.95);
	vec3 cool = base * vec3(0.85, 0.9, 1.08);
	ALBEDO = clamp(mix(cool, warm, lit), 0.0, 1.0);
}
