# Bicycle Rush (साइकिल रश)

2-player co-op Android TV endless runner, Indian village theme, Hindi banter.
Phones are the controllers (same Wi-Fi): open the address shown on the TV in the phone browser.

Build: push this repo to GitHub, open Actions > "Build APK" > Run workflow, download artifact `bicycle-rush-apk`.
Test on PC: arrows = P1, WASD = P2, P = pause, Q = quality.
Phone: swipe left/right = lane, up = jump, down = slide.

Animal models (cow, horse, pig, pug, sheep): "Farm Animals Pack" by Quaternius, CC0 (see models/License.txt).

Vehicle models (bus, trucks, cars, autos, bikes): "Bus Simulator India - Traffic Cars" by Villanueva-Jonatan-32621, CC BY 4.0, https://sketchfab.com/3d-models/bus-simulator-india-traffic-cars-a0c72a6277bf4301bb3e5db4ccb194b6 (see models/vehicles/license.txt). Tata truck: decimated from the supplied OBJ.

Road and ground textures: "Hiden Road Diorama" by Toni García Vilche, CC BY 4.0, https://sketchfab.com/3d-models/hiden-road-diorama-ffdfb06b044844848b26b733dfada25f (see textures/license_road_diorama.txt).

Buildings (decimated/rescaled, textures resized; see models/buildings/licenses.txt):
- Bhelpuri Shop by AJ_AY, CC BY 4.0
- Ganesha 3D by lucas.rvdl, CC BY 4.0
- Indian House Old by bhagathartworks, CC BY 4.0
- Under Construction Indian House by nayan pachori, CC BY 4.0
- Indian Community Cleanliness Complex by nayan pachori, CC BY-NC-ND 4.0 (non-commercial, no derivatives!). Set USE_COMPLEX := false in scripts/bldg.gd and delete models/buildings/complex.glb to remove it.
- Indian House with tank by Ace.Rich, Sketchfab Standard licence (do not publish the model file in a public repo).

Trees, bicycle and saree lady (decimated; all CC BY 4.0, credits in models/buildings/licenses.txt):
- Tree low poly lowpoly by 00amza; Fantasy Tree by Šimon Ustal; Mango Tree by stealth86; Low poly Coconut Palm Tree by iGauravRajput; Old Bicycle by Tidominer; Pink saree lady 3d model by dk8026854
