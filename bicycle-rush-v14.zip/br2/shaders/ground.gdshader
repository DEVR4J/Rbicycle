shader_type spatial;
render_mode unshaded, cull_back;

// Gravel shoulder in the middle, grass to both sides (one texture, the grass
// edge columns are mirrored outwards), scrolling with the road.

uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_enable;
uniform float scroll = 0.0;
uniform float tile_len = 39.0;
uniform float centre_u = 0.46;
uniform float grass_band = 0.11;

const float CURVE = 0.00012;
const float START = 12.0;

varying vec2 wp;

void vertex() {
	wp = VERTEX.xz;
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	float u = centre_u + wp.x / tile_len;
	float uu = u;
	if (u > 1.0) {
		float t = u - 1.0;
		float tri = grass_band - abs(mod(t, grass_band * 2.0) - grass_band);
		uu = 1.0 - tri;
	} else if (u < 0.0) {
		float t = -u;
		float tri = grass_band - abs(mod(t, grass_band * 2.0) - grass_band);
		uu = tri;
	}
	float v = (wp.y - scroll) / tile_len;
	float fv = abs(fract(v * 0.5) * 2.0 - 1.0);
	vec2 dx = vec2(dFdx(uu), dFdx(v));
	vec2 dy = vec2(dFdy(uu), dFdy(v));
	vec3 c = textureGrad(tex, vec2(uu, fv), dx, dy).rgb;
	ALBEDO = clamp(c * 1.08, 0.0, 1.0);
}
