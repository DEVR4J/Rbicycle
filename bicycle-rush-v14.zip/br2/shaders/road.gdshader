shader_type spatial;
render_mode unshaded, cull_back;

// Worn asphalt with gravel patches and faded lines. The texture scrolls with
// the distance travelled (mirrored along the road so it never shows a seam).

uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_enable;
uniform float scroll = 0.0;
uniform float tile_len = 16.0;
uniform float half_width = 6.75;
uniform float bright = 1.25;

const float CURVE = 0.00012;
const float START = 12.0;

varying vec2 wp;

void vertex() {
	wp = VERTEX.xz;
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	float u = clamp((wp.x + half_width) / (half_width * 2.0), 0.0, 1.0);
	float v = (wp.y - scroll) / tile_len;
	float fv = abs(fract(v * 0.5) * 2.0 - 1.0);
	vec2 dx = vec2(dFdx(u), dFdx(v));
	vec2 dy = vec2(dFdy(u), dFdy(v));
	vec3 c = textureGrad(tex, vec2(u, fv), dx, dy).rgb;
	ALBEDO = clamp(c * bright, 0.0, 1.0);
}
