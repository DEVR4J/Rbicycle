shader_type spatial;
render_mode unshaded, cull_disabled;

// Textured vehicle body: same fixed-light toon look and world curve as the rest.

uniform sampler2D tex : source_color, hint_default_white, filter_linear_mipmap, repeat_enable;
uniform vec4 tint : source_color = vec4(1.0);
uniform float cut = 0.0;

const float CURVE = 0.00012;
const float START = 12.0;
const vec3 L = vec3(-0.45, 0.75, 0.48);

void vertex() {
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	vec3 n = normalize(NORMAL);
	if (!FRONT_FACING) {
		n = -n;
	}
	float lit = smoothstep(-0.35, 0.75, dot(n, normalize(L)));
	float wy = (INV_VIEW_MATRIX * vec4(n, 0.0)).y;
	float bounce = 0.82 + 0.18 * clamp(wy * 0.5 + 0.5, 0.0, 1.0);
	vec4 tx = texture(tex, UV);
	if (tx.a < cut) {
		discard;
	}
	vec3 base = tx.rgb * tint.rgb;
	vec3 col = base * (0.62 + 0.62 * lit) * bounce;
	vec3 r = reflect(-normalize(L), n);
	col += vec3(pow(max(dot(r, normalize(VIEW)), 0.0), 18.0) * 0.08);
	ALBEDO = clamp(col, 0.0, 1.0);
}
