extends RefCounted
## Textured 3D buildings (baked offline into models/buildings/*.glb): every
## model is already centred, standing on y = 0 and facing +Z, so it drops
## straight into the scenery. Missing files return null and callers fall back
## to the hand-built houses.

const Art := preload("res://scripts/art.gd")
const DIR := "res://models/buildings/"

## The cleanliness-complex model is CC BY-NC-ND 4.0 (non-commercial, no
## derivatives). Set this to false to drop it from the game entirely.
const USE_COMPLEX := true

static var _lib: Dictionary = {}


static func _tpl(bname: String, line: bool) -> Node3D:
	var key := bname + ("L" if line else "N")
	if _lib.has(key):
		return _lib[key] as Node3D
	var res: Node3D = null
	var path := DIR + bname + ".glb"
	if ResourceLoader.exists(path):
		var scn: PackedScene = load(path) as PackedScene
		if scn != null:
			res = scn.instantiate() as Node3D
			if res != null:
				for mv in res.find_children("*", "MeshInstance3D", true, false):
					var mi: MeshInstance3D = mv
					if mi.mesh == null:
						continue
					mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
					for si in range(mi.mesh.get_surface_count()):
						var sm: Material = mi.mesh.surface_get_material(si)
						var tex: Texture2D = null
						var tint := Color.WHITE
						var cut := 0.0
						if sm is BaseMaterial3D:
							var bm: BaseMaterial3D = sm
							tex = bm.albedo_texture
							tint = bm.albedo_color
							if bm.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR:
								cut = 0.5
						mi.set_surface_override_material(si, Art.veh_mat(tex, tint, cut, line))
	_lib[key] = res
	return res


## One instance of baked model `bname`, uniformly scaled by `sc`.
static func make(bname: String, sc: float = 1.0, line: bool = false) -> Node3D:
	var t: Node3D = _tpl(bname, line)
	if t == null:
		return null
	var n := Node3D.new()
	var d: Node3D = t.duplicate() as Node3D
	d.scale = Vector3.ONE * sc
	n.add_child(d)
	return n


## A random building for scenery key `key` (house/storey/haveli/shed/hut).
static func pick(key: String) -> Node3D:
	var opts: Array
	match key:
		"storey":
			opts = ["house_tank", "house_build", "house_tank"]
		"haveli":
			opts = ["complex", "house_tank", "house_old"] if USE_COMPLEX else ["house_tank", "house_old"]
		"shed":
			opts = ["house_build", "house_old"]
		"hut":
			opts = ["house_old"]
		_:
			opts = ["house_old", "house_old", "house_tank", "house_build", "complex", "house_old"] if USE_COMPLEX else ["house_old", "house_old", "house_tank", "house_build", "house_old"]
	var bname: String = opts[randi() % opts.size()]
	var sc := 1.0
	if key == "hut":
		sc = 0.85
	return make(bname, sc)


static func bhelpuri() -> Node3D:
	return make("bhelpuri", 1.0, true)


## The giant Ganesha statue (1.0 tall in the file; scale to taste).
static func ganesha(sc: float) -> Node3D:
	return make("ganesha", sc, false)
