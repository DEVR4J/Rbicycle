extends Node3D
## Bicycle Rush: two riders on one shared four-lane village road.
## Phones are the controllers (see phone_server.gd). Everything is built in code.

const Art := preload("res://scripts/art.gd")
const Props := preload("res://scripts/props.gd")
const Scenery := preload("res://scripts/scenery.gd")
const Signs := preload("res://scripts/signs.gd")
const FX := preload("res://scripts/fx.gd")
const UI := preload("res://scripts/ui.gd")
const PhoneServer := preload("res://scripts/phone_server.gd")
const Commentary := preload("res://scripts/commentary.gd")

const LANES := [-4.5, -1.5, 1.5, 4.5]
const SPAWN_Z := -85.0
const DESPAWN_Z := 18.0
const START_SPEED := 15.0
const MAX_SPEED := 32.0
const LOBBY_SPEED := 7.0
const GRAVITY := 30.0
const JUMP_V := 10.5
const SLIDE_TIME := 0.8
const START_LIVES := 3
const MAX_LIVES := 3
const BOOST_TIME := 5.0
const SHIELD_TIME := 12.0
const CAM_POS := Vector3(0.0, 5.4, 12.0)
const CAM_TARGET := Vector3(0.0, 2.3, -14.0)
const SETTINGS_PATH := "user://settings.cfg"

const GRASS := Color("#6DB65A")
const ROAD := Color("#8D8B94")
const ROAD_EDGE := Color("#C9A26C")

const MISSIONS := [
	{"id": "coins", "fmt": "%d सिक्के इकट्ठा करो", "goal": 50, "reward": 300},
	{"id": "shield", "fmt": "%d ढाल उठाओ", "goal": 2, "reward": 250},
	{"id": "boost", "fmt": "%d चाय बूस्ट उठाओ", "goal": 1, "reward": 250},
	{"id": "survive", "fmt": "%d सेकंड टिके रहो", "goal": 75, "reward": 400},
	{"id": "jump", "fmt": "%d बार कूदो", "goal": 12, "reward": 200},
	{"id": "slide", "fmt": "%d बार झुको", "goal": 5, "reward": 250},
]

enum State { LOBBY, COUNTDOWN, PLAYING, GAMEOVER }


class Rider:
	var idx := 0
	var root: Node3D
	var parts: Dictionary = {}
	var wheels: Array = []
	var dust: CPUParticles3D
	var stars: Node3D
	var lane := 0
	var y := 0.0
	var vy := 0.0
	var slide_t := 0.0
	var stun := 0.0
	var inv := 0.0
	var shield_t := 0.0
	var look_back := 0.0
	var phase := 0.0
	var squash := 0.0
	var coins := 0
	var crashes := 0
	var connected := false
	var joined := false
	var taunt_cd := 0.0
	var mood := ""


var state: int = State.LOBBY
var paused := false
var speed := LOBBY_SPEED
var world_dist := 0.0
var next_chunk := 42.0
var monument_at := 1.0e12
var next_dash := 0.0
var road_mat: ShaderMaterial
var ground_mat: ShaderMaterial
var next_row := 0.0
var play_time := 0.0
var score_f := 0.0
var coins_total := 0
var multiplier := 1
var lives := START_LIVES
var boost_t := 0.0
var safe_lane := 1
var shake := 0.0
var time_now := 0.0
var speech_cd := 0.0
var lead_cd := 0.0
var over_t := 0.0
var count_t := 0.0
var count_shown := 4
var hud_t := 0.0
var last_crash_time := -10.0
var scenery_prev := ""
var back_ms := 0
var quality := "high"

var riders: Array = []
var movers: Array = []
var clouds: Array = []
var missions: Array = []
var world: Node3D
var cam: Camera3D
var server: Node
var cmt = Commentary.new()
var hud = null
var font: Font



# ================================================================ setup

func _ready() -> void:
	randomize()
	font = _load_font()
	Art.font = font
	_load_settings()
	_apply_quality()
	world = Node3D.new()
	add_child(world)
	_build_environment()
	Signs.build(self, font)
	_build_ground()
	_build_riders()
	hud = UI.new()
	hud.build(self, font)
	server = PhoneServer.new()
	add_child(server)
	server.player_message.connect(_on_player_message)
	server.slot_changed.connect(_on_slot_changed)
	if not server.start():
		push_warning("Phone server could not start. Phones will not be able to join.")
	_fill_scenery()
	_fill_dashes()
	_roll_missions()
	_update_hud()
	_refresh_overlay()


func _load_font() -> Font:
	var base: Font = ThemeDB.fallback_font
	if ResourceLoader.exists("res://fonts/hindi.ttf"):
		var f := load("res://fonts/hindi.ttf") as Font
		if f != null:
			var fv := FontVariation.new()
			fv.base_font = f
			fv.fallbacks = [base]
			return fv
	push_warning("res://fonts/hindi.ttf is missing, so Hindi text will not render.")
	return base


func _load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		quality = str(cf.get_value("game", "quality", "high"))
	elif OS.get_processor_count() < 4:
		quality = "low"


func _save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("game", "quality", quality)
	cf.save(SETTINGS_PATH)


func _apply_quality() -> void:
	var high: bool = quality == "high"
	Art.outlines = high
	Scenery.density = 1.0 if high else 0.55


func _build_environment() -> void:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("#2F8CFF")
	sky_mat.sky_horizon_color = Color("#CDEEFF")
	sky_mat.ground_horizon_color = Color("#CDEEFF")
	sky_mat.ground_bottom_color = Color("#BFE8D0")
	sky_mat.sky_curve = 0.18
	sky_mat.sun_angle_max = 30.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color.WHITE
	env.fog_enabled = true
	env.set("fog_mode", 1)
	env.fog_light_color = Color("#CDEEFF")
	env.set("fog_depth_begin", 75.0)
	env.set("fog_depth_end", 175.0)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-26.0, 180.0, 0.0)
	sun.light_energy = 1.0
	sun.shadow_enabled = false
	add_child(sun)
	cam = Camera3D.new()
	cam.fov = 58.0
	cam.near = 0.3
	cam.far = 260.0
	add_child(cam)
	cam.look_at_from_position(CAM_POS, CAM_TARGET, Vector3.UP)
	for i in range(8):
		var c := Node3D.new()
		for k in range(4):
			var m := MeshInstance3D.new()
			m.mesh = Art.sph(randf_range(3.0, 5.0), 8)
			m.material_override = Art.mat(Color.WHITE)
			m.position = Vector3(float(k) * 4.0 - 6.0, randf_range(-0.6, 0.8), randf_range(-1.0, 1.0))
			m.scale = Vector3(1.3, 0.7, 1.0)
			m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			c.add_child(m)
		c.position = Vector3(randf_range(-90.0, 90.0), randf_range(26.0, 38.0), randf_range(-170.0, -60.0))
		add_child(c)
		clouds.append(c)


func _build_ground() -> void:
	var g := PlaneMesh.new()
	g.size = Vector2(120.0, 260.0)
	g.subdivide_width = 2
	g.subdivide_depth = 120
	var gi := MeshInstance3D.new()
	gi.mesh = g
	ground_mat = ShaderMaterial.new()
	ground_mat.shader = preload("res://shaders/ground.gdshader")
	ground_mat.set_shader_parameter("tex", preload("res://textures/ground.png"))
	gi.material_override = ground_mat
	gi.position = Vector3(0.0, 0.0, -115.0)
	gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(gi)
	var r := PlaneMesh.new()
	r.size = Vector2(13.5, 260.0)
	r.subdivide_width = 1
	r.subdivide_depth = 120
	var ri := MeshInstance3D.new()
	ri.mesh = r
	road_mat = ShaderMaterial.new()
	road_mat.shader = preload("res://shaders/road.gdshader")
	road_mat.set_shader_parameter("tex", preload("res://textures/road.png"))
	ri.material_override = road_mat
	ri.position = Vector3(0.0, 0.02, -115.0)
	ri.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ri)


func _build_riders() -> void:
	var cfgs := [
		{"female": true, "shirt": Color("#FF5C93"), "pants": Color("#6B3FD1"), "frame": Color("#FF8A2B"), "skin": Color("#C98B5E"), "accent": Color("#FFCB2F")},
		{"female": false, "shirt": Color("#2E86FF"), "pants": Color("#F4F4F4"), "frame": Color("#18C4B8"), "skin": Color("#B9794F"), "accent": Color("#FF8A2B")},
	]
	var tags := [Color("#FF5C93"), Color("#3E7BFA")]
	for i in range(2):
		var r := Rider.new()
		r.idx = i
		r.lane = 1 + i
		r.parts = Art.make_rider(cfgs[i])
		r.root = r.parts["root"]
		r.wheels = r.parts["wheels"]
		r.root.position = Vector3(float(LANES[r.lane]), 0.0, 0.0)
		r.root.visible = false
		add_child(r.root)
		var tag := Label3D.new()
		tag.text = "P%d" % (i + 1)
		tag.font = font
		tag.font_size = 96
		tag.pixel_size = 0.012
		tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		tag.no_depth_test = true
		tag.modulate = tags[i]
		tag.outline_size = 18
		tag.outline_modulate = Art.INK
		tag.position = Vector3(0.0, 5.9, 0.0)
		r.root.add_child(tag)
		r.stars = FX.make_stars(Art.mat(Art.C_YELLOW))
		r.stars.position = Vector3(0.0, 4.9, 0.0)
		r.root.add_child(r.stars)
		var d := CPUParticles3D.new()
		var dm := SphereMesh.new()
		dm.radius = 0.2
		dm.height = 0.4
		dm.radial_segments = 6
		dm.rings = 3
		var dmat := StandardMaterial3D.new()
		dmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		dmat.albedo_color = Color(0.92, 0.78, 0.58, 0.8)
		dmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		dm.material = dmat
		d.mesh = dm
		d.amount = 14
		d.lifetime = 0.6
		d.direction = Vector3(0, 0.5, 1)
		d.spread = 30.0
		d.initial_velocity_min = 3.0
		d.initial_velocity_max = 6.0
		d.gravity = Vector3(0, -1.0, 6.0)
		d.scale_amount_min = 0.5
		d.scale_amount_max = 1.2
		d.position = Vector3(0, 0.2, 1.5)
		d.emitting = false
		r.root.add_child(d)
		r.dust = d
		riders.append(r)


func _fill_scenery() -> void:
	for k in range(4):
		var kind: String = Scenery.next_kind(scenery_prev) if k > 0 else "village"
		scenery_prev = kind
		_spawn_chunk(kind, SPAWN_Z - Scenery.CHUNK_LEN * 0.5 + float(3 - k) * Scenery.CHUNK_LEN)
	next_chunk = world_dist + Scenery.CHUNK_LEN


func _spawn_chunk(kind: String, z: float) -> void:
	var c := Scenery.build_chunk(kind)
	c.position = Vector3(0, 0, z)
	world.add_child(c)
	movers.append(c)


func _clear_scenery() -> void:
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		if str(n.get_meta("kind", "")) == "scenery":
			movers.remove_at(i)
			n.queue_free()


func _make_dash() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.box(Vector3(0.2, 0.03, 2.4)), Color("#FFF1CF"), Vector3(0, 0.05, 0), Vector3.ZERO, false)
	n.set_meta("kind", "dash")
	return n


func _fill_dashes() -> void:
	var z := SPAWN_Z
	while z < 16.0:
		_spawn_dash(z)
		z += 6.0
	next_dash = world_dist + 6.0


func _spawn_dash(z: float) -> void:
	for x in [-3.0, 3.0]:
		var d := _make_dash()
		d.position = Vector3(float(x), 0.0, z)
		world.add_child(d)
		movers.append(d)


# ================================================================ input

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_back()


func _back() -> void:
	var now: int = Time.get_ticks_msec()
	if now - back_ms < 300:
		return
	back_ms = now
	if state == State.LOBBY:
		get_tree().quit()
	elif state == State.GAMEOVER:
		_to_lobby()
	else:
		_set_paused(not paused)


func _unhandled_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k != null and k.pressed and not k.echo:
		match k.keycode:
			KEY_A:
				_local_input(1, "l")
			KEY_D:
				_local_input(1, "r")
			KEY_W:
				_local_input(1, "u")
			KEY_S:
				_local_input(1, "d")
			KEY_P:
				_set_paused(not paused)
			KEY_Q:
				_set_quality("low" if quality == "high" else "high")
	if event.is_action_pressed("ui_cancel"):
		_back()
	elif event.is_action_pressed("ui_left"):
		_local_input(0, "l")
	elif event.is_action_pressed("ui_right"):
		_local_input(0, "r")
	elif event.is_action_pressed("ui_up"):
		_local_input(0, "u")
	elif event.is_action_pressed("ui_down"):
		_local_input(0, "d")
	elif event.is_action_pressed("ui_accept"):
		if paused:
			_set_paused(false)
		else:
			_try_start(true)


func _local_input(i: int, d: String) -> void:
	var r: Rider = riders[i]
	if not r.joined:
		r.joined = true
		r.connected = true
		r.root.visible = true
		_refresh_overlay()
		return
	_apply_input(r, d)


func _on_player_message(slot: int, msg: Dictionary) -> void:
	var t: String = str(msg.get("t", ""))
	if t == "swipe":
		_apply_input(riders[slot], str(msg.get("d", "")))
	elif t == "taunt":
		_taunt(slot)
	elif t == "start":
		if paused:
			_set_paused(false)
		else:
			_try_start(false)
	elif t == "pause":
		if state == State.PLAYING or state == State.COUNTDOWN:
			_set_paused(not paused)
	elif t == "quality":
		_set_quality(str(msg.get("v", "high")))


func _on_slot_changed(slot: int, online: bool) -> void:
	var r: Rider = riders[slot]
	r.connected = online
	if online:
		r.joined = true
		r.root.visible = true
		r.look_back = 1.4
		say("join", [slot + 1])
		server.send_to(slot, {"t": "vibe", "ms": 80})
	_refresh_overlay()
	_update_hud()


func _apply_input(r: Rider, d: String) -> void:
	if state == State.GAMEOVER or paused or r.stun > 0.0:
		return
	match d:
		"l":
			r.lane = maxi(0, r.lane - 1)
		"r":
			r.lane = mini(3, r.lane + 1)
		"u":
			if r.y <= 0.02 and r.vy == 0.0:
				r.vy = JUMP_V
				r.slide_t = 0.0
				r.squash = 0.18
				_mission_add("jump", 1.0)
				FX.dust(world, r.root.position + Vector3(0, 0.3, 0.6))
				if randf() < 0.25:
					FX.popup(world, r.root.position + Vector3(0, 5.0, 0), cmt.word("jump"), Color("#FFFFFF"), font, 56, 1.4)
		"d":
			if r.y > 0.05:
				r.vy = minf(r.vy, -18.0)
			elif r.slide_t <= 0.0:
				r.slide_t = SLIDE_TIME
				_mission_add("slide", 1.0)
				FX.dust(world, r.root.position + Vector3(0, 0.3, 0.6))


func _taunt(slot: int) -> void:
	var r: Rider = riders[slot]
	if r.taunt_cd > 0.0 or state != State.PLAYING:
		return
	r.taunt_cd = 6.0
	var target: int = 1 - slot
	var line: String = (cmt.pick("taunt") as String) % [target + 1]
	hud.speech(line)
	speech_cd = 4.5
	r.look_back = 1.0
	server.send_to(target, {"t": "msg", "text": line})
	server.send_to(target, {"t": "vibe", "ms": 120})


func _try_start(from_tv: bool) -> void:
	if state == State.LOBBY:
		var any := false
		for r in riders:
			if r.joined:
				any = true
		if not any:
			if from_tv:
				_local_input(0, "")
			else:
				return
		_start_game()
	elif state == State.GAMEOVER and over_t <= 0.0:
		_start_game()


func _set_paused(p: bool) -> void:
	if state != State.PLAYING and state != State.COUNTDOWN:
		return
	paused = p
	if p:
		hud.show_overlay("रुका हुआ", _missions_text(), "OK दबाओ: जारी रखो   |   Back: फिर रोको", Color("#7B4FC4"))
	else:
		hud.hide_overlay()


func _set_quality(q: String) -> void:
	if q != "low" and q != "high":
		return
	if q == quality:
		return
	quality = q
	_save_settings()
	_apply_quality()
	_clear_scenery()
	scenery_prev = ""
	_fill_scenery()
	hud.toast("क्वालिटी: ज़्यादा" if q == "high" else "क्वालिटी: कम (तेज़)", Color("#7B4FC4"))
	_refresh_overlay()


# ================================================================ game flow

func _roll_missions() -> void:
	var pool: Array = MISSIONS.duplicate()
	pool.shuffle()
	missions = []
	for i in range(3):
		var m: Dictionary = (pool[i] as Dictionary).duplicate()
		m["prog"] = 0.0
		m["done"] = false
		missions.append(m)


func _mission_add(id: String, amount: float) -> void:
	for m in missions:
		var md: Dictionary = m
		if bool(md["done"]) or str(md["id"]) != id:
			continue
		md["prog"] = float(md["prog"]) + amount
		if float(md["prog"]) >= float(md["goal"]):
			md["done"] = true
			score_f += float(md["reward"])
			hud.toast("मिशन पूरा! +%d" % int(md["reward"]), Color("#2FA84F"))
			say("mission", [], true)
			FX.ring(world, Vector3(0, 2.5, 0), Color("#FFD43B"))


func _missions_text() -> String:
	var lines: Array = []
	for m in missions:
		var md: Dictionary = m
		var t: String = str(md["fmt"]) % int(md["goal"])
		if bool(md["done"]):
			lines.append("%s  (पूरा!)" % t)
		else:
			lines.append("%s  (%d/%d)" % [t, int(md["prog"]), int(md["goal"])])
	return "आज के मिशन\n\n" + "\n".join(lines)


func _mission_line() -> String:
	for m in missions:
		var md: Dictionary = m
		if not bool(md["done"]):
			return "मिशन: %s (%d/%d)" % [str(md["fmt"]) % int(md["goal"]), int(md["prog"]), int(md["goal"])]
	return "सारे मिशन पूरे!"


func _clear_play_objects() -> void:
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		var kind: String = str(n.get_meta("kind", ""))
		if kind == "obstacle" or kind == "coin" or kind == "pickup":
			movers.remove_at(i)
			n.queue_free()


func _start_game() -> void:
	_clear_play_objects()
	_roll_missions()
	paused = false
	state = State.COUNTDOWN
	count_t = 3.4
	count_shown = 4
	lives = START_LIVES
	multiplier = 1
	coins_total = 0
	score_f = 0.0
	play_time = 0.0
	boost_t = 0.0
	safe_lane = 1
	lead_cd = 25.0
	next_row = world_dist + 60.0
	monument_at = world_dist + 1200.0
	for r in riders:
		r.coins = 0
		r.crashes = 0
		r.stun = 0.0
		r.inv = 0.0
		r.shield_t = 0.0
		r.y = 0.0
		r.vy = 0.0
		r.slide_t = 0.0
		r.look_back = 0.0
		r.root.visible = r.joined
	hud.hide_overlay()
	_update_hud()


func _to_lobby() -> void:
	state = State.LOBBY
	paused = false
	_clear_play_objects()
	for r in riders:
		r.look_back = 0.0
	_refresh_overlay()
	_update_hud()


func _game_over() -> void:
	state = State.GAMEOVER
	over_t = 2.5
	boost_t = 0.0
	say("over", [], true)
	for r in riders:
		r.look_back = 99.0
	_refresh_overlay()


func _hit(r: Rider, n: Node3D, otype: String) -> void:
	var col := Color("#C9884F")
	if boost_t > 0.0:
		FX.smash(world, n.position + Vector3(0, 1.2, 0), col)
		score_f += 30.0
		_remove_mover(n)
		return
	if r.shield_t > 0.0:
		r.shield_t = 0.0
		r.inv = 1.0
		FX.ring(world, r.root.position + Vector3(0, 1.8, 0), Color("#55D4FF"))
		FX.smash(world, n.position + Vector3(0, 1.2, 0), col)
		FX.popup(world, r.root.position + Vector3(0, 5.0, 0), "ढाल टूटी!", Color("#8FD1FF"), font, 60)
		say("shield_pop", [], true)
		_remove_mover(n)
		return
	r.stun = 1.5
	r.inv = 2.7
	r.crashes += 1
	r.look_back = 1.6
	r.vy = 0.0
	r.y = 0.0
	r.slide_t = 0.0
	lives -= 1
	multiplier = 1
	shake = 0.7
	speed = maxf(speed * 0.6, START_SPEED * 0.7)
	FX.smash(world, n.position + Vector3(0, 1.2, 0), col)
	FX.dust(world, r.root.position + Vector3(0, 0.4, 0))
	FX.popup(world, r.root.position + Vector3(0, 5.0, 0), cmt.word("crash"), Color("#FF6B5B"), font, 84)
	server.send_to(r.idx, {"t": "vibe", "ms": 380})
	_remove_mover(n)
	var both: bool = time_now - last_crash_time < 2.5
	last_crash_time = time_now
	if lives <= 0:
		_game_over()
		return
	if both:
		say("both", [], true)
	else:
		say(otype, [], true)
	_update_hud()


func _remove_mover(n: Node3D) -> void:
	var i: int = movers.find(n)
	if i >= 0:
		movers.remove_at(i)
	n.queue_free()


func _collect(r: Rider, n: Node3D) -> void:
	var kind: String = str(n.get_meta("kind", ""))
	var pos: Vector3 = n.position
	if kind == "coin":
		r.coins += 1
		coins_total += 1
		score_f += 10.0 * float(multiplier)
		if coins_total % 8 == 0:
			multiplier = mini(12, multiplier + 1)
			FX.popup(world, r.root.position + Vector3(0, 5.2, 0), "x%d" % multiplier, Color("#FFD43B"), font, 70)
		FX.coin_burst(world, pos)
		server.send_to(r.idx, {"t": "vibe", "ms": 15})
		_mission_add("coins", 1.0)
		if coins_total % 25 == 0:
			say("coins")
		_check_lead()
	else:
		var pt: String = str(n.get_meta("ptype", "shield"))
		FX.ring(world, pos, Color("#55D4FF") if pt == "shield" else Color("#FF9A3D"))
		r.look_back = 1.3
		server.send_to(r.idx, {"t": "vibe", "ms": 90})
		if pt == "shield":
			r.shield_t = SHIELD_TIME
			FX.popup(world, pos + Vector3(0, 2.0, 0), cmt.word("shield"), Color("#8FD1FF"), font, 76)
			_mission_add("shield", 1.0)
			say("shield_on", [], true)
		else:
			boost_t = BOOST_TIME
			for o in riders:
				o.look_back = 1.0
			FX.popup(world, pos + Vector3(0, 2.0, 0), cmt.word("boost"), Color("#FFB347"), font, 80)
			_mission_add("boost", 1.0)
			say("boost", [], true)
	_remove_mover(n)


func _check_lead() -> void:
	if lead_cd > 0.0:
		return
	var a: Rider = riders[0]
	var b: Rider = riders[1]
	if not (a.joined and b.joined):
		return
	var diff: int = a.coins - b.coins
	if absi(diff) < 8:
		return
	var lead: int = 0 if diff > 0 else 1
	lead_cd = 25.0
	if randf() < 0.5:
		say("lead", [lead + 1, 2 - lead], true)
	else:
		say("lag", [2 - lead], true)
	server.send_to(1 - lead, {"t": "vibe", "ms": 80})


# ================================================================ frame loop

func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	time_now += delta
	_update_clouds(delta)
	speech_cd = maxf(0.0, speech_cd - delta)
	if paused:
		_update_camera(delta)
		return
	lead_cd = maxf(0.0, lead_cd - delta)
	for r in riders:
		r.taunt_cd = maxf(0.0, r.taunt_cd - delta)
	match state:
		State.LOBBY:
			speed = move_toward(speed, LOBBY_SPEED, 10.0 * delta)
			_move_world(delta)
			_update_riders(delta, false)
		State.COUNTDOWN:
			count_t -= delta
			var shown: int = int(ceil(count_t - 0.4))
			if shown != count_shown and shown >= 1 and shown <= 3:
				count_shown = shown
				hud.countdown(str(shown))
			speed = move_toward(speed, START_SPEED * 0.7, 6.0 * delta)
			_move_world(delta)
			_update_riders(delta, false)
			if count_t <= 0.4 and count_shown != 0:
				count_shown = 0
				hud.countdown("चलो!", Color("#7CFF6B"))
				say("start", [], true)
			if count_t <= 0.0:
				state = State.PLAYING
				next_row = world_dist + 30.0
		State.PLAYING:
			play_time += delta
			_mission_add("survive", delta)
			boost_t = maxf(0.0, boost_t - delta)
			var target: float = minf(MAX_SPEED, START_SPEED + play_time * 0.14)
			if boost_t > 0.0:
				target += 10.0
			speed = move_toward(speed, target, 10.0 * delta)
			_move_world(delta)
			score_f += speed * delta * float(multiplier) * 0.4
			_spawn_rows()
			_update_riders(delta, true)
		State.GAMEOVER:
			over_t -= delta
			speed = move_toward(speed, 0.0, 22.0 * delta)
			_move_world(delta)
			_update_riders(delta, false)
	_update_camera(delta)
	hud_t += delta
	if hud_t > 0.1:
		hud_t = 0.0
		_update_hud()


func _update_clouds(delta: float) -> void:
	for c in clouds:
		var n: Node3D = c
		n.position.z += 2.5 * delta
		if n.position.z > 10.0:
			n.position.z = -175.0
			n.position.x = randf_range(-90.0, 90.0)


func _update_camera(delta: float) -> void:
	var off := Vector3.ZERO
	if shake > 0.0:
		shake = maxf(0.0, shake - delta * 1.6)
		off = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * shake * 0.3
	var cx := 0.0
	var count := 0
	for r in riders:
		if r.joined:
			cx += r.root.position.x
			count += 1
	if count > 0:
		cx = cx / float(count) * 0.18
	var want_fov: float = 58.0 + (12.0 if boost_t > 0.0 else 0.0)
	cam.fov = lerpf(cam.fov, want_fov, 1.0 - exp(-4.0 * delta))
	cam.look_at_from_position(CAM_POS + Vector3(cx, 0.0, 0.0) + off, CAM_TARGET + Vector3(cx * 0.5, 0.0, 0.0), Vector3.UP)


func _move_world(delta: float) -> void:
	var dz: float = speed * delta
	world_dist += dz
	if road_mat != null:
		road_mat.set_shader_parameter("scroll", fposmod(world_dist, 32.0))
		ground_mat.set_shader_parameter("scroll", fposmod(world_dist, 78.0))
	while world_dist >= next_chunk:
		next_chunk += Scenery.CHUNK_LEN
		var kind: String = Scenery.next_kind(scenery_prev)
		if world_dist >= monument_at:
			kind = "monument"
			monument_at = world_dist + 3500.0
		scenery_prev = kind
		_spawn_chunk(kind, SPAWN_Z - Scenery.CHUNK_LEN * 0.5)
	while world_dist >= next_dash:
		next_dash += 6.0
		_spawn_dash(SPAWN_Z)
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		if not is_instance_valid(n):
			movers.remove_at(i)
			continue
		n.position.z += dz
		var kind2: String = str(n.get_meta("kind", ""))
		if kind2 == "scenery":
			var half: float = float(n.get_meta("len", 42.0)) * 0.5
			if n.position.z - half > 30.0:
				movers.remove_at(i)
				n.queue_free()
				continue
			if n.position.z - half < 14.0 and n.position.z + half > SPAWN_Z:
				Scenery.animate_chunk(n, time_now, delta, speed)
			continue
		if n.position.z > DESPAWN_Z:
			movers.remove_at(i)
			n.queue_free()
			continue
		if kind2 == "obstacle":
			_update_obstacle(n, delta)
		elif kind2 == "coin":
			n.rotation.y += 3.2 * delta
		elif kind2 == "pickup":
			_update_pickup(n, delta)


func _update_obstacle(n: Node3D, delta: float) -> void:
	if n.has_meta("cross") and n.position.z > -52.0 and not bool(n.get_meta("started", false)):
		n.set_meta("started", true)
		n.set_meta("moving", true)
		var dir: float = float(n.get_meta("dir", 1.0))
		var cs: float = float(n.get_meta("cross", 1.0))
		var lx: float = float(n.get_meta("lane_x", 0.0))
		var eta: float = absf(n.position.z) / maxf(speed, 6.0)
		n.position.x = clampf(lx - dir * cs * eta, -10.5, 10.5)
	if bool(n.get_meta("moving", false)) and n.has_meta("cross"):
		var dir2: float = float(n.get_meta("dir", 1.0))
		n.position.x += dir2 * float(n.get_meta("cross", 1.0)) * delta
		if absf(n.position.x) > 11.5:
			n.set_meta("moving", false)
	if n.position.z > -60.0:
		Props.animate(n, time_now, delta, speed)


func _update_pickup(n: Node3D, delta: float) -> void:
	n.position.y = 1.6 + sin(time_now * 3.0 + n.position.x) * 0.25
	var sp: Node3D = n.get_meta("spin_node", null)
	if sp != null:
		sp.rotation.y += 2.4 * delta
	var h: Node3D = n.get_node_or_null("halo") as Node3D
	if h != null:
		var s: float = 1.0 + sin(time_now * 5.0) * 0.1
		h.scale = Vector3(s, s, s)


# ================================================================ riders

func _update_riders(delta: float, collide: bool) -> void:
	for rv in riders:
		var r: Rider = rv
		if not r.joined:
			continue
		var tx: float = LANES[r.lane]
		var x: float = r.root.position.x
		r.root.position.x = lerpf(x, tx, 1.0 - exp(-13.0 * delta))
		if r.y > 0.0 or r.vy > 0.0:
			r.vy -= GRAVITY * delta
			r.y += r.vy * delta
			if r.y <= 0.0:
				r.y = 0.0
				r.vy = 0.0
				r.squash = 0.22
				FX.dust(world, r.root.position + Vector3(0, 0.3, 0.5))
		r.slide_t = maxf(0.0, r.slide_t - delta)
		r.inv = maxf(0.0, r.inv - delta)
		r.shield_t = maxf(0.0, r.shield_t - delta)
		r.look_back = maxf(0.0, r.look_back - delta)
		r.squash = maxf(0.0, r.squash - delta * 0.8)
		var was_stunned: bool = r.stun > 0.0
		r.stun = maxf(0.0, r.stun - delta)
		var airborne: bool = r.y > 0.02
		var pedal: float = 0.0
		if state == State.GAMEOVER:
			pedal = 0.0
		elif r.stun > 0.0:
			pedal = 0.5
		elif airborne:
			pedal = 1.5
		else:
			pedal = 6.0 + speed * 0.5
		r.phase += delta * pedal
		_legs(r)
		for wv in r.wheels:
			var w: Node3D = wv
			w.rotation.x -= speed * delta / 0.55
		var body: Node3D = r.parts["body"]
		var head: Node3D = r.parts["head"]
		var want_lean: float = 0.0
		var want_y: float = 1.4
		if r.slide_t > 0.0:
			want_lean = -1.0
			want_y = 0.95
		elif airborne:
			want_lean = -0.3
		elif r.stun > 0.0:
			want_lean = 0.5
		body.rotation.x = lerpf(body.rotation.x, want_lean, 1.0 - exp(-14.0 * delta))
		body.position.y = lerpf(body.position.y, want_y, 1.0 - exp(-14.0 * delta))
		var look: float = PI if (r.look_back > 0.0 or state == State.GAMEOVER) else 0.0
		head.rotation.y = lerp_angle(head.rotation.y, look, 1.0 - exp(-12.0 * delta))
		var face: Dictionary = r.parts["face"]
		var mood := "normal"
		if r.stun > 0.0:
			mood = "dizzy"
		elif state == State.GAMEOVER:
			mood = "scared"
		elif r.look_back > 0.0 or boost_t > 0.0:
			mood = "happy"
		elif r.slide_t > 0.0 or airborne:
			mood = "scared" if r.y > 1.4 else "happy"
		if mood != r.mood:
			r.mood = mood
			Art.set_mood(face, mood)
		var roll: float = clampf((x - tx) * 0.1, -0.3, 0.3)
		if r.stun > 0.0:
			roll += sin(time_now * 34.0) * 0.22
		r.root.rotation.z = roll
		r.root.rotation.y = clampf((x - tx) * 0.05, -0.2, 0.2)
		r.root.position.y = r.y + (sin(time_now * 40.0) * 0.05 if r.stun > 0.0 else 0.0)
		var sq: float = r.squash
		var sy: float = 1.0 - sq * 0.6 if r.y <= 0.02 else 1.0 + minf(absf(r.vy), 10.0) * 0.012
		r.root.scale = Vector3(1.0 + sq * 0.5, sy, 1.0 + sq * 0.5)
		r.stars.visible = r.stun > 0.0
		r.stars.rotation.y += delta * 6.0
		var shield_node: Node3D = r.parts["shield"]
		shield_node.visible = r.shield_t > 0.0 and (r.shield_t > 2.0 or int(time_now * 8.0) % 2 == 0)
		var trail: CPUParticles3D = r.parts["trail"]
		trail.emitting = boost_t > 0.0
		r.dust.emitting = (state != State.GAMEOVER) and not airborne and speed > 6.0 and r.stun <= 0.0
		if r.inv > 0.0 and r.stun <= 0.0 and not was_stunned:
			r.root.visible = int(time_now * 14.0) % 2 == 0
		else:
			r.root.visible = true
		if collide:
			_check_collisions(r)


func _legs(r: Rider) -> void:
	var l1 := 0.7
	var l2 := 0.74
	for k in range(2):
		var hip: Node3D = r.parts["hip_l"] if k == 0 else r.parts["hip_r"]
		var knee: Node3D = r.parts["knee_l"] if k == 0 else r.parts["knee_r"]
		var ph: float = r.phase + PI * float(k)
		var fy: float = 0.62 + 0.26 * sin(ph)
		var fz: float = 0.15 + 0.26 * cos(ph)
		var dy: float = fy - hip.position.y
		var dz: float = fz - hip.position.z
		var d: float = clampf(sqrt(dy * dy + dz * dz), 0.35, l1 + l2 - 0.02)
		var tv: float = atan2(-dz, -dy)
		var a1: float = acos(clampf((l1 * l1 + d * d - l2 * l2) / (2.0 * l1 * d), -1.0, 1.0))
		var b1: float = acos(clampf((l2 * l2 + d * d - l1 * l1) / (2.0 * l2 * d), -1.0, 1.0))
		hip.rotation.x = tv + a1
		knee.rotation.x = -(a1 + b1)


func _check_collisions(r: Rider) -> void:
	if r.stun > 0.0 or not r.connected:
		return
	var rx: float = r.root.position.x
	var top: float = r.y + (1.9 if r.slide_t > 0.0 else 3.3)
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		var kind: String = str(n.get_meta("kind", ""))
		if kind != "obstacle" and kind != "coin" and kind != "pickup":
			continue
		var dz: float = absf(n.position.z)
		if dz > 6.0:
			continue
		var dx: float = absf(n.position.x - rx)
		if kind == "coin":
			var cy: float = float(n.get_meta("cy", 1.2))
			if dx < 1.25 and dz < 1.4 and absf(cy - (r.y + 1.9)) < 1.8:
				_collect(r, n)
			continue
		if kind == "pickup":
			if dx < 1.5 and dz < 1.7:
				_collect(r, n)
			continue
		if r.inv > 0.0 and boost_t <= 0.0:
			continue
		var otype: String = str(n.get_meta("otype", ""))
		var spec: Dictionary = Props.SPEC[otype]
		var hx: float = float(spec["hw"])
		var hz: float = float(spec["hz"])
		if n.has_meta("cross"):
			hx = float(spec["hz"])
			hz = float(spec["hw"])
		if dx < hx + 0.5 and dz < hz + 0.7:
			var ok: String = str(spec["kind"])
			if ok == "slip":
				if r.y < 0.4 and not bool(n.get_meta("splashed", false)):
					n.set_meta("splashed", true)
					FX.splash(world, n.position + Vector3(0, 0.3, 0))
					speed = maxf(speed * 0.8, START_SPEED * 0.8)
					r.look_back = 0.8
					say("puddle", [])
			elif ok == "high":
				if top > float(spec.get("ylo", 2.2)) and r.y < float(spec["h"]):
					_hit(r, n, otype)
					return
			else:
				if r.y < float(spec["h"]):
					_hit(r, n, otype)
					return


# ================================================================ spawning

func _pick_obstacle() -> String:
	var pool: Array = ["puddle", "hay", "hay", "barricade", "barricade", "scooter", "car", "car", "auto", "bike", "cow", "cart", "tractor", "laundry", "buffalo", "ox", "man", "goat", "horse", "pig", "truck"]
	if play_time > 30.0:
		pool.append_array(["bull", "dog", "woman", "cart", "tractor", "barricade", "truck"])
	return pool[randi() % pool.size()]


func _spawn_rows() -> void:
	while world_dist >= next_row:
		var gap: float = lerpf(38.0, 27.0, clampf(play_time / 150.0, 0.0, 1.0))
		next_row += gap
		_spawn_row()


func _add_mover(n: Node3D, kind: String, x: float, z: float) -> void:
	n.position = Vector3(x, n.position.y, z)
	n.set_meta("kind", kind)
	world.add_child(n)
	movers.append(n)


func _spawn_obstacle(lane: int, otype: String, zoff: float = 0.0) -> Node3D:
	var n := Props.make(otype)
	var spec: Dictionary = Props.SPEC[otype]
	var x: float = LANES[lane]
	n.set_meta("otype", otype)
	n.set_meta("lane_x", x)
	if spec.has("cross") and randf() < 0.3:
		var dir: float = 1.0 if randf() < 0.5 else -1.0
		n.set_meta("cross", float(spec["cross"]))
		n.set_meta("dir", dir)
		n.rotation_degrees.y = dir * 90.0
		x = -dir * 10.5
	_add_mover(n, "obstacle", x, SPAWN_Z + zoff)
	return n


func _spawn_coin_line(lane: int, count: int, zoff: float = 0.0, arc: bool = false) -> void:
	for i in range(count):
		var cy: float = 1.2
		if arc:
			cy = 1.2 + sin(PI * float(i) / float(maxi(count - 1, 1))) * 1.5
		var c := Art.make_coin(cy)
		c.set_meta("cy", cy)
		_add_mover(c, "coin", LANES[lane], SPAWN_Z + zoff - float(i) * 2.4)


func _spawn_row() -> void:
	var cands: Array = []
	for l in range(4):
		if absi(l - safe_lane) <= 2:
			cands.append(l)
	safe_lane = cands[randi() % cands.size()]
	var free: Array = [safe_lane]
	if play_time < 40.0 or randf() < 0.35:
		var nb: int = safe_lane + (1 if (safe_lane == 0 or (safe_lane < 3 and randf() < 0.5)) else -1)
		free.append(clampi(nb, 0, 3))
	var blocked: Array = []
	for l in range(4):
		if not free.has(l):
			blocked.append(l)
	blocked.shuffle()
	var r: float = randf()
	if r < 0.12:
		_spawn_coin_line(safe_lane, 7)
		return
	if r < 0.18 and play_time > 25.0:
		var left: bool = safe_lane >= 2
		var a: int = 0 if left else 2
		var xmid: float = (float(LANES[a]) + float(LANES[a + 1])) * 0.5
		var bus := Props.make("bus")
		bus.set_meta("otype", "bus")
		bus.set_meta("lane_x", xmid)
		_add_mover(bus, "obstacle", xmid, SPAWN_Z - 4.0)
		_spawn_coin_line(safe_lane, 5)
		return
	if r < 0.20:
		var lane: int = blocked[0]
		for i in range(3):
			var ch := _spawn_obstacle(lane, "chicken", -2.2 * float(i))
			ch.set_meta("lane_x", float(LANES[lane]) + 0.3 * float(i % 2))
		_spawn_coin_line(safe_lane, 4)
		return
	var nblock: int = mini(blocked.size(), randi_range(1, 1 if play_time < 60.0 else 2))
	for i in range(nblock):
		var lane2: int = blocked[i]
		var ot := _pick_obstacle()
		_spawn_obstacle(lane2, ot)
		if str(Props.SPEC[ot]["kind"]) == "low" and randf() < 0.5:
			_spawn_coin_line(lane2, 5, 4.0, true)
	var pick: float = randf()
	if pick < 0.08 and play_time > 10.0 and not _any_shield():
		var s := Art.make_shield_pickup()
		s.set_meta("ptype", "shield")
		_add_mover(s, "pickup", LANES[safe_lane], SPAWN_Z)
	elif pick < 0.15 and play_time > 20.0 and boost_t <= 0.0:
		var b := Art.make_boost_pickup()
		b.set_meta("ptype", "boost")
		_add_mover(b, "pickup", LANES[safe_lane], SPAWN_Z)
	else:
		_spawn_coin_line(safe_lane, randi_range(4, 8), 0.0, randf() < 0.3)
	if free.size() > 1 and randf() < 0.5:
		_spawn_coin_line(free[1], 4, -6.0)


func _any_shield() -> bool:
	for r in riders:
		if r.shield_t > 0.0:
			return true
	for n in movers:
		if str(n.get_meta("ptype", "")) == "shield":
			return true
	return false


# ================================================================ speech and HUD

func say(event: String, args: Array = [], force: bool = false) -> void:
	if not force and speech_cd > 0.0:
		return
	var s: String = cmt.pick(event)
	if s == "":
		return
	if args.size() > 0:
		s = s % args
	hud.speech(s)
	speech_cd = 4.5


func _update_hud() -> void:
	hud.update_hud(coins_total, int(score_f), multiplier, lives, MAX_LIVES)
	var joined: Array = []
	var coins: Array = []
	var shields: Array = []
	for r in riders:
		joined.append(r.joined)
		coins.append(r.coins)
		shields.append(r.shield_t > 0.0)
	hud.update_players(joined, coins, shields)
	hud.set_power("boost", boost_t, BOOST_TIME)
	hud.set_power("shield1", (riders[0] as Rider).shield_t, SHIELD_TIME)
	hud.set_power("shield2", (riders[1] as Rider).shield_t, SHIELD_TIME)
	hud.set_mission_line(_mission_line() if state == State.PLAYING else "")


func _slot_text(i: int) -> String:
	var r: Rider = riders[i]
	var st: String = "जुड़ गया" if r.joined else "इंतज़ार..."
	return "खिलाड़ी %d: %s" % [i + 1, st]


func _roast_text() -> String:
	var a: Rider = riders[0]
	var b: Rider = riders[1]
	if not (a.joined and b.joined):
		return "अकेले भी क्या खेलना! अगली बार दोस्त को बुलाओ।"
	var lines: Array = []
	if a.crashes == b.crashes:
		lines.append("दोनों ने %d-%d बार साइकिल ठोकी। बराबरी की टक्कर!" % [a.crashes, b.crashes])
	else:
		var worst: Rider = a if a.crashes > b.crashes else b
		lines.append("खिलाड़ी %d ने %d बार साइकिल ठोकी। बीमा वाले हाथ जोड़ रहे हैं।" % [worst.idx + 1, worst.crashes])
	if a.coins != b.coins:
		var rich: Rider = a if a.coins > b.coins else b
		lines.append("सिक्कों में खिलाड़ी %d आगे: %d-%d" % [rich.idx + 1, a.coins, b.coins])
	return "\n".join(lines)


func _refresh_overlay() -> void:
	if hud == null:
		return
	match state:
		State.LOBBY:
			var q: String = "ज़्यादा" if quality == "high" else "कम (तेज़)"
			hud.show_overlay("साइकिल रश", "फ़ोन के ब्राउज़र में खोलो (वही वाई-फ़ाई):\n%s\n\n%s     %s\n\nबाएँ/दाएँ स्वाइप: लेन   |   ऊपर: कूदो   |   नीचे: झुको\nक्वालिटी: %s (फ़ोन पर बदलो)\n\nVehicles: Bus Simulator India - Traffic Cars by Villanueva-Jonatan-32621 (CC BY 4.0)\nRoad: Hiden Road Diorama by Toni García Vilche (CC BY 4.0)\nBuildings: AJ_AY (Bhelpuri Shop), lucas.rvdl (Ganesha 3D), bhagathartworks (Indian House Old), nayan pachori (Under Construction House, Community Cleanliness Complex - CC BY-NC-ND 4.0), Ace.Rich (House with tank)\nTrees, cycle, saree lady: 00amza, Simon Ustal, stealth86, iGauravRajput, Tidominer, dk8026854 (CC BY 4.0) - via Sketchfab" % [server.url, _slot_text(0), _slot_text(1), q], "फ़ोन पर \"शुरू\" दबाओ या रिमोट का OK")
		State.GAMEOVER:
			hud.show_overlay("खेल ख़त्म!", "स्कोर: %d      सिक्के: %d\n\n%s\n\n%s" % [int(score_f), coins_total, _roast_text(), _missions_text()], "फिर खेलने के लिए \"शुरू\" या OK", Color("#D93636"))
		_:
			hud.hide_overlay()
