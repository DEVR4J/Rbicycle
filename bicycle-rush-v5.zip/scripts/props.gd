extends RefCounted
## Animals, villagers and vehicles. Everything faces +Z (towards the camera) so
## the expressive faces are visible. Crossing animals are rotated about Y by
## main.gd (+90 degrees = walking towards +X).

const Art := preload("res://scripts/art.gd")

## kind: block = needs a lane change, low = can be jumped, slip = splash only.
## cross = sideways speed in metres per second (0 or missing = stands still).
const SPEC := {
	"puddle": {"hw": 1.3, "hz": 1.3, "h": 0.25, "kind": "slip"},
	"hay": {"hw": 1.1, "hz": 0.9, "h": 1.1, "kind": "low"},
	"barricade": {"hw": 1.35, "hz": 0.4, "h": 1.2, "kind": "low"},
	"scooter": {"hw": 0.7, "hz": 1.1, "h": 1.25, "kind": "low"},
	"chicken": {"hw": 0.45, "hz": 0.45, "h": 0.8, "kind": "low", "cross": 5.2},
	"goat": {"hw": 0.6, "hz": 0.8, "h": 1.15, "kind": "low", "cross": 3.4},
	"dog": {"hw": 0.55, "hz": 0.8, "h": 1.0, "kind": "low", "cross": 4.4},
	"cow": {"hw": 0.9, "hz": 1.5, "h": 2.2, "kind": "block", "cross": 1.5},
	"buffalo": {"hw": 1.0, "hz": 1.6, "h": 2.3, "kind": "block", "cross": 1.1},
	"ox": {"hw": 0.9, "hz": 1.5, "h": 2.3, "kind": "block", "cross": 1.4},
	"bull": {"hw": 0.9, "hz": 1.5, "h": 2.4, "kind": "block", "cross": 2.8},
	"man": {"hw": 0.6, "hz": 0.6, "h": 2.7, "kind": "block", "cross": 1.7},
	"woman": {"hw": 0.6, "hz": 0.6, "h": 2.7, "kind": "block", "cross": 1.5},
	"laundry": {"hw": 1.5, "hz": 0.4, "h": 3.6, "kind": "high", "ylo": 2.2},
	"cart": {"hw": 1.5, "hz": 3.2, "h": 3.2, "kind": "block"},
	"tractor": {"hw": 1.5, "hz": 2.1, "h": 3.0, "kind": "block"},
	"bus": {"hw": 2.4, "hz": 4.4, "h": 4.0, "kind": "block", "wide": true},
}

const COW_PATCH := [Color("#FFFFFF"), Color("#F4E3C8"), Color("#C98A52")]
const GOAT_COL := [Color("#FFFFFF"), Color("#C9884F"), Color("#4A3B35"), Color("#E8D9BC")]
const SHIRTS := [Color("#FF5C93"), Color("#3E7BFA"), Color("#FFCB2F"), Color("#18C4B8"), Color("#FF8A2B"), Color("#8E5CF0"), Color("#3FBF5A")]
const SKINS := [Color("#C98B5E"), Color("#B9794F"), Color("#D9A06E"), Color("#9C6440")]


static func make(otype: String) -> Node3D:
	match otype:
		"puddle":
			return make_puddle()
		"hay":
			return make_hay()
		"barricade":
			return make_barricade()
		"scooter":
			return make_scooter()
		"chicken":
			return make_chicken()
		"goat":
			return make_goat()
		"dog":
			return make_dog()
		"cow":
			return make_cow()
		"buffalo":
			return make_buffalo(0)
		"ox":
			return make_ox()
		"bull":
			return make_bull()
		"man":
			return make_person(false)
		"woman":
			return make_person(true)
		"laundry":
			return make_laundry()
		"cart":
			return make_cart()
		"tractor":
			return make_tractor()
		"bus":
			return make_bus()
	return make_hay()


# ============================================================ animation

static func animate(n: Node3D, t: float, dt: float, speed: float) -> void:
	var moving: bool = n.get_meta("moving", false)
	var gait: float = n.get_meta("gait", 8.0)
	var legs: Array = n.get_meta("legs", [])
	for lg in legs:
		var l: Node3D = lg
		if moving:
			l.rotation.x = sin(t * gait + float(l.get_meta("ph", 0.0))) * float(l.get_meta("amp", 0.5))
		else:
			l.rotation.x = lerpf(l.rotation.x, 0.0, 1.0 - exp(-10.0 * dt))
	var arms: Array = n.get_meta("arms", [])
	for ar in arms:
		var a: Node3D = ar
		if moving:
			a.rotation.x = sin(t * gait + float(a.get_meta("ph", 0.0))) * float(a.get_meta("amp", 0.5))
	if n.has_meta("tail"):
		var tl: Node3D = n.get_meta("tail")
		tl.rotation.z = sin(t * float(n.get_meta("tail_rate", 5.0))) * 0.5
	if n.has_meta("head"):
		var hd: Node3D = n.get_meta("head")
		var base: float = hd.get_meta("rx", 0.0)
		hd.rotation.x = base + sin(t * (gait * 0.5 if moving else 1.7)) * (0.12 if moving else 0.05)
	if n.has_meta("bob"):
		var b: Node3D = n.get_meta("bob")
		var by: float = b.get_meta("y0", 0.0)
		if moving:
			b.position.y = by + absf(sin(t * gait)) * float(n.get_meta("bob_amp", 0.08))
		else:
			b.position.y = by
	if n.has_meta("breathe"):
		var br: Node3D = n.get_meta("breathe")
		br.scale.y = 1.0 + sin(t * 1.6) * 0.025
	if n.has_meta("sway"):
		var sw: Node3D = n.get_meta("sway")
		sw.rotation.z = sin(t * gait) * 0.05 if moving else 0.0
	if n.has_meta("wheels") and bool(n.get_meta("rolling", false)):
		var ws: Array = n.get_meta("wheels")
		for wv in ws:
			var w: Node3D = wv
			w.rotation.x -= speed * dt / float(w.get_meta("r", 0.5))
	if n.has_meta("wave"):
		var wv2: Node3D = n.get_meta("wave")
		wv2.rotation.z = deg_to_rad(-150.0) + sin(t * 7.0 + float(n.get_meta("ph", 0.0))) * 0.45
	if n.has_meta("hop"):
		n.position.y = absf(sin(t * 5.5 + float(n.get_meta("ph", 0.0)))) * 0.45
	if n.has_meta("lamp"):
		var lp: Node3D = n.get_meta("lamp")
		lp.visible = int(t * 3.0) % 2 == 0
	if n.has_meta("drops"):
		var ds: Array = n.get_meta("drops")
		for dv in ds:
			var d: Node3D = dv
			d.position.y = float(d.get_meta("y0", 0.3)) + absf(sin(t * 3.0 + float(d.get_meta("ph", 0.0)))) * 0.35


# ============================================================ helpers

static func _wheel(parent: Node3D, wheels: Array, pos: Vector3, r: float, w: float, tire: Color, hub: Color, treads: int) -> Node3D:
	var g := Art.group(parent, pos)
	g.set_meta("r", r)
	Art.part(g, Art.cyl(r, r, w, 16), tire, Vector3.ZERO, Vector3(0, 0, 90), true, 0.06)
	Art.part(g, Art.cyl(r * 0.55, r * 0.55, w + 0.04, 12), hub, Vector3.ZERO, Vector3(0, 0, 90), false)
	for i in range(treads):
		var a: float = TAU * float(i) / float(treads)
		Art.part(g, Art.box(Vector3(w * 0.95, r * 0.22, r * 0.3)), tire.darkened(0.25), Vector3(0, cos(a) * r, sin(a) * r), Vector3(rad_to_deg(-a), 0, 0), false)
	wheels.append(g)
	return g


static func _horns(head: Node3D, kind: String, hr: float, col: Color) -> void:
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		match kind:
			"long":
				var b := Art.group(head, Vector3(s * hr * 0.78, hr * 0.55, -hr * 0.15), Vector3(0, 0, s * -62.0))
				Art.part(b, Art.cap(hr * 0.13, hr * 1.25, 8), col, Vector3(0, hr * 0.5, 0), Vector3.ZERO, true, 0.04)
				Art.part(b, Art.cap(hr * 0.1, hr * 0.7, 8), col, Vector3(-s * hr * 0.35, hr * 1.1, -hr * 0.2), Vector3(-25, 0, s * 55.0), false)
			"curved":
				var b2 := Art.group(head, Vector3(s * hr * 0.6, hr * 0.78, hr * 0.05), Vector3(0, 0, s * -28.0))
				Art.part(b2, Art.cap(hr * 0.15, hr * 0.9, 8), col, Vector3(0, hr * 0.4, 0), Vector3.ZERO, true, 0.04)
				Art.part(b2, Art.cap(hr * 0.1, hr * 0.5, 8), col, Vector3(s * hr * 0.25, hr * 0.95, hr * 0.0), Vector3(0, 0, s * -50.0), false)
			"short":
				Art.part(head, Art.cyl(0.0, hr * 0.2, hr * 0.55, 8), col, Vector3(s * hr * 0.5, hr * 0.85, -hr * 0.1), Vector3(0, 0, s * -20.0), true, 0.03)
			"goat":
				Art.part(head, Art.cap(hr * 0.1, hr * 0.9, 6), col, Vector3(s * hr * 0.35, hr * 0.95, -hr * 0.25), Vector3(-35, 0, s * -12.0), true, 0.03)


static func _ears(head: Node3D, kind: String, hr: float, col: Color, inner: Color) -> void:
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		match kind:
			"flop":
				Art.part(head, Art.sph(hr * 0.32, 8), col, Vector3(s * hr * 1.0, hr * 0.1, -hr * 0.2), Vector3(0, 0, s * 25.0), true, 0.04, Vector3(1.6, 0.4, 1.0))
			"side":
				Art.part(head, Art.sph(hr * 0.3, 8), col, Vector3(s * hr * 1.0, hr * 0.35, -hr * 0.2), Vector3(0, 0, s * -15.0), true, 0.04, Vector3(1.7, 0.35, 0.9))
				Art.part(head, Art.sph(hr * 0.2, 8), inner, Vector3(s * hr * 1.0, hr * 0.35, -hr * 0.12), Vector3(0, 0, s * -15.0), false, 0.03, Vector3(1.5, 0.3, 0.9))
			"pointy":
				Art.part(head, Art.cyl(0.0, hr * 0.28, hr * 0.8, 6), col, Vector3(s * hr * 0.55, hr * 0.95, -hr * 0.1), Vector3(0, 0, s * -12.0), true, 0.04)
			"long":
				Art.part(head, Art.cap(hr * 0.17, hr * 1.1, 8), col, Vector3(s * hr * 0.9, hr * 0.15, -hr * 0.1), Vector3(0, 0, s * 72.0), true, 0.04)


## A tapered limb between two points (axis from `from` to `to`).
static func _tube(parent: Node3D, from: Vector3, to: Vector3, r0: float, r1: float, color: Color, outline: bool = false, seg: int = 10) -> MeshInstance3D:
	var d: Vector3 = to - from
	var ln: float = maxf(d.length(), 0.001)
	var mi: MeshInstance3D = Art.part(parent, Art.cyl(r1, r0, ln, seg), color, (from + to) * 0.5, Vector3.ZERO, outline, 0.03)
	var dir: Vector3 = d / ln
	var axis: Vector3 = Vector3.UP.cross(dir)
	if axis.length() > 0.0001:
		mi.basis = Basis(axis.normalized(), Vector3.UP.angle_to(dir))
	elif dir.y < 0.0:
		mi.basis = Basis(Vector3.RIGHT, PI)
	return mi


## Two-part animal leg (thigh/forearm, shin, hoof) hanging from a hip pivot.
static func _leg(parent: Node3D, x: float, y: float, z: float, length: float, r: float, color: Color, hoof: Color, hind: bool) -> Node3D:
	var p := Art.group(parent, Vector3(x, y, z))
	var kz: float = -0.1 * length if hind else 0.03 * length
	var knee := Vector3(0, -length * 0.48, kz)
	var ank := Vector3(0, -length * 0.9, 0)
	_tube(p, Vector3.ZERO, knee, r * 1.6, r * 1.0, color, false, 8)
	_tube(p, knee, ank, r * 1.0, r * 0.7, color, false, 8)
	Art.part(p, Art.cyl(r * 0.62, r * 0.88, length * 0.13, 8), hoof, Vector3(0, -length * 0.94, 0), Vector3.ZERO, false)
	return p


static func _real_eyes(head: Node3D, x: float, y: float, z: float, r: float, mood: int) -> void:
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		var ex: float = x * s
		if mood == 1:
			Art.part(head, Art.box(Vector3(r * 1.7, r * 0.25, r * 0.5)), Art.INK, Vector3(ex, y, z), Vector3(0, 0, s * -8.0), false)
			continue
		Art.part(head, Art.sph(r * 1.15, 8), Color("#F1E8D8"), Vector3(ex, y, z), Vector3.ZERO, false, 0.02, Vector3(0.7, 1.0, 1.0))
		Art.part(head, Art.sph(r * 0.8, 8), Color("#2A1A12"), Vector3(ex + s * r * 0.15, y, z + r * 0.3), Vector3.ZERO, false, 0.02, Vector3(0.6, 1.0, 0.8))
		Art.part(head, Art.sph(r * 0.2, 5), Color.WHITE, Vector3(ex + s * r * 0.22, y + r * 0.3, z + r * 0.62), Vector3.ZERO, false)
		if mood == 2:
			Art.part(head, Art.box(Vector3(r * 2.0, r * 0.35, r * 0.4)), Art.INK, Vector3(ex, y + r * 1.2, z + r * 0.1), Vector3(0, 0, s * -22.0), false)


## Four-legged animal built along Z, head at +Z: ellipsoid barrel, chest and
## rump, a tilted tapered neck, a skull with a tapering muzzle, two-part legs.
static func _quad(c: Dictionary) -> Node3D:
	var n := Node3D.new()
	var col: Color = c["col"]
	var col2: Color = c.get("col2", col)
	var rad: float = c["rad"]
	var ln: float = c["len"]
	var lh: float = c["leg"]
	var hr: float = float(c["head"]) * 0.85
	var mood: int = c.get("mood", 0)
	var hoof: Color = c.get("hoof", Art.C_HAIR)
	var yb: float = lh + rad * 0.85
	var half: float = ln * 0.5 + rad
	var body := Art.group(n)
	body.set_meta("y0", 0.0)
	Art.part(body, Art.sph(rad, 18), col, Vector3(0, yb, 0), Vector3.ZERO, true, 0.04, Vector3(0.9, 0.96, half / rad))
	Art.part(body, Art.sph(rad * 0.95, 14), col, Vector3(0, yb - rad * 0.02, ln * 0.3), Vector3.ZERO, false, 0.03, Vector3(0.9, 1.0, 1.0))
	Art.part(body, Art.sph(rad * 0.92, 14), col, Vector3(0, yb + rad * 0.06, -ln * 0.3), Vector3.ZERO, false, 0.03, Vector3(0.95, 1.0, 1.05))
	if c.has("belly"):
		Art.part(body, Art.sph(rad * 0.8, 12), c["belly"], Vector3(0, yb - rad * 0.34, 0), Vector3.ZERO, false, 0.03, Vector3(0.85, 0.7, half * 0.95 / (rad * 0.8)))
	if c.has("spot"):
		var sp: Color = c["spot"]
		Art.part(body, Art.sph(rad * 0.55, 8), sp, Vector3(rad * 0.72, yb + rad * 0.3, ln * 0.1), Vector3.ZERO, false, 0.03, Vector3(0.4, 1.0, 1.3))
		Art.part(body, Art.sph(rad * 0.5, 8), sp, Vector3(-rad * 0.72, yb + rad * 0.1, -ln * 0.25), Vector3.ZERO, false, 0.03, Vector3(0.4, 1.0, 1.1))
		Art.part(body, Art.sph(rad * 0.4, 8), sp, Vector3(0, yb + rad * 0.9, -ln * 0.05), Vector3.ZERO, false, 0.03, Vector3(1.2, 0.4, 1.2))
	if c.get("hump", false):
		Art.part(body, Art.sph(rad * 0.58, 10), col, Vector3(0, yb + rad * 0.82, ln * 0.3), Vector3.ZERO, true, 0.04, Vector3(0.9, 1.0, 1.2))

	var legs: Array = []
	var lr: float = rad * 0.17
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var hind: bool = float(sz) < 0.0
			var lg := _leg(n, float(sx) * rad * 0.5, yb - rad * 0.35, float(sz) * ln * 0.34, lh + rad * 0.35, lr, col2, hoof, hind)
			lg.set_meta("ph", 0.0 if float(sx) * float(sz) > 0.0 else PI)
			lg.set_meta("amp", 0.5)
			legs.append(lg)

	var nang: float = deg_to_rad(float(c.get("neck_ang", 38.0)))
	var nlen: float = rad * float(c.get("neck_len", 1.25))
	var nb := Vector3(0, yb + rad * 0.3, ln * 0.5 + rad * 0.1)
	var ndir := Vector3(0, sin(nang), cos(nang))
	var hp: Vector3 = nb + ndir * nlen
	hp.y += float(c.get("neck", 0.0))
	_tube(n, nb - ndir * rad * 0.15, hp, rad * 0.62, rad * 0.4, col, true, 12)

	var head := Art.group(n, hp)
	var hpitch: float = float(c.get("head_pitch", 0.45))
	head.set_meta("rx", hpitch)
	head.rotation.x = hpitch
	Art.part(head, Art.sph(hr, 14), col2, Vector3.ZERO, Vector3.ZERO, true, 0.03, Vector3(0.82, 0.95, 1.1))
	var sn: Color = c.get("snout", col2.lightened(0.18))
	Art.part(head, Art.cyl(hr * 0.36, hr * 0.55, hr * 1.35, 10), sn, Vector3(0, -hr * 0.05, hr * 1.15), Vector3(90, 0, 0), true, 0.03)
	for sx in [-1.0, 1.0]:
		Art.part(head, Art.sph(hr * 0.08, 6), Art.INK, Vector3(float(sx) * hr * 0.15, -hr * 0.02, hr * 1.83), Vector3.ZERO, false, 0.02, Vector3(1, 1.3, 0.6))
	if c.get("tongue", false):
		Art.part(head, Art.sph(hr * 0.2, 6), Art.C_PINK, Vector3(0, -hr * 0.45, hr * 1.7), Vector3.ZERO, false, 0.02, Vector3(0.9, 0.5, 1.4))
	_real_eyes(head, hr * 0.68, hr * 0.22, hr * 0.55, hr * 0.14, mood)
	_ears(head, str(c.get("ear", "flop")), hr, col2, c.get("inner", Art.C_PINK))
	_horns(head, str(c.get("horn", "none")), hr, c.get("horn_col", Art.C_STONE))
	if c.get("beard", false):
		Art.part(head, Art.cyl(hr * 0.12, 0.0, hr * 0.7, 6), col.lightened(0.15), Vector3(0, -hr * 0.8, hr * 1.5), Vector3.ZERO, false)
	if c.get("garland", false):
		for i in range(10):
			var a: float = TAU * float(i) / 10.0
			var gc: Color = Art.C_ORANGE if i % 2 == 0 else Art.C_YELLOW
			Art.part(n, Art.sph(rad * 0.18, 6), gc, Vector3(cos(a) * rad * 0.74, yb + rad * 0.3 + sin(a) * rad * 0.7, ln * 0.5 - rad * 0.1), Vector3.ZERO, true, 0.03)
	if c.get("bell", false):
		Art.part(n, Art.sph(rad * 0.2, 8), Art.C_GOLD, Vector3(0, yb - rad * 0.42, ln * 0.5 + rad * 0.1), Vector3.ZERO, true, 0.03)

	var tail := Art.group(n, Vector3(0, yb + rad * 0.35, -ln * 0.5 - rad * 0.85))
	var tk: String = str(c.get("tail", "tuft"))
	if tk == "tuft":
		Art.part(tail, Art.cap(rad * 0.08, lh * 0.9 + rad, 6), col2, Vector3(0, -lh * 0.45, 0), Vector3.ZERO, false)
		Art.part(tail, Art.sph(rad * 0.22, 8), Art.C_HAIR, Vector3(0, -lh * 0.95 - rad * 0.2, 0), Vector3.ZERO, true, 0.03, Vector3(1, 1.6, 1))
	elif tk == "up":
		Art.part(tail, Art.cap(rad * 0.12, rad * 1.6, 6), col2, Vector3(0, rad * 0.5, -rad * 0.2), Vector3(-30, 0, 0), true, 0.03)
	else:
		Art.part(tail, Art.sph(rad * 0.2, 6), col2, Vector3(0, 0, -rad * 0.1), Vector3.ZERO, true, 0.03)

	n.set_meta("legs", legs)
	n.set_meta("head", head)
	n.set_meta("tail", tail)
	n.set_meta("bob", body)
	n.set_meta("breathe", body)
	n.set_meta("gait", 7.0)
	return n


# ============================================================ animals

static func make_cow() -> Node3D:
	var base: Color = COW_PATCH[randi() % COW_PATCH.size()]
	var n := _quad({
		"col": base, "col2": base.darkened(0.04), "rad": 0.78, "len": 1.7, "leg": 0.95, "head": 0.55,
		"ear": "side", "horn": "short", "spot": Color("#8A5A36"), "snout": Color("#FFC9B5"),
		"tail": "tuft", "garland": true, "bell": true, "hump": true,
	})
	return n


static func make_buffalo(mood: int = 0) -> Node3D:
	var n := _quad({
		"col": Color("#5E6B80"), "col2": Color("#4B566A"), "rad": 0.92, "len": 1.9, "leg": 0.8, "head": 0.62,
		"ear": "side", "horn": "long", "horn_col": Color("#E7DCC3"), "snout": Color("#6E7A8F"), "tail": "tuft",
		"mood": mood, "inner": Color("#8F98AA"), "neck": -0.1, "neck_ang": 18.0, "head_pitch": 0.7, "neck_len": 1.3,
	})
	return n


static func make_ox() -> Node3D:
	var n := _quad({
		"col": Color("#F2E4CC"), "col2": Color("#E8D3AF"), "rad": 0.74, "len": 1.7, "leg": 1.0, "head": 0.52,
		"ear": "side", "horn": "curved", "horn_col": Color("#7A5A3A"), "snout": Color("#FFD3C2"), "tail": "tuft",
		"hump": true, "garland": true, "bell": true,
	})
	return n


static func make_bull() -> Node3D:
	var n := _quad({
		"col": Color("#8B3F2E"), "col2": Color("#732F22"), "rad": 0.88, "len": 1.8, "leg": 0.95, "head": 0.6,
		"ear": "side", "horn": "curved", "horn_col": Color("#F2E8D0"), "snout": Color("#B05A44"), "tail": "tuft",
		"mood": 2, "hump": true, "inner": Color("#D98A70"), "neck_ang": 28.0, "head_pitch": 0.55, "neck_len": 1.1,
	})
	var ring := Art.part(n, Art.torus(0.05, 0.13, 10), Art.C_GOLD, Vector3(0, 1.8, 2.12), Vector3(90, 0, 0), false)
	ring.scale = Vector3(1.4, 1.4, 1.4)
	n.set_meta("gait", 11.0)
	n.set_meta("tail_rate", 9.0)
	return n


static func make_goat() -> Node3D:
	var base: Color = GOAT_COL[randi() % GOAT_COL.size()]
	var n := _quad({
		"col": base, "col2": base.darkened(0.06), "rad": 0.4, "len": 0.8, "leg": 0.55, "head": 0.34,
		"ear": "side", "horn": "goat", "horn_col": Color("#E8D9BC"), "snout": base.lightened(0.15),
		"tail": "up", "beard": true, "tongue": randf() < 0.5, "inner": Art.C_PINK, "neck_ang": 50.0, "head_pitch": 0.2, "neck_len": 1.0,
	})
	n.set_meta("gait", 13.0)
	return n


static func make_dog() -> Node3D:
	var base: Color = Color("#E3A857") if randf() < 0.6 else Color("#B98B5E")
	var n := _quad({
		"col": base, "col2": base, "rad": 0.34, "len": 0.8, "leg": 0.55, "head": 0.34,
		"ear": "flop", "snout": Color("#F4DDB3"), "tail": "up", "tongue": true, "belly": Color("#F4DDB3"), "neck_ang": 55.0, "head_pitch": 0.1, "neck_len": 0.9,
		"inner": Art.C_PINK,
	})
	n.set_meta("gait", 16.0)
	n.set_meta("tail_rate", 16.0)
	return n


static func make_chicken() -> Node3D:
	var n := Node3D.new()
	var body_col: Color = Color("#FFFFFF") if randf() < 0.5 else Color("#E8863A")
	var bd := Art.group(n)
	bd.set_meta("y0", 0.0)
	Art.part(bd, Art.sph(0.42, 12), body_col, Vector3(0, 0.68, 0), Vector3.ZERO, true, 0.05, Vector3(0.95, 0.95, 1.2))
	for sx in [-1.0, 1.0]:
		Art.part(bd, Art.sph(0.26, 8), body_col.darkened(0.1), Vector3(float(sx) * 0.38, 0.7, -0.05), Vector3(0, 0, float(sx) * 18.0), true, 0.03, Vector3(0.35, 0.9, 1.2))
	for i in range(3):
		var s: float = float(i - 1)
		Art.part(bd, Art.cap(0.06, 0.6, 6), Color("#3FBF5A") if i == 1 else Art.C_RED, Vector3(s * 0.12, 0.95, -0.55), Vector3(-40, 0, s * 22.0), true, 0.02)
	var head := Art.group(bd, Vector3(0, 1.08, 0.42))
	head.set_meta("rx", 0.0)
	Art.part(head, Art.sph(0.24, 10), body_col, Vector3.ZERO, Vector3.ZERO, true, 0.04)
	Art.part(head, Art.cyl(0.0, 0.09, 0.22, 6), Art.C_YELLOW, Vector3(0, -0.04, 0.27), Vector3(90, 0, 0), true, 0.02)
	Art.part(head, Art.sph(0.07, 6), Art.C_RED, Vector3(0, -0.2, 0.18), Vector3.ZERO, false, 0.02, Vector3(0.8, 1.4, 0.8))
	for i in range(3):
		Art.part(head, Art.sph(0.07, 6), Art.C_RED, Vector3(0, 0.26 + 0.03 * float(i == 1), -0.04 + 0.1 * float(i - 1)), Vector3.ZERO, false)
	Art.eyes(head, 0.12, 0.07, 0.17, 0.075, 0, 1.0)
	var legs: Array = []
	for sx in [-1.0, 1.0]:
		var lg := Art.leg(n, float(sx) * 0.17, 0.4, 0.0, 0.4, 0.045, Art.C_YELLOW, Art.C_ORANGE)
		lg.set_meta("ph", 0.0 if sx < 0.0 else PI)
		lg.set_meta("amp", 0.9)
		legs.append(lg)
	n.set_meta("legs", legs)
	n.set_meta("head", head)
	n.set_meta("bob", bd)
	n.set_meta("bob_amp", 0.12)
	n.set_meta("gait", 24.0)
	return n


# ============================================================ villagers

static func _real_face(head: Node3D, skin: Color, r: float, male: bool) -> void:
	Art.part(head, Art.sph(r, 16), skin, Vector3.ZERO, Vector3.ZERO, true, 0.04, Vector3(0.86, 1.0, 0.92))
	Art.part(head, Art.sph(r * 0.55, 10), skin, Vector3(0, -r * 0.45, -r * 0.2), Vector3.ZERO, false, 0.03, Vector3(0.95, 0.9, 0.9))
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		Art.part(head, Art.sph(r * 0.16, 8), skin, Vector3(s * r * 0.84, -r * 0.03, r * 0.05), Vector3.ZERO, false, 0.02, Vector3(0.5, 1.0, 0.8))
		Art.part(head, Art.sph(r * 0.12, 8), Color("#F1E8D8"), Vector3(s * r * 0.34, r * 0.12, -r * 0.85), Vector3.ZERO, false, 0.02, Vector3(1.0, 0.7, 0.5))
		Art.part(head, Art.sph(r * 0.07, 6), Art.INK, Vector3(s * r * 0.34, r * 0.12, -r * 0.89), Vector3.ZERO, false, 0.02, Vector3(1, 1, 0.5))
		Art.part(head, Art.box(Vector3(r * 0.3, r * 0.05, r * 0.05)), Art.C_HAIR, Vector3(s * r * 0.34, r * 0.3, -r * 0.87), Vector3(0, 0, s * 8.0), false)
	Art.part(head, Art.cyl(r * 0.04, r * 0.11, r * 0.28, 6), skin.darkened(0.08), Vector3(0, -r * 0.1, -r * 0.98), Vector3(-90, 0, 0), false)
	Art.part(head, Art.box(Vector3(r * 0.3, r * 0.04, r * 0.04)), Color("#7A2230"), Vector3(0, -r * 0.42, -r * 0.84), Vector3.ZERO, false)
	if male:
		Art.part(head, Art.box(Vector3(r * 0.42, r * 0.09, r * 0.07)), Art.C_HAIR, Vector3(0, -r * 0.27, -r * 0.9), Vector3.ZERO, false)


static func make_person(female: bool) -> Node3D:
	var n := Node3D.new()
	var m := Art.group(n, Vector3.ZERO, Vector3(0, 180, 0))
	var shirt: Color = SHIRTS[randi() % SHIRTS.size()]
	var skin: Color = SKINS[randi() % SKINS.size()]
	var accent: Color = SHIRTS[randi() % SHIRTS.size()]
	var bob := Art.group(m)
	bob.set_meta("y0", 0.0)
	var legs: Array = []
	var arms: Array = []
	if female:
		var sway := Art.group(bob)
		Art.part(sway, Art.cyl(0.3, 0.62, 1.55, 14), shirt, Vector3(0, 0.78, 0), Vector3.ZERO, true, 0.06)
		Art.part(sway, Art.cyl(0.64, 0.64, 0.09, 14), accent, Vector3(0, 0.1, 0), Vector3.ZERO, false)
		Art.part(sway, Art.sph(0.3, 8), Art.C_YELLOW, Vector3(0.36, 0.78, -0.55), Vector3.ZERO, false, 0.03, Vector3(0.5, 1.4, 0.4))
		for sx in [-1.0, 1.0]:
			Art.part(sway, Art.sph(0.17, 8), Art.INK, Vector3(float(sx) * 0.24, 0.12, -0.28), Vector3.ZERO, false, 0.03, Vector3(1, 0.5, 1.5))
		n.set_meta("sway", sway)
	else:
		for sx in [-1.0, 1.0]:
			var hip := Art.group(bob, Vector3(float(sx) * 0.18, 1.15, 0.0))
			Art.part(hip, Art.cyl(0.16, 0.2, 1.15, 10), Color("#FFFFFF"), Vector3(0, -0.5, 0), Vector3.ZERO, true, 0.05)
			Art.part(hip, Art.sph(0.15, 8), Color("#C9884F"), Vector3(0, -1.12, -0.06), Vector3.ZERO, true, 0.03, Vector3(1, 0.55, 1.5))
			hip.set_meta("ph", 0.0 if sx < 0.0 else PI)
			hip.set_meta("amp", 0.6)
			legs.append(hip)
		Art.part(bob, Art.cyl(0.38, 0.4, 0.55, 12), Color("#FFFFFF"), Vector3(0, 1.25, 0), Vector3.ZERO, true, 0.05)
	var torso_col: Color = accent if not female else shirt
	Art.part(bob, Art.cap(0.42, 1.45, 12), torso_col, Vector3(0, 1.95, 0), Vector3.ZERO, true, 0.05, Vector3(1.08, 1.0, 0.66))
	Art.part(bob, Art.cyl(0.13, 0.17, 0.32, 8), skin, Vector3(0, 2.72, 0), Vector3.ZERO, false)
	if female:
		Art.part(bob, Art.cap(0.12, 1.5, 8), shirt.lightened(0.25), Vector3(-0.1, 2.05, -0.43), Vector3(0, 0, -38), false)
	else:
		Art.part(bob, Art.cap(0.1, 1.4, 8), Color("#FFF1CF"), Vector3(0.0, 2.1, -0.46), Vector3(0, 0, 40), false)
	var carry: String = "pot" if female and randf() < 0.65 else ("basket" if randf() < 0.5 else "stick")
	if not female and randf() < 0.5:
		carry = "hay"
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		var sh := Art.group(bob, Vector3(s * 0.55, 2.5, 0.0))
		_tube(sh, Vector3.ZERO, Vector3(0, -0.52, 0.0), 0.11, 0.09, torso_col, true)
		_tube(sh, Vector3(0, -0.52, 0.0), Vector3(0, -0.92, 0.04), 0.075, 0.06, skin, false, 8)
		Art.part(sh, Art.sph(0.075, 8), skin, Vector3(0, -0.97, 0.04), Vector3.ZERO, false)
		sh.set_meta("ph", PI if sx < 0.0 else 0.0)
		sh.set_meta("amp", 0.5)
		if carry == "pot" and sx > 0.0:
			sh.rotation_degrees = Vector3(0, 0, -150)
		elif carry == "stick" and sx > 0.0:
			Art.part(sh, Art.cap(0.05, 2.6, 6), Art.C_WOOD_D, Vector3(0, -0.95, -0.1), Vector3.ZERO, true, 0.03)
		else:
			arms.append(sh)
	var head := Art.group(bob, Vector3(0, 3.1, 0.0))
	head.scale = Vector3(0.66, 0.66, 0.66)
	_real_face(head, skin, 0.62, not female)
	if female:
		Art.part(head, Art.sph(0.66, 12), Art.C_HAIR, Vector3(0, 0.1, 0.14), Vector3.ZERO, false, 0.04, Vector3(1, 0.85, 1))
		Art.part(head, Art.sph(0.7, 12), shirt, Vector3(0, 0.2, 0.2), Vector3.ZERO, true, 0.05, Vector3(1.0, 0.8, 1.0))
		Art.part(head, Art.sph(0.06, 6), Art.C_RED, Vector3(0, 0.2, -0.595), Vector3.ZERO, false)
		for sx in [-1.0, 1.0]:
			Art.part(head, Art.sph(0.06, 6), Art.C_GOLD, Vector3(float(sx) * 0.62, -0.18, 0.06), Vector3.ZERO, false)
	else:
		Art.part(head, Art.sph(0.72, 12), accent.lightened(0.1), Vector3(0, 0.5, 0.12), Vector3.ZERO, true, 0.05, Vector3(1, 0.68, 1))
		Art.part(head, Art.torus(0.55, 0.78, 12), accent.darkened(0.2), Vector3(0, 0.34, 0.1), Vector3.ZERO, false, 0.03, Vector3(1.0, 0.8, 1.0))
		Art.part(head, Art.sph(0.24, 8), accent.lightened(0.28), Vector3(0, 0.95, 0.05), Vector3.ZERO, true, 0.04)
		Art.part(head, Art.box(Vector3(0.5, 0.9, 0.12)), accent.darkened(0.1), Vector3(0.12, -0.05, 0.72), Vector3(8, 0, 8), true, 0.03)
	match carry:
		"pot":
			var pot := Art.group(head, Vector3(0, 1.05, 0.15))
			Art.part(pot, Art.sph(0.52, 12), Art.C_CLAY, Vector3(0, 0.1, 0), Vector3.ZERO, true, 0.05, Vector3(1, 0.95, 1))
			Art.part(pot, Art.cyl(0.3, 0.28, 0.28, 12), Art.C_CLAY.lightened(0.1), Vector3(0, 0.62, 0), Vector3.ZERO, true, 0.04)
			Art.part(pot, Art.torus(0.25, 0.36, 12), Art.C_CLAY.darkened(0.15), Vector3(0, 0.78, 0), Vector3.ZERO, false)
			Art.part(pot, Art.cyl(0.5, 0.5, 0.06, 12), Art.C_YELLOW, Vector3(0, 0.1, 0.0), Vector3.ZERO, false, 0.02, Vector3(1.03, 1.0, 1.03))
		"basket":
			var bk := Art.group(bob, Vector3(-0.78, 1.45, -0.35))
			Art.part(bk, Art.cyl(0.4, 0.28, 0.5, 10), Color("#C99A5B"), Vector3.ZERO, Vector3.ZERO, true, 0.04)
			for i in range(4):
				Art.part(bk, Art.sph(0.16, 6), Art.C_RED if i % 2 == 0 else Art.C_LEAF, Vector3(-0.15 + 0.1 * float(i), 0.3, 0.0), Vector3.ZERO, false)
		"hay":
			Art.part(head, Art.sph(0.9, 12), Art.C_HAY, Vector3(0, 1.45, 0.1), Vector3.ZERO, true, 0.06, Vector3(1.3, 0.75, 1.0))
			Art.part(head, Art.box(Vector3(1.9, 0.07, 0.07)), Art.C_WOOD_D, Vector3(0, 1.45, 0.1), Vector3.ZERO, false)
	n.set_meta("legs", legs)
	n.set_meta("arms", arms)
	n.set_meta("head", head)
	n.set_meta("bob", bob)
	n.set_meta("bob_amp", 0.07)
	n.set_meta("gait", 7.5)
	return n


# ============================================================ obstacles

static func make_puddle() -> Node3D:
	var n := Node3D.new()
	var mud := MeshInstance3D.new()
	mud.mesh = Art.cyl(1.55, 1.55, 0.03, 16)
	mud.material_override = Art.mat(Color("#8A5A32"))
	mud.position.y = 0.05
	mud.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(mud)
	var wt := MeshInstance3D.new()
	wt.mesh = Art.cyl(1.3, 1.3, 0.03, 16)
	wt.material_override = Art.water_mat(Art.C_WATER)
	wt.position.y = 0.09
	wt.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(wt)
	var drops: Array = []
	for i in range(4):
		var d := Art.part(n, Art.sph(0.1, 6), Color("#BDEBFF"), Vector3(-0.7 + 0.45 * float(i), 0.3, 0.2 * float(i % 2) - 0.1), Vector3.ZERO, false)
		d.set_meta("y0", 0.3)
		d.set_meta("ph", float(i) * 1.3)
		drops.append(d)
	n.set_meta("drops", drops)
	return n


static func make_hay() -> Node3D:
	var n := Node3D.new()
	var spots := [Vector3(-0.55, 0.62, 0.0), Vector3(0.55, 0.62, 0.0), Vector3(0.0, 1.45, 0.0)]
	for p in spots:
		var pv: Vector3 = p
		Art.part(n, Art.cyl(0.62, 0.62, 1.05, 14), Art.C_HAY, pv, Vector3(0, 0, 90) if pv.y < 1.0 else Vector3(90, 0, 0), true, 0.06)
		Art.part(n, Art.torus(0.55, 0.66, 12), Art.C_WOOD, pv + Vector3(0, 0, 0.0), Vector3(0, 0, 90) if pv.y < 1.0 else Vector3(90, 0, 0), false)
	return n


static func make_barricade() -> Node3D:
	var n := Node3D.new()
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.box(Vector3(0.14, 1.3, 0.14)), Art.C_RIM, Vector3(float(sx) * 1.05, 0.65, 0), Vector3(0, 0, float(sx) * -6.0), true, 0.04)
		Art.part(n, Art.cyl(0.0, 0.32, 0.8, 8), Art.C_ORANGE, Vector3(float(sx) * 1.5, 0.4, 0.45), Vector3.ZERO, true, 0.04)
		Art.part(n, Art.cyl(0.16, 0.22, 0.12, 8), Color.WHITE, Vector3(float(sx) * 1.5, 0.42, 0.45), Vector3.ZERO, false, 0.02)
	for i in range(7):
		var c: Color = Art.C_RED if i % 2 == 0 else Color.WHITE
		Art.part(n, Art.box(Vector3(0.38, 0.5, 0.18)), c, Vector3(-1.14 + 0.38 * float(i), 1.08, 0), Vector3.ZERO, true, 0.03)
	for i in range(7):
		var c2: Color = Color.WHITE if i % 2 == 0 else Art.C_RED
		Art.part(n, Art.box(Vector3(0.38, 0.4, 0.18)), c2, Vector3(-1.14 + 0.38 * float(i), 0.52, 0), Vector3.ZERO, true, 0.03)
	Art.sign_board(n, Art.S_WORK, Vector3(0, 2.15, 0.0), 2.3, 0.7, Art.C_BLUE)
	Art.part(n, Art.cap(0.06, 0.9, 6), Art.C_RIM, Vector3(-0.9, 1.65, -0.02), Vector3.ZERO, false)
	Art.part(n, Art.cap(0.06, 0.9, 6), Art.C_RIM, Vector3(0.9, 1.65, -0.02), Vector3.ZERO, false)
	var lamp := Art.part(n, Art.sph(0.16, 8), Art.C_YELLOW, Vector3(0, 1.5, 0.15), Vector3.ZERO, true, 0.03)
	n.set_meta("lamp", lamp)
	return n


## Washing line strung across the lane: slide (swipe down) underneath it.
static func make_laundry() -> Node3D:
	var n := Node3D.new()
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.cap(0.09, 4.4, 6), Art.C_WOOD_D, Vector3(float(sx) * 1.65, 2.2, 0), Vector3.ZERO, true, 0.04)
		Art.part(n, Art.sph(0.16, 6), Art.C_RED, Vector3(float(sx) * 1.65, 4.45, 0), Vector3.ZERO, false)
	Art.part(n, Art.cap(0.03, 3.4, 5), Art.INK, Vector3(0, 3.7, 0), Vector3(0, 0, 90), false)
	var cols := [Art.C_PINK, Art.C_YELLOW, Art.C_TEAL, Art.C_ORANGE, Art.C_PURPLE]
	var swing: Array = []
	for i in range(5):
		var cl := Art.group(n, Vector3(-1.3 + 0.65 * float(i), 3.7, 0))
		var h: float = 1.0 + 0.45 * float(i % 3)
		Art.part(cl, Art.box(Vector3(0.52, h, 0.06)), cols[i], Vector3(0, -h * 0.5, 0), Vector3.ZERO, true, 0.03)
		Art.part(cl, Art.box(Vector3(0.1, 0.12, 0.1)), Art.C_WOOD, Vector3(0, -0.02, 0.05), Vector3.ZERO, false)
		cl.set_meta("ph", float(i) * 0.9)
		cl.set_meta("amp", 0.18)
		swing.append(cl)
	n.set_meta("legs", swing)
	n.set_meta("moving", true)
	n.set_meta("gait", 3.0)
	return n


static func make_scooter() -> Node3D:
	var n := Node3D.new()
	var lean := Art.group(n, Vector3.ZERO, Vector3(0, 0, 7))
	var col: Color = Art.C_TEAL if randf() < 0.5 else Art.C_PINK
	var wheels: Array = []
	_wheel(lean, wheels, Vector3(0, 0.42, 0.95), 0.42, 0.2, Art.C_TYRE, Art.C_METAL, 0)
	_wheel(lean, wheels, Vector3(0, 0.42, -0.95), 0.42, 0.2, Art.C_TYRE, Art.C_METAL, 0)
	Art.part(lean, Art.box(Vector3(0.62, 0.14, 1.2)), col, Vector3(0, 0.62, 0.2), Vector3.ZERO, true, 0.04)
	Art.part(lean, Art.cap(0.3, 1.1, 10), col, Vector3(0, 0.95, -0.55), Vector3(18, 0, 0), true, 0.05)
	Art.part(lean, Art.cap(0.34, 1.0, 10), col, Vector3(0, 0.9, -0.55), Vector3(-90, 0, 0), true, 0.05, Vector3(1.0, 1.0, 1.1))
	Art.part(lean, Art.box(Vector3(0.52, 0.2, 0.85)), Color("#3B2A24"), Vector3(0, 1.28, -0.45), Vector3.ZERO, true, 0.04)
	Art.part(lean, Art.cap(0.06, 1.0, 6), Art.C_METAL, Vector3(0, 1.1, 0.85), Vector3(14, 0, 0), false)
	Art.part(lean, Art.cap(0.05, 1.0, 6), Art.C_METAL, Vector3(0, 1.62, 0.78), Vector3(0, 0, 90), false)
	Art.part(lean, Art.sph(0.22, 10), Art.C_YELLOW, Vector3(0, 1.45, 1.05), Vector3.ZERO, true, 0.04, Vector3(1, 1, 0.8))
	for sx in [-1.0, 1.0]:
		Art.part(lean, Art.cap(0.025, 0.5, 5), Art.C_METAL, Vector3(float(sx) * 0.55, 1.85, 0.74), Vector3(0, 0, float(sx) * -15.0), false)
		Art.part(lean, Art.sph(0.1, 6), Art.C_METAL, Vector3(float(sx) * 0.6, 2.1, 0.74), Vector3.ZERO, false, 0.02, Vector3(1, 0.7, 0.4))
	Art.part(lean, Art.sph(0.26, 10), Art.C_RED, Vector3(0.52, 1.78, 0.78), Vector3.ZERO, true, 0.04)
	n.set_meta("wheels", wheels)
	return n


static func make_cart() -> Node3D:
	var n := Node3D.new()
	var wheels: Array = []
	var yoke_z: float = 3.2
	for sx in [-1.0, 1.0]:
		var ox := make_ox()
		ox.position = Vector3(float(sx) * 0.62, 0, yoke_z)
		ox.scale = Vector3(0.62, 0.62, 0.62)
		n.add_child(ox)
	Art.part(n, Art.cap(0.07, 1.8, 6), Art.C_WOOD_D, Vector3(0, 1.75, yoke_z - 0.15), Vector3(0, 0, 90), true, 0.03)
	Art.part(n, Art.cap(0.08, 3.4, 6), Art.C_WOOD, Vector3(0, 0.95, 1.3), Vector3(90, 0, 0), true, 0.03)
	Art.part(n, Art.box(Vector3(2.6, 0.2, 3.0)), Art.C_WOOD, Vector3(0, 1.0, -0.6), Vector3.ZERO, true, 0.05)
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.box(Vector3(0.12, 0.7, 3.0)), Art.C_WOOD_D, Vector3(float(sx) * 1.28, 1.35, -0.6), Vector3.ZERO, true, 0.04)
		var w := Art.group(n, Vector3(float(sx) * 1.42, 0.8, -0.5))
		w.set_meta("r", 0.8)
		Art.part(w, Art.torus(0.66, 0.84, 14), Art.C_WOOD_D, Vector3.ZERO, Vector3(0, 0, 90), true, 0.04)
		for i in range(6):
			Art.part(w, Art.box(Vector3(0.1, 1.5, 0.09)), Art.C_WOOD, Vector3.ZERO, Vector3(rad_to_deg(PI * float(i) / 6.0), 0, 0), false)
		Art.part(w, Art.cyl(0.18, 0.18, 0.28, 8), Art.C_METAL, Vector3.ZERO, Vector3(0, 0, 90), false)
		wheels.append(w)
	Art.part(n, Art.sph(1.55, 14), Art.C_HAY, Vector3(0, 2.1, -0.6), Vector3.ZERO, true, 0.07, Vector3(0.95, 0.72, 1.15))
	for i in range(5):
		Art.part(n, Art.cap(0.04, 0.9, 5), Art.C_HAY.darkened(0.15), Vector3(-0.9 + 0.45 * float(i), 3.0, -0.2 + 0.2 * float(i % 3)), Vector3(20.0 * float(i - 2), 0, 15.0 * float(i - 2)), false)
	n.set_meta("wheels", wheels)
	return n


static func make_tractor() -> Node3D:
	var n := Node3D.new()
	var wheels: Array = []
	var red: Color = Color("#E8412F")
	Art.part(n, Art.cap(0.62, 2.4, 12), red, Vector3(0, 1.65, 0.65), Vector3(90, 0, 0), true, 0.06, Vector3(1.0, 1.0, 1.0))
	Art.part(n, Art.box(Vector3(1.3, 0.28, 1.0)), Color("#2F2A33"), Vector3(0, 2.2, 1.55), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.box(Vector3(1.4, 0.9, 1.5)), red, Vector3(0, 1.9, -0.9), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(1.0, 0.16, 0.9)), Color("#3B2A24"), Vector3(0, 2.5, -1.05), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.box(Vector3(0.86, 0.7, 0.14)), Color("#3B2A24"), Vector3(0, 2.9, -1.45), Vector3(-10, 0, 0), true, 0.04)
	Art.part(n, Art.cap(0.03, 0.8, 5), Art.C_METAL, Vector3(0, 2.4, -0.1), Vector3(-30, 0, 0), false)
	Art.part(n, Art.torus(0.18, 0.3, 12), Art.INK, Vector3(0, 2.75, -0.35), Vector3(-30, 0, 0), false)
	Art.part(n, Art.cyl(0.1, 0.1, 1.1, 8), Art.C_METAL, Vector3(0.45, 2.7, 1.1), Vector3.ZERO, true, 0.03)
	Art.part(n, Art.cyl(0.18, 0.1, 0.12, 8), Art.INK, Vector3(0.45, 3.3, 1.1), Vector3.ZERO, false)
	for i in range(5):
		Art.part(n, Art.box(Vector3(0.9, 0.08, 0.06)), Art.C_METAL, Vector3(0, 1.3 + 0.13 * float(i), 1.9), Vector3.ZERO, false)
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.sph(0.2, 8), Art.C_YELLOW, Vector3(float(sx) * 0.55, 1.95, 1.9), Vector3.ZERO, true, 0.04, Vector3(1, 1, 0.7))
		_wheel(n, wheels, Vector3(float(sx) * 1.0, 1.0, -0.9), 1.0, 0.55, Art.C_TYRE, Art.C_YELLOW, 12)
		_wheel(n, wheels, Vector3(float(sx) * 0.75, 0.6, 1.55), 0.6, 0.38, Art.C_TYRE, Art.C_YELLOW, 10)
	n.set_meta("wheels", wheels)
	return n


static func make_bus() -> Node3D:
	var n := Node3D.new()
	var wheels: Array = []
	var cols := [Art.C_ORANGE, Art.C_BLUE, Art.C_PINK, Art.C_TEAL]
	var body: Color = cols[randi() % cols.size()]
	Art.part(n, Art.box(Vector3(4.3, 2.0, 8.6)), body, Vector3(0, 1.75, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.box(Vector3(4.3, 1.5, 8.6)), Art.C_CREAM, Vector3(0, 3.5, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.box(Vector3(4.34, 0.22, 8.64)), Art.C_YELLOW, Vector3(0, 2.8, 0), Vector3.ZERO, false)
	Art.part(n, Art.box(Vector3(3.8, 1.05, 0.12)), Color("#27465E"), Vector3(0, 3.5, 4.32), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.box(Vector3(0.1, 1.05, 0.14)), Art.INK, Vector3(0, 3.5, 4.34), Vector3.ZERO, false)
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.box(Vector3(0.12, 0.9, 7.6)), Color("#27465E"), Vector3(float(sx) * 2.16, 3.5, 0), Vector3.ZERO, false)
		Art.part(n, Art.sph(0.3, 8), Art.C_YELLOW, Vector3(float(sx) * 1.55, 1.3, 4.33), Vector3.ZERO, true, 0.05, Vector3(1, 1, 0.6))
		Art.part(n, Art.box(Vector3(0.12, 0.5, 0.2)), Art.C_RIM, Vector3(float(sx) * 2.3, 3.5, 4.2), Vector3.ZERO, false)
		Art.part(n, Art.cap(0.05, 0.9, 5), Art.C_METAL, Vector3(float(sx) * 2.35, 3.2, 4.15), Vector3.ZERO, false)
		for zz in [-2.6, 2.8]:
			_wheel(n, wheels, Vector3(float(sx) * 1.95, 0.75, float(zz)), 0.75, 0.55, Art.C_TYRE, Art.C_METAL, 0)
	Art.part(n, Art.box(Vector3(4.4, 0.35, 0.5)), Art.C_METAL, Vector3(0, 0.7, 4.5), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.box(Vector3(2.4, 0.6, 0.1)), Art.C_YELLOW, Vector3(0, 1.0, 4.34), Vector3.ZERO, true, 0.03)
	for i in range(11):
		var gc: Color = Art.C_ORANGE if i % 2 == 0 else Art.C_YELLOW
		Art.part(n, Art.sph(0.17, 6), gc, Vector3(-1.7 + 0.34 * float(i), 4.05 + 0.05 * sin(float(i) * 0.6), 4.4), Vector3.ZERO, true, 0.03)
	Art.sign_board(n, Art.S_BUS, Vector3(0, 4.55, 4.32), 3.0, 0.62, Art.C_RED)
	Art.part(n, Art.box(Vector3(3.4, 0.7, 4.2)), Color("#C99A5B"), Vector3(0, 4.6, -1.0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.box(Vector3(2.8, 0.5, 2.2)), Art.C_RED, Vector3(0.2, 5.1, -0.6), Vector3.ZERO, true, 0.05)
	n.set_meta("wheels", wheels)
	return n
