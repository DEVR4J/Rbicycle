extends RefCounted
## Core procedural art: materials, primitive meshes, faces, the two riders and
## the collectibles. Everything is built from code (no external assets).

const TOON := preload("res://shaders/toon.gdshader")
const OUTLINE := preload("res://shaders/outline.gdshader")
const GLOW := preload("res://shaders/glow.gdshader")
const TEXS := preload("res://shaders/toon_tex.gdshader")
const WATER := preload("res://shaders/water.gdshader")

static var font: Font = null
static var outlines: bool = true
static var sign_tex: Dictionary = {}
static var _mats: Dictionary = {}
static var _omats: Dictionary = {}
static var _meshes: Dictionary = {}
static var _gmats: Dictionary = {}
static var _tmats: Dictionary = {}

# Signboard texts (the same strings are baked into textures by signs.gd)
const S_WORK := "कार्य प्रगति पर है"
const S_CHAI := "चाय की दुकान"
const S_WELCOME := "स्वागतम्"
const S_SWEET := "मिठाई वाला"
const S_VEG := "सब्ज़ी मंडी"
const S_PUNCTURE := "पंचर बनता है"
const S_KIRANA := "किराना स्टोर"
const S_RAM := "राम राम जी"
const S_HAIR := "बाल कटिंग"
const S_BUS := "राज ट्रैवल्स"

# Bright, saturated palette
const INK := Color("#2B1B14")
const C_TYRE := Color("#2E2A33")
const C_RIM := Color("#F0EBDD")
const C_METAL := Color("#C9CFD6")
const C_PINK := Color("#FF5C93")
const C_ORANGE := Color("#FF8A2B")
const C_PURPLE := Color("#8E5CF0")
const C_TEAL := Color("#18C4B8")
const C_YELLOW := Color("#FFCB2F")
const C_RED := Color("#E83F3F")
const C_BLUE := Color("#3E7BFA")
const C_SKY := Color("#5CC8FF")
const C_GREEN := Color("#3FBF5A")
const C_LEAF := Color("#2FAE4E")
const C_LEAF_L := Color("#6FD35B")
const C_LEAF_D := Color("#1F8A45")
const C_WOOD := Color("#A5642E")
const C_WOOD_D := Color("#6F4222")
const C_HAY := Color("#F2C94C")
const C_CLAY := Color("#D9663A")
const C_CREAM := Color("#FFF1CF")
const C_HAIR := Color("#2B1D18")
const C_WATER := Color("#33B8F0")
const C_STONE := Color("#E8D9BC")
const C_GOLD := Color("#FFB81F")
const C_GOLD_L := Color("#FFE07A")


# ------------------------------------------------------------ materials

static func mat(c: Color) -> ShaderMaterial:
	var key := c.to_html()
	if _mats.has(key):
		return _mats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = TOON
	m.set_shader_parameter("albedo", c)
	_mats[key] = m
	return m


static func outline_mat(mesh: Mesh, lw: float) -> ShaderMaterial:
	var hs: Vector3 = mesh.get_aabb().size * 0.5
	var key := "%.3f,%.3f,%.3f,%.3f" % [hs.x, hs.y, hs.z, lw]
	if _omats.has(key):
		return _omats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = OUTLINE
	m.set_shader_parameter("half_size", Vector3(maxf(hs.x, 0.01), maxf(hs.y, 0.01), maxf(hs.z, 0.01)))
	m.set_shader_parameter("line_width", lw)
	_omats[key] = m
	return m


static func glow_mat(c: Color, intensity: float = 0.6) -> ShaderMaterial:
	var key := "%s_%.2f" % [c.to_html(), intensity]
	if _gmats.has(key):
		return _gmats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = GLOW
	m.set_shader_parameter("glow_color", c)
	m.set_shader_parameter("intensity", intensity)
	_gmats[key] = m
	return m


static func water_mat(c: Color) -> ShaderMaterial:
	var key := "w" + c.to_html()
	if _mats.has(key):
		return _mats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = WATER
	m.set_shader_parameter("water_color", c)
	_mats[key] = m
	return m


static func tex_mat(t: Texture2D) -> ShaderMaterial:
	var key: int = t.get_instance_id()
	if _tmats.has(key):
		return _tmats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = TEXS
	m.set_shader_parameter("tex", t)
	_tmats[key] = m
	return m


# ------------------------------------------------------------ meshes

static func box(s: Vector3) -> Mesh:
	var k := "b%s" % str(s)
	if not _meshes.has(k):
		var m := BoxMesh.new()
		m.size = s
		_meshes[k] = m
	return _meshes[k] as Mesh


static func cyl(rt: float, rb: float, h: float, seg: int = 12) -> Mesh:
	var k := "c%.3f_%.3f_%.3f_%d" % [rt, rb, h, seg]
	if not _meshes.has(k):
		var m := CylinderMesh.new()
		m.top_radius = rt
		m.bottom_radius = rb
		m.height = h
		m.radial_segments = seg
		m.rings = 1
		_meshes[k] = m
	return _meshes[k] as Mesh


static func sph(r: float, seg: int = 12) -> Mesh:
	var k := "s%.3f_%d" % [r, seg]
	if not _meshes.has(k):
		var m := SphereMesh.new()
		m.radius = r
		m.height = r * 2.0
		m.radial_segments = seg
		m.rings = maxi(seg / 2, 3)
		_meshes[k] = m
	return _meshes[k] as Mesh


static func cap(r: float, h: float, seg: int = 10) -> Mesh:
	var k := "k%.3f_%.3f_%d" % [r, h, seg]
	if not _meshes.has(k):
		var m := CapsuleMesh.new()
		m.radius = r
		m.height = maxf(h, r * 2.0 + 0.01)
		m.radial_segments = seg
		m.rings = 4
		_meshes[k] = m
	return _meshes[k] as Mesh


static func prism(s: Vector3) -> Mesh:
	var k := "p%s" % str(s)
	if not _meshes.has(k):
		var m := PrismMesh.new()
		m.size = s
		m.left_to_right = 0.5
		_meshes[k] = m
	return _meshes[k] as Mesh


static func torus(inner: float, outer: float, seg: int = 12) -> Mesh:
	var k := "t%.3f_%.3f_%d" % [inner, outer, seg]
	if not _meshes.has(k):
		var m := TorusMesh.new()
		m.inner_radius = inner
		m.outer_radius = outer
		m.rings = seg
		m.ring_segments = 8
		_meshes[k] = m
	return _meshes[k] as Mesh


static func quad(w: float, h: float) -> Mesh:
	var k := "q%.3f_%.3f" % [w, h]
	if not _meshes.has(k):
		var m := QuadMesh.new()
		m.size = Vector2(w, h)
		_meshes[k] = m
	return _meshes[k] as Mesh


# ------------------------------------------------------------ building blocks

static func part(parent: Node3D, mesh: Mesh, color: Color, pos: Vector3 = Vector3.ZERO, rot: Vector3 = Vector3.ZERO, outline: bool = true, lw: float = 0.05, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat(color)
	mi.position = pos
	mi.rotation_degrees = rot
	mi.scale = scl
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	if outline and outlines:
		var o := MeshInstance3D.new()
		o.mesh = mesh
		o.material_override = outline_mat(mesh, lw)
		o.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.add_child(o)
	return mi


static func group(parent: Node3D, pos: Vector3 = Vector3.ZERO, rot: Vector3 = Vector3.ZERO) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	n.rotation_degrees = rot
	parent.add_child(n)
	return n


## A leg pivot (swings from the hip) with a capsule and a hoof/shoe.
static func leg(parent: Node3D, x: float, y: float, z: float, length: float, r: float, color: Color, hoof: Color = C_HAIR) -> Node3D:
	var p := group(parent, Vector3(x, y, z))
	part(p, cap(r, length), color, Vector3(0, -length * 0.5, 0), Vector3.ZERO, false)
	part(p, sph(r * 1.05, 8), hoof, Vector3(0, -length + r * 0.3, r * 0.2), Vector3.ZERO, false, 0.03, Vector3(1, 0.7, 1.3))
	return p


## Cartoon eyes for animals. fz = +1 when the animal faces +Z (towards camera).
## mode: 0 normal, 1 sleepy (closed), 2 angry.
static func eyes(parent: Node3D, x: float, y: float, z: float, r: float, mode: int = 0, fz: float = 1.0) -> void:
	for sx in [-1.0, 1.0]:
		var ex: float = x * float(sx)
		if mode == 1:
			part(parent, box(Vector3(r * 1.8, r * 0.3, r * 0.4)), INK, Vector3(ex, y, z), Vector3(0, 0, float(sx) * -12.0), false)
			continue
		part(parent, sph(r, 8), Color.WHITE, Vector3(ex, y, z), Vector3.ZERO, false, 0.03, Vector3(1, 1.1, 0.7))
		part(parent, sph(r * 0.55, 6), INK, Vector3(ex, y - r * 0.05, z + fz * r * 0.45), Vector3.ZERO, false, 0.03, Vector3(1, 1, 0.5))
		part(parent, sph(r * 0.18, 5), Color.WHITE, Vector3(ex - r * 0.12, y + r * 0.2, z + fz * r * 0.75), Vector3.ZERO, false, 0.02)
		if mode == 2:
			part(parent, box(Vector3(r * 2.0, r * 0.35, r * 0.4)), INK, Vector3(ex, y + r * 1.1, z + fz * r * 0.2), Vector3(0, 0, float(sx) * -24.0), false)


static func sign_board(parent: Node3D, text: String, pos: Vector3, w: float, h: float, frame: Color = C_WOOD_D) -> void:
	part(parent, box(Vector3(w + 0.2, h + 0.2, 0.12)), frame, pos + Vector3(0, 0, -0.07), Vector3.ZERO, true, 0.03)
	if sign_tex.has(text):
		var mi := MeshInstance3D.new()
		mi.mesh = quad(w, h)
		mi.material_override = tex_mat(sign_tex[text] as Texture2D)
		mi.position = pos
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(mi)
	else:
		part(parent, box(Vector3(w, h, 0.05)), C_YELLOW, pos, Vector3.ZERO, false)


# ------------------------------------------------------------ faces

## Builds the face on the -Z side of a head of radius r. Returns node refs.
static func make_face(head: Node3D, skin: Color, r: float, male: bool) -> Dictionary:
	var f := {}
	part(head, sph(r, 16), skin, Vector3.ZERO, Vector3.ZERO, true, 0.05)
	for sx in [-1.0, 1.0]:
		part(head, sph(0.14, 8), skin, Vector3(float(sx) * r * 0.97, -0.02, 0.06), Vector3.ZERO, false, 0.03)
		part(head, sph(0.09, 6), C_RED.lightened(0.2), Vector3(float(sx) * 0.4, -0.13, -0.44), Vector3.ZERO, false, 0.02, Vector3(1, 0.7, 0.4))
	var eye_l := part(head, sph(0.16, 10), Color.WHITE, Vector3(-0.25, 0.08, -0.52), Vector3.ZERO, false, 0.03, Vector3(1, 1.1, 0.6))
	var eye_r := part(head, sph(0.16, 10), Color.WHITE, Vector3(0.25, 0.08, -0.52), Vector3.ZERO, false, 0.03, Vector3(1, 1.1, 0.6))
	var pup_l := part(head, sph(0.085, 8), INK, Vector3(-0.25, 0.07, -0.585), Vector3.ZERO, false, 0.02, Vector3(1, 1, 0.5))
	var pup_r := part(head, sph(0.085, 8), INK, Vector3(0.25, 0.07, -0.585), Vector3.ZERO, false, 0.02, Vector3(1, 1, 0.5))
	part(head, sph(0.03, 5), Color.WHITE, Vector3(-0.28, 0.11, -0.62), Vector3.ZERO, false, 0.02)
	part(head, sph(0.03, 5), Color.WHITE, Vector3(0.22, 0.11, -0.62), Vector3.ZERO, false, 0.02)
	var brow_l := part(head, box(Vector3(0.22, 0.05, 0.05)), INK, Vector3(-0.25, 0.28, -0.53), Vector3(0, 0, 10), false)
	var brow_r := part(head, box(Vector3(0.22, 0.05, 0.05)), INK, Vector3(0.25, 0.28, -0.53), Vector3(0, 0, -10), false)
	part(head, sph(0.1, 8), skin.darkened(0.1), Vector3(0, -0.07, -0.6), Vector3.ZERO, false, 0.03, Vector3(1, 1, 0.8))
	var mouth := part(head, sph(0.1, 8), Color("#8A1F2E"), Vector3(0, -0.27, -0.53), Vector3.ZERO, false, 0.03, Vector3(1.4, 0.45, 0.5))
	if male:
		part(head, cap(0.06, 0.34, 6), C_HAIR, Vector3(0, -0.16, -0.6), Vector3(0, 0, 90), false)
	f["eye_l"] = eye_l
	f["eye_r"] = eye_r
	f["pup_l"] = pup_l
	f["pup_r"] = pup_r
	f["brow_l"] = brow_l
	f["brow_r"] = brow_r
	f["mouth"] = mouth
	f["male"] = male
	return f


static func set_mood(f: Dictionary, mood: String) -> void:
	if f.is_empty():
		return
	var mouth: Node3D = f["mouth"]
	var brow_l: Node3D = f["brow_l"]
	var brow_r: Node3D = f["brow_r"]
	var eye_l: Node3D = f["eye_l"]
	var eye_r: Node3D = f["eye_r"]
	var pup_l: Node3D = f["pup_l"]
	var pup_r: Node3D = f["pup_r"]
	var male: bool = f["male"]
	var my: float = -0.27
	match mood:
		"happy":
			mouth.scale = Vector3(2.0, 0.8, 0.5)
			my = -0.25
			brow_l.position.y = 0.31
			brow_r.position.y = 0.31
			eye_l.scale = Vector3(1.0, 1.1, 0.6)
			eye_r.scale = Vector3(1.0, 1.1, 0.6)
			pup_l.scale = Vector3(1.0, 1.0, 0.5)
			pup_r.scale = Vector3(1.0, 1.0, 0.5)
		"scared":
			mouth.scale = Vector3(1.0, 1.9, 0.5)
			my = -0.32
			brow_l.position.y = 0.36
			brow_r.position.y = 0.36
			eye_l.scale = Vector3(1.3, 1.45, 0.6)
			eye_r.scale = Vector3(1.3, 1.45, 0.6)
			pup_l.scale = Vector3(0.6, 0.6, 0.5)
			pup_r.scale = Vector3(0.6, 0.6, 0.5)
		"dizzy":
			mouth.scale = Vector3(1.3, 0.7, 0.5)
			my = -0.28
			brow_l.position.y = 0.3
			brow_r.position.y = 0.26
			eye_l.scale = Vector3(1.1, 1.2, 0.6)
			eye_r.scale = Vector3(1.1, 1.2, 0.6)
			pup_l.scale = Vector3(0.5, 0.5, 0.5)
			pup_r.scale = Vector3(1.3, 1.3, 0.5)
		_:
			mouth.scale = Vector3(1.4, 0.45, 0.5)
			brow_l.position.y = 0.28
			brow_r.position.y = 0.28
			eye_l.scale = Vector3(1.0, 1.1, 0.6)
			eye_r.scale = Vector3(1.0, 1.1, 0.6)
			pup_l.scale = Vector3(1.0, 1.0, 0.5)
			pup_r.scale = Vector3(1.0, 1.0, 0.5)
	mouth.position.y = my
	if male:
		pass


# ------------------------------------------------------------ riders

## cfg: female, shirt, pants, frame, skin, accent (Colors).
## Returns: root, wheels, body, head, face, hip_l, hip_r, knee_l, knee_r, shield, trail
static func make_rider(cfg: Dictionary) -> Dictionary:
	var female: bool = cfg["female"]
	var shirt: Color = cfg["shirt"]
	var pants: Color = cfg["pants"]
	var frame: Color = cfg["frame"]
	var skin: Color = cfg["skin"]
	var accent: Color = cfg["accent"]
	var out := {}
	var root := Node3D.new()
	var wheels: Array = []

	for zz in [-0.95, 0.95]:
		var w := group(root, Vector3(0.0, 0.55, float(zz)))
		part(w, cyl(0.55, 0.55, 0.14, 18), C_TYRE, Vector3.ZERO, Vector3(0, 0, 90), true, 0.05)
		part(w, cyl(0.42, 0.42, 0.16, 18), C_RIM, Vector3.ZERO, Vector3(0, 0, 90), false)
		part(w, box(Vector3(0.1, 0.9, 0.05)), frame.lightened(0.35), Vector3.ZERO, Vector3.ZERO, false)
		part(w, box(Vector3(0.1, 0.05, 0.9)), frame.lightened(0.35), Vector3.ZERO, Vector3.ZERO, false)
		wheels.append(w)

	# frame
	part(root, cap(0.07, 1.5, 8), frame, Vector3(0, 1.1, -0.1), Vector3(-90, 0, 0), false)
	part(root, cap(0.07, 1.28, 8), frame, Vector3(0, 1.15, -0.35), Vector3(128.7, 0, 0), false)
	part(root, cap(0.06, 0.7, 8), frame, Vector3(0, 1.07, 0.25), Vector3(17, 0, 0), false)
	part(root, cap(0.05, 0.96, 8), frame, Vector3(0, 0.93, 0.65), Vector3(141, 0, 0), false)
	part(root, cap(0.06, 1.0, 8), frame, Vector3(0, 1.05, -0.9), Vector3(-174, 0, 0), false)
	part(root, cap(0.05, 0.4, 8), C_METAL, Vector3(0, 1.72, -0.85), Vector3.ZERO, false)
	part(root, cap(0.05, 1.05, 8), C_METAL, Vector3(0, 1.8, -0.85), Vector3(0, 0, 90), false)
	part(root, sph(0.09, 8), C_METAL, Vector3(0.3, 1.93, -0.85), Vector3.ZERO, false)
	part(root, cyl(0.2, 0.2, 0.06, 10), C_METAL, Vector3(0, 0.75, 0.15), Vector3(0, 0, 90), false)
	part(root, sph(0.2, 8), Color("#4A2C1E"), Vector3(0, 1.45, 0.4), Vector3.ZERO, true, 0.04, Vector3(1, 0.4, 1.4))
	part(root, box(Vector3(0.5, 0.06, 0.5)), C_METAL, Vector3(0, 1.28, 1.05), Vector3.ZERO, false)
	part(root, box(Vector3(0.75, 0.4, 0.55)), Color("#D9A85B"), Vector3(0, 1.5, -1.4), Vector3.ZERO, true, 0.04)
	part(root, sph(0.09, 8), C_GOLD_L, Vector3(0, 1.62, -1.0), Vector3.ZERO, false)
	for sx in [-1.0, 1.0]:
		var tx: float = 0.55 * float(sx)
		part(root, cap(0.035, 0.34, 6), C_PINK if sx < 0.0 else C_YELLOW, Vector3(tx, 1.62, -0.85), Vector3(0, 0, float(sx) * 15.0), false)

	# upper body (rotates and tucks while sliding)
	var body := group(root, Vector3(0.0, 1.4, 0.2))
	part(body, cap(0.4, 1.15, 12), shirt, Vector3(0, 0.52, -0.05), Vector3(-18, 0, 0), true, 0.05)
	part(body, sph(0.38, 10), pants, Vector3(0, 0.0, 0.05), Vector3.ZERO, true, 0.05, Vector3(1.1, 0.7, 1.1))
	part(body, cyl(0.15, 0.18, 0.22, 8), skin, Vector3(0, 1.05, -0.12), Vector3.ZERO, false)
	for sx in [-1.0, 1.0]:
		var ax: float = 0.435 * float(sx)
		part(body, cap(0.13, 1.0, 8), shirt, Vector3(ax, 0.675, -0.625), Vector3(-123, 0, 0), true, 0.04)
		part(body, sph(0.13, 8), skin, Vector3(0.45 * float(sx), 0.4, -1.05), Vector3.ZERO, false)

	# head
	var head := group(body, Vector3(0, 1.3, -0.12))
	var face := make_face(head, skin, 0.62, not female)
	if female:
		part(head, sph(0.66, 12), C_HAIR, Vector3(0, 0.1, 0.13), Vector3.ZERO, false, 0.04, Vector3(1, 0.85, 1))
		part(head, sph(0.27, 8), C_HAIR, Vector3(0, 0.55, 0.45), Vector3.ZERO, true, 0.04)
		part(head, sph(0.15, 8), C_YELLOW, Vector3(0.22, 0.62, 0.5), Vector3.ZERO, false)
		part(head, sph(0.16, 8), C_HAIR, Vector3(0, 0.0, 0.66), Vector3.ZERO, false, 0.03, Vector3(1, 1.3, 1))
		part(head, sph(0.14, 8), C_HAIR, Vector3(0, -0.4, 0.7), Vector3.ZERO, false, 0.03, Vector3(1, 1.3, 1))
		part(head, sph(0.12, 8), C_HAIR, Vector3(0, -0.75, 0.7), Vector3.ZERO, false, 0.03, Vector3(1, 1.3, 1))
		part(head, sph(0.09, 6), C_RED, Vector3(0, -0.95, 0.7), Vector3.ZERO, false)
		part(head, sph(0.045, 6), C_RED, Vector3(0, 0.2, -0.595), Vector3.ZERO, false)
		for sx in [-1.0, 1.0]:
			part(head, sph(0.06, 6), C_GOLD, Vector3(float(sx) * 0.62, -0.18, 0.06), Vector3.ZERO, false)
	else:
		part(head, sph(0.7, 12), accent, Vector3(0, 0.5, 0.14), Vector3.ZERO, true, 0.05, Vector3(1, 0.65, 1))
		part(head, sph(0.26, 8), accent.lightened(0.25), Vector3(0, 0.88, 0.1), Vector3.ZERO, true, 0.04)
		part(head, box(Vector3(0.45, 0.9, 0.1)), accent.darkened(0.12), Vector3(0.12, -0.05, 0.7), Vector3(8, 0, 8), true, 0.03)
		part(head, torus(0.05, 0.1, 12), C_GOLD, Vector3(0, 0.45, -0.52), Vector3(90, 0, 0), false, 0.02, Vector3(2.2, 2.2, 2.2))
		part(head, sph(0.16, 8), C_GOLD, Vector3(0, 0.72, -0.5), Vector3.ZERO, false)
		part(head, cap(0.05, 0.3, 6), C_YELLOW, Vector3(0, 0.0, -0.01), Vector3(0, 0, 90), false)

	# legs (pedalling)
	var hips: Array = []
	var knees: Array = []
	for sx in [-1.0, 1.0]:
		var hip := group(root, Vector3(0.22 * float(sx), 1.35, 0.3))
		part(hip, cap(0.16, 0.75, 8), pants, Vector3(0, -0.35, 0), Vector3.ZERO, true, 0.04)
		var knee := group(hip, Vector3(0, -0.7, 0))
		part(knee, cap(0.14, 0.75, 8), pants, Vector3(0, -0.35, 0), Vector3.ZERO, true, 0.04)
		part(knee, sph(0.18, 8), accent, Vector3(0, -0.74, -0.06), Vector3.ZERO, true, 0.04, Vector3(1, 0.7, 1.5))
		hips.append(hip)
		knees.append(knee)

	# shield bubble and speed trail
	var shield := MeshInstance3D.new()
	shield.mesh = sph(2.3, 16)
	shield.material_override = glow_mat(Color("#55D4FF"), 0.9)
	shield.position = Vector3(0, 1.9, 0)
	shield.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	shield.visible = false
	root.add_child(shield)
	var trail := CPUParticles3D.new()
	trail.emitting = false
	trail.amount = 36
	trail.lifetime = 0.55
	trail.direction = Vector3(0, 0.1, 1)
	trail.spread = 22.0
	trail.initial_velocity_min = 12.0
	trail.initial_velocity_max = 20.0
	trail.gravity = Vector3.ZERO
	trail.position = Vector3(0, 1.2, 1.6)
	var tm := SphereMesh.new()
	tm.radius = 0.14
	tm.height = 0.28
	tm.radial_segments = 6
	tm.rings = 3
	var tmat := StandardMaterial3D.new()
	tmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	tmat.albedo_color = Color("#FFB347")
	tm.material = tmat
	trail.mesh = tm
	root.add_child(trail)

	out["root"] = root
	out["wheels"] = wheels
	out["body"] = body
	out["head"] = head
	out["face"] = face
	out["hip_l"] = hips[0]
	out["hip_r"] = hips[1]
	out["knee_l"] = knees[0]
	out["knee_r"] = knees[1]
	out["shield"] = shield
	out["trail"] = trail
	return out


# ------------------------------------------------------------ collectibles

static func make_coin(y: float = 1.2) -> Node3D:
	var n := Node3D.new()
	n.position.y = y
	var c := group(n, Vector3.ZERO, Vector3(90, 0, 0))
	part(c, cyl(0.5, 0.5, 0.12, 16), C_GOLD, Vector3.ZERO, Vector3.ZERO, true, 0.04)
	part(c, cyl(0.36, 0.36, 0.15, 16), C_GOLD_L, Vector3.ZERO, Vector3.ZERO, false)
	part(c, cyl(0.16, 0.16, 0.18, 8), C_GOLD, Vector3.ZERO, Vector3.ZERO, false)
	n.set_meta("anim", "spin")
	return n


static func make_shield_pickup() -> Node3D:
	var n := Node3D.new()
	n.position.y = 1.6
	var s := group(n)
	part(s, sph(0.62, 12), Color("#2E7BFF"), Vector3.ZERO, Vector3.ZERO, true, 0.05, Vector3(1, 1.15, 0.35))
	part(s, sph(0.46, 10), Color("#8FD1FF"), Vector3(0, 0, -0.06), Vector3.ZERO, false, 0.03, Vector3(1, 1.15, 0.3))
	part(s, box(Vector3(0.12, 0.5, 0.06)), Color.WHITE, Vector3(0, 0.02, -0.2), Vector3.ZERO, false)
	part(s, box(Vector3(0.4, 0.12, 0.06)), Color.WHITE, Vector3(0, 0.08, -0.2), Vector3.ZERO, false)
	var halo := MeshInstance3D.new()
	halo.mesh = sph(1.0, 12)
	halo.material_override = glow_mat(Color("#55D4FF"), 0.8)
	halo.name = "halo"
	halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(halo)
	n.set_meta("anim", "pickup")
	n.set_meta("spin_node", s)
	return n


static func make_boost_pickup() -> Node3D:
	var n := Node3D.new()
	n.position.y = 1.6
	var s := group(n)
	part(s, cyl(0.42, 0.28, 0.62, 12), Color("#C9572B"), Vector3.ZERO, Vector3.ZERO, true, 0.05)
	part(s, cyl(0.38, 0.38, 0.05, 12), Color("#7A3B1E"), Vector3(0, 0.3, 0), Vector3.ZERO, false)
	part(s, cyl(0.44, 0.44, 0.06, 12), Color("#E3774A"), Vector3(0, 0.33, 0), Vector3.ZERO, false)
	for i in range(3):
		part(s, sph(0.1 + 0.02 * float(i), 6), Color(1, 1, 1), Vector3(-0.1 + 0.1 * float(i), 0.6 + 0.2 * float(i), 0), Vector3.ZERO, false)
	part(s, box(Vector3(0.18, 0.4, 0.05)), C_YELLOW, Vector3(0, -0.02, -0.4), Vector3(0, 0, 18), false)
	var halo := MeshInstance3D.new()
	halo.mesh = sph(1.0, 12)
	halo.material_override = glow_mat(Color("#FF9A3D"), 0.8)
	halo.name = "halo"
	halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(halo)
	n.set_meta("anim", "pickup")
	n.set_meta("spin_node", s)
	return n
