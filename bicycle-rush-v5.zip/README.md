# Bicycle Rush (साइकिल रश)

2-player co-op Android TV endless runner, Indian village theme, Hindi banter.
Phones are the controllers (same Wi-Fi): open the address shown on the TV in the phone browser.

Build: push this repo to GitHub, open Actions > "Build APK" > Run workflow, download artifact `bicycle-rush-apk`.
Test on PC: arrows = P1, WASD = P2, P = pause, Q = quality.
Phone: swipe left/right = lane, up = jump, down = slide.
