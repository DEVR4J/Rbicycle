# Bicycle Rush (साइकिल रश)

2-player co-op Android TV endless runner, Indian village theme, Hindi banter.
Phones are the controllers (same Wi-Fi): open the address shown on the TV in the phone browser.

Build: push this repo to GitHub, open Actions > "Build APK" > Run workflow, download artifact `bicycle-rush-apk`.
Test on PC: arrows = P1, WASD = P2, P = pause, Q = quality.
Phone: swipe left/right = lane, up = jump, down = slide.

Animal models (cow, horse, pig, pug, sheep): "Farm Animals Pack" by Quaternius, CC0 (see models/License.txt).

Vehicle models (bus, trucks, cars, autos, bikes): "Bus Simulator India - Traffic Cars" by Villanueva-Jonatan-32621, CC BY 4.0, https://sketchfab.com/3d-models/bus-simulator-india-traffic-cars-a0c72a6277bf4301bb3e5db4ccb194b6 (see models/vehicles/license.txt). Tata truck: decimated from the supplied OBJ.
