shader_type spatial;
render_mode unshaded, cull_back;

// Cartoon water: flat colour with drifting foam shimmer. Curved like the world.

uniform vec4 water_color : source_color = vec4(0.2, 0.72, 0.94, 1.0);
uniform vec4 foam_color : source_color = vec4(0.85, 0.97, 1.0, 1.0);

const float CURVE = 0.00012;
const float START = 12.0;

varying vec3 wpos;

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	float w = sin(wpos.x * 2.6 + TIME * 1.4) * sin(wpos.z * 2.1 - TIME * 1.1);
	float k = smoothstep(0.55, 0.9, w);
	ALBEDO = mix(water_color.rgb, foam_color.rgb, k * 0.55);
}
