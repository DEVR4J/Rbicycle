extends RefCounted
## Endless roadside scenery, built as 42 m long "chunks" so the world keeps
## changing: village, farm, market, pond and bridge. All procedural.

const Art := preload("res://scripts/art.gd")
const Props := preload("res://scripts/props.gd")

const CHUNK_LEN := 42.0
const ROAD_HALF := 6.75

## 1.0 = full detail, lower = fewer small props (for weak TVs).
static var density: float = 1.0

const PLASTER := [
	Color("#FF7FA8"), Color("#2FD0C6"), Color("#FFC53D"), Color("#9BE04F"),
	Color("#FF9440"), Color("#B79BFF"), Color("#6EC8FF"), Color("#FF6B5B"),
]
const MUD := Color("#D9A066")
const SOIL := Color("#B97A45")
const GRASS_A := Color("#46C65A")
const GRASS_B := Color("#37AE4C")
const MUSTARD := Color("#FFD93B")

const KINDS := ["village", "farm", "market", "pond", "bridge"]
const WEIGHTS := {"village": 4.0, "farm": 3.0, "market": 2.0, "pond": 2.0, "bridge": 1.2}


static func next_kind(prev: String) -> String:
	var total := 0.0
	for k in KINDS:
		if k != prev:
			total += float(WEIGHTS[k])
	var r: float = randf() * total
	for k in KINDS:
		if k == prev:
			continue
		r -= float(WEIGHTS[k])
		if r <= 0.0:
			return k
	return "village"


static func animate_chunk(chunk: Node3D, t: float, dt: float, speed: float) -> void:
	var list: Array = chunk.get_meta("anim", [])
	for v in list:
		var nd: Node3D = v
		if is_instance_valid(nd):
			Props.animate(nd, t, dt, speed)


# ============================================================ chunk builder

static func build_chunk(kind: String) -> Node3D:
	var root := Node3D.new()
	root.set_meta("len", CHUNK_LEN)
	root.set_meta("kind", "scenery")
	var anim: Array = []
	root.set_meta("anim", anim)
	_poles(root)
	_roadside(root)
	match kind:
		"village":
			_village(root)
		"farm":
			_farm(root)
		"market":
			_market(root)
		"pond":
			_pond(root)
		"bridge":
			_bridge(root)
	_far(root, kind)
	return root


static func _anim(root: Node3D, n: Node3D) -> void:
	var a: Array = root.get_meta("anim")
	a.append(n)


static func _place(root: Node3D, n: Node3D, x: float, z: float, face: bool = true, jitter: float = 8.0) -> void:
	n.position = Vector3(x, n.position.y, z)
	if face:
		n.rotation_degrees.y = (-90.0 if x > 0.0 else 90.0) + randf_range(-jitter, jitter)
	else:
		n.rotation_degrees.y = randf() * 360.0
	root.add_child(n)


static func _side_x(side: float, lo: float, hi: float) -> float:
	return side * randf_range(lo, hi)


# ============================================================ poles, wires, roadside

static func _poles(root: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		for z in [-14.0, 0.0, 14.0]:
			var p := Node3D.new()
			p.position = Vector3(s * 7.9, 0, float(z))
			Art.part(p, Art.cyl(0.13, 0.2, 6.6, 6), Art.C_WOOD_D, Vector3(0, 3.3, 0), Vector3.ZERO, true, 0.05)
			Art.part(p, Art.box(Vector3(2.4, 0.14, 0.14)), Art.C_WOOD, Vector3(0, 5.9, 0), Vector3.ZERO, true, 0.04)
			for ix in [-1.0, 0.0, 1.0]:
				Art.part(p, Art.cyl(0.07, 0.09, 0.2, 6), Art.C_RIM, Vector3(float(ix) * 0.95, 6.1, 0), Vector3.ZERO, false)
			if randf() < 0.5 and density >= 0.9:
				Art.part(p, Art.box(Vector3(0.7, 0.5, 0.1)), Art.C_YELLOW, Vector3(0, 3.3, 0.18), Vector3.ZERO, true, 0.03)
			root.add_child(p)
			for ix in [-1.0, 0.0, 1.0]:
				var w := Art.part(root, Art.cap(0.025, 14.0, 4), Art.INK, Vector3(s * 7.9 + float(ix) * 0.95, 6.0 - 0.08 * absf(float(ix)), float(z) + 7.0), Vector3(90, 0, 0), false)
				w.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


static func _roadside(root: Node3D) -> void:
	var count: int = int(14.0 * density)
	for i in range(count):
		var s: float = 1.0 if randf() < 0.5 else -1.0
		var x: float = s * randf_range(7.1, 8.4)
		var z: float = randf_range(-20.0, 20.0)
		var r: float = randf()
		var n := Node3D.new()
		if r < 0.4:
			Art.part(n, Art.sph(randf_range(0.35, 0.6), 8), Art.C_LEAF if randf() < 0.5 else Art.C_LEAF_L, Vector3(0, 0.35, 0), Vector3.ZERO, true, 0.04, Vector3(1.2, 0.8, 1.2))
		elif r < 0.7:
			for k in range(3):
				Art.part(n, Art.sph(0.14, 6), Art.C_ORANGE if k != 1 else Art.C_YELLOW, Vector3(-0.2 + 0.2 * float(k), 0.4 + 0.05 * float(k % 2), 0), Vector3.ZERO, false)
				Art.part(n, Art.cyl(0.0, 0.1, 0.35, 5), Art.C_LEAF_D, Vector3(-0.2 + 0.2 * float(k), 0.17, 0), Vector3.ZERO, false)
		else:
			for k in range(4):
				Art.part(n, Art.cyl(0.0, 0.09, 0.55, 5), Art.C_LEAF_L, Vector3(-0.25 + 0.17 * float(k), 0.27, 0.05 * float(k % 2)), Vector3(0, 0, 14.0 * float(k - 1)), false)
		n.position = Vector3(x, 0, z)
		root.add_child(n)


# ============================================================ items

static func make_house(rich: bool = true) -> Node3D:
	var n := Node3D.new()
	var wall: Color = PLASTER[randi() % PLASTER.size()]
	var trim: Color = wall.darkened(0.28)
	Art.part(n, Art.box(Vector3(4.6, 2.7, 4.4)), wall, Vector3(0, 1.35, 0), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(4.68, 0.5, 4.48)), trim, Vector3(0, 0.25, 0), Vector3.ZERO, false)
	Art.part(n, Art.prism(Vector3(5.8, 1.9, 5.6)), Art.C_CLAY, Vector3(0, 3.65, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.cap(0.12, 5.6, 6), Art.C_CLAY.darkened(0.2), Vector3(0, 4.6, 0), Vector3(90, 0, 0), false)
	Art.part(n, Art.box(Vector3(1.0, 1.7, 0.12)), Art.C_WOOD_D, Vector3(0, 0.95, 2.24), Vector3.ZERO, true, 0.03)
	Art.part(n, Art.cyl(0.5, 0.5, 0.12, 10), Art.C_WOOD_D, Vector3(0, 1.8, 2.24), Vector3(90, 0, 0), false)
	for sx in [-1.0, 1.0]:
		var wx: float = float(sx) * 1.55
		Art.part(n, Art.box(Vector3(0.95, 1.0, 0.1)), Color("#243B55"), Vector3(wx, 1.65, 2.23), Vector3.ZERO, false)
		Art.part(n, Art.box(Vector3(0.42, 1.0, 0.12)), Art.C_SKY, Vector3(wx - 0.33, 1.65, 2.28), Vector3.ZERO, false)
		Art.part(n, Art.box(Vector3(0.42, 1.0, 0.12)), Art.C_SKY, Vector3(wx + 0.33, 1.65, 2.28), Vector3.ZERO, false)
	if rich:
		Art.part(n, Art.box(Vector3(5.0, 0.12, 1.5)), trim, Vector3(0, 2.55, 3.05), Vector3.ZERO, true, 0.04)
		for sx in [-1.0, 1.0]:
			Art.part(n, Art.cyl(0.1, 0.1, 2.5, 6), Art.C_WOOD, Vector3(float(sx) * 2.2, 1.25, 3.65), Vector3.ZERO, false)
		for i in range(7):
			Art.part(n, Art.sph(0.1, 5), Art.C_ORANGE if i % 2 == 0 else Art.C_YELLOW, Vector3(-0.9 + 0.3 * float(i), 2.25 - 0.1 * sin(PI * float(i) / 6.0), 2.34), Vector3.ZERO, false)
		Art.part(n, Art.cyl(0.38, 0.45, 0.4, 8), Art.C_STONE, Vector3(-1.7, 0.2, 3.5), Vector3.ZERO, true, 0.03)
		Art.part(n, Art.sph(0.32, 6), Art.C_LEAF, Vector3(-1.7, 0.65, 3.5), Vector3.ZERO, false)
		if randf() < 0.45:
			Art.sign_board(n, Art.S_RAM, Vector3(0, 2.5, 2.27), 1.5, 0.42, Art.C_RED)
		if randf() < 0.5:
			var cot := Art.group(n, Vector3(1.5, 0.0, 3.7))
			Art.part(cot, Art.box(Vector3(1.6, 0.1, 0.9)), Art.C_WOOD, Vector3(0, 0.55, 0), Vector3.ZERO, true, 0.03)
			Art.part(cot, Art.box(Vector3(1.4, 0.04, 0.75)), Art.C_TEAL, Vector3(0, 0.62, 0), Vector3.ZERO, false)
			for sx in [-0.7, 0.7]:
				for sz in [-0.4, 0.4]:
					Art.part(cot, Art.cyl(0.05, 0.05, 0.5, 5), Art.C_WOOD_D, Vector3(float(sx), 0.27, float(sz)), Vector3.ZERO, false)
	return n


static func make_hut() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(1.9, 2.0, 1.9, 12), MUD.lightened(0.08), Vector3(0, 0.95, 0), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.cyl(0.0, 2.6, 1.9, 12), Art.C_HAY.darkened(0.1), Vector3(0, 2.85, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.box(Vector3(0.9, 1.4, 0.1)), Art.C_WOOD_D, Vector3(0, 0.7, 1.93), Vector3.ZERO, false)
	Art.part(n, Art.torus(0.7, 1.0, 12), Art.C_RED, Vector3(0, 0.05, 2.4), Vector3(0, 0, 0), false, 0.02, Vector3(1.0, 0.1, 1.0))
	return n


static func make_temple() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.box(Vector3(5.0, 0.4, 5.0)), Art.C_STONE, Vector3(0, 0.2, 0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.box(Vector3(4.2, 0.4, 4.2)), Art.C_STONE.darkened(0.06), Vector3(0, 0.6, 0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.box(Vector3(3.0, 2.2, 3.0)), Art.C_PINK, Vector3(0, 1.9, 0), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(3.2, 0.2, 3.2)), Art.C_YELLOW, Vector3(0, 3.1, 0), Vector3.ZERO, false)
	Art.part(n, Art.cyl(0.0, 1.9, 1.5, 8), Art.C_ORANGE, Vector3(0, 3.95, 0), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.cyl(0.0, 1.25, 1.3, 8), Art.C_RED, Vector3(0, 5.1, 0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.sph(0.3, 8), Art.C_GOLD, Vector3(0, 5.9, 0), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.box(Vector3(1.0, 1.5, 0.12)), Color("#2B1B14"), Vector3(0, 1.55, 1.52), Vector3.ZERO, false)
	Art.part(n, Art.cyl(0.0, 0.2, 0.4, 6), Art.C_GOLD, Vector3(0, 2.5, 1.55), Vector3.ZERO, false)
	Art.part(n, Art.cap(0.05, 3.2, 5), Art.C_WOOD, Vector3(1.9, 3.6, 0), Vector3.ZERO, false)
	Art.part(n, Art.prism(Vector3(1.1, 0.7, 0.05)), Art.C_ORANGE, Vector3(2.4, 4.9, 0), Vector3(0, 0, -90), false)
	for i in range(5):
		Art.part(n, Art.sph(0.1, 5), Art.C_ORANGE if i % 2 == 0 else Art.C_YELLOW, Vector3(-1.0 + 0.5 * float(i), 2.9 - 0.08 * sin(PI * float(i) / 4.0), 1.55), Vector3.ZERO, false)
	return n


static func make_pump() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.box(Vector3(1.6, 0.25, 1.6)), Art.C_STONE, Vector3(0, 0.12, 0), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.cyl(0.18, 0.22, 1.5, 8), Art.C_BLUE, Vector3(0, 1.0, 0), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.sph(0.3, 8), Art.C_BLUE.darkened(0.1), Vector3(0, 1.85, 0), Vector3.ZERO, true, 0.04, Vector3(1, 0.8, 1.3))
	Art.part(n, Art.cap(0.06, 1.3, 6), Art.C_METAL, Vector3(0, 2.2, 0.4), Vector3(-65, 0, 0), true, 0.03)
	Art.part(n, Art.sph(0.12, 6), Art.C_RED, Vector3(0, 2.55, 0.95), Vector3.ZERO, false)
	Art.part(n, Art.cap(0.07, 0.5, 6), Art.C_BLUE, Vector3(0, 1.6, 0.3), Vector3(-80, 0, 0), false)
	Art.part(n, Art.cyl(0.3, 0.24, 0.45, 8), Art.C_ORANGE, Vector3(0.6, 0.45, 0.6), Vector3.ZERO, true, 0.04)
	var pd := MeshInstance3D.new()
	pd.mesh = Art.cyl(0.55, 0.55, 0.03, 12)
	pd.material_override = Art.water_mat(Art.C_WATER)
	pd.position = Vector3(0, 0.27, 0.0)
	pd.scale = Vector3(1.0, 1.0, 1.0)
	n.add_child(pd)
	return n


static func make_chai_stall() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.box(Vector3(4.2, 2.4, 2.4)), Art.C_TEAL, Vector3(0, 1.2, -0.8), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(5.0, 0.18, 3.6)), Art.C_BLUE, Vector3(0, 2.75, 0.0), Vector3(7, 0, 0), true, 0.05)
	for i in range(6):
		Art.part(n, Art.box(Vector3(0.05, 0.06, 3.5)), Art.C_BLUE.lightened(0.25), Vector3(-2.1 + 0.84 * float(i), 2.86, 0.0), Vector3(7, 0, 0), false)
	Art.part(n, Art.box(Vector3(3.8, 0.95, 0.9)), Art.C_WOOD, Vector3(0, 0.48, 1.0), Vector3.ZERO, true, 0.05)
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.cyl(0.07, 0.07, 2.8, 6), Art.C_WOOD_D, Vector3(float(sx) * 2.0, 1.4, 1.55), Vector3.ZERO, false)
	Art.part(n, Art.cyl(0.32, 0.38, 0.45, 10), Art.C_METAL, Vector3(-0.8, 1.2, 1.0), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.sph(0.34, 8), Art.C_METAL, Vector3(-0.8, 1.55, 1.0), Vector3.ZERO, true, 0.04, Vector3(1, 0.6, 1))
	Art.part(n, Art.cap(0.05, 0.5, 5), Art.C_METAL, Vector3(-0.4, 1.6, 1.0), Vector3(0, 0, -65), false)
	Art.part(n, Art.sph(0.16, 6), Color("#FFB347"), Vector3(-0.8, 0.98, 1.0), Vector3.ZERO, false)
	for i in range(4):
		Art.part(n, Art.cyl(0.09, 0.07, 0.2, 6), Color("#F7E6C0"), Vector3(0.2 + 0.3 * float(i), 1.1, 1.0), Vector3.ZERO, false)
	for i in range(8):
		var pc: Color = Art.C_RED if i % 3 == 0 else (Art.C_YELLOW if i % 3 == 1 else Art.C_PINK)
		Art.part(n, Art.box(Vector3(0.3, 0.45, 0.06)), pc, Vector3(-1.5 + 0.43 * float(i), 2.35, 1.45), Vector3.ZERO, false)
	Art.part(n, Art.box(Vector3(2.4, 0.12, 0.7)), Art.C_WOOD, Vector3(0.2, 0.45, 2.3), Vector3.ZERO, true, 0.04)
	Art.sign_board(n, Art.S_CHAI, Vector3(0, 3.5, 1.9), 3.0, 0.75, Art.C_WOOD_D)
	return n


static func make_shop(text: String) -> Node3D:
	var n := Node3D.new()
	var wall: Color = PLASTER[randi() % PLASTER.size()]
	Art.part(n, Art.box(Vector3(4.6, 3.0, 3.6)), wall, Vector3(0, 1.5, 0), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(3.2, 1.9, 0.12)), Color("#3A2A33"), Vector3(0, 1.1, 1.82), Vector3.ZERO, false)
	for i in range(7):
		Art.part(n, Art.box(Vector3(0.72, 0.3, 1.7)), Color.WHITE if i % 2 == 0 else Art.C_RED, Vector3(-2.16 + 0.72 * float(i), 2.35, 2.5), Vector3(24, 0, 0), true, 0.03)
	Art.part(n, Art.box(Vector3(3.4, 0.9, 0.7)), Art.C_WOOD, Vector3(0, 0.45, 2.0), Vector3.ZERO, true, 0.04)
	for i in range(9):
		var c: Color = [Art.C_YELLOW, Art.C_PINK, Art.C_ORANGE, Art.C_TEAL, Art.C_RED][i % 5]
		Art.part(n, Art.sph(0.17, 6), c, Vector3(-1.4 + 0.35 * float(i), 1.0, 2.0), Vector3.ZERO, false)
	for i in range(6):
		var pc: Color = [Art.C_RED, Art.C_YELLOW, Art.C_GREEN][i % 3]
		Art.part(n, Art.box(Vector3(0.3, 0.45, 0.06)), pc, Vector3(-1.4 + 0.55 * float(i), 1.9, 1.78), Vector3.ZERO, false)
	Art.sign_board(n, text, Vector3(0, 3.35, 1.85), 3.4, 0.8, Art.C_RED)
	Art.part(n, Art.sph(0.45, 8), Art.C_HAY, Vector3(-2.0, 0.4, 2.6), Vector3.ZERO, true, 0.04, Vector3(1, 0.9, 1))
	Art.part(n, Art.sph(0.42, 8), Art.C_STONE, Vector3(-1.4, 0.38, 2.7), Vector3.ZERO, true, 0.04, Vector3(1, 0.9, 1))
	return n


static func make_puncture_shop() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.box(Vector3(3.6, 2.3, 2.6)), Art.C_YELLOW.darkened(0.05), Vector3(0, 1.15, -0.2), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(4.2, 0.16, 2.2)), Art.C_RED, Vector3(0, 2.6, 0.8), Vector3(8, 0, 0), true, 0.05)
	for i in range(4):
		Art.part(n, Art.torus(0.28, 0.5, 10), Art.C_TYRE, Vector3(1.3, 0.2 + 0.28 * float(i), 1.3), Vector3.ZERO, true, 0.03)
	Art.part(n, Art.torus(0.5, 0.9, 12), Art.C_TYRE, Vector3(-1.3, 1.0, 1.5), Vector3(90, 0, 0), true, 0.04)
	Art.part(n, Art.cyl(0.35, 0.3, 0.7, 8), Art.C_BLUE, Vector3(0, 0.35, 1.5), Vector3.ZERO, true, 0.04)
	Art.sign_board(n, Art.S_PUNCTURE, Vector3(0, 3.1, 1.0), 3.0, 0.7, Art.C_BLUE)
	return n


static func make_barber() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.box(Vector3(3.4, 2.4, 2.4)), Art.C_LEAF_L.darkened(0.05), Vector3(0, 1.2, -0.2), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.box(Vector3(2.2, 1.5, 0.1)), Art.C_SKY.lightened(0.3), Vector3(0, 1.3, 1.02), Vector3.ZERO, false)
	Art.part(n, Art.cyl(0.35, 0.35, 0.2, 8), Art.C_RED, Vector3(1.0, 0.5, 1.6), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.cap(0.22, 0.8, 8), Art.C_BLUE, Vector3(1.0, 1.0, 1.6), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.cyl(0.12, 0.12, 1.0, 8), Color.WHITE, Vector3(-1.9, 1.4, 1.2), Vector3.ZERO, true, 0.03)
	for i in range(4):
		Art.part(n, Art.box(Vector3(0.26, 0.1, 0.26)), Art.C_RED, Vector3(-1.9, 1.0 + 0.25 * float(i), 1.2), Vector3(0, 30.0 * float(i), 0), false)
	Art.sign_board(n, Art.S_HAIR, Vector3(0, 2.75, 1.05), 2.6, 0.62, Art.C_ORANGE)
	return n


static func make_neem() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(0.35, 0.55, 2.8, 8), Art.C_WOOD_D, Vector3(0, 1.4, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.sph(2.0, 7), Art.C_LEAF, Vector3(0, 4.1, 0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.sph(1.4, 7), Art.C_LEAF_L, Vector3(1.5, 3.5, 0.5), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.sph(1.5, 7), Art.C_LEAF_L, Vector3(-1.4, 3.7, -0.4), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.sph(1.1, 7), Art.C_LEAF_D, Vector3(0.3, 5.2, -0.2), Vector3.ZERO, true, 0.08)
	return n


static func make_mango() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(0.4, 0.6, 2.2, 8), Art.C_WOOD_D, Vector3(0, 1.1, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.sph(2.3, 7), Art.C_LEAF_D, Vector3(0, 3.8, 0), Vector3.ZERO, true, 0.05, Vector3(1.1, 0.9, 1.1))
	for i in range(6):
		var a: float = TAU * float(i) / 6.0
		Art.part(n, Art.sph(0.17, 6), Art.C_YELLOW if i % 2 == 0 else Art.C_ORANGE, Vector3(cos(a) * 1.9, 3.2 + 0.4 * float(i % 3), sin(a) * 1.9), Vector3.ZERO, false)
	return n


static func make_banyan(with_seat: bool = true) -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(0.8, 1.15, 3.8, 9), Art.C_WOOD_D, Vector3(0, 1.9, 0), Vector3.ZERO, true, 0.09)
	for i in range(5):
		var a: float = TAU * float(i) / 5.0
		Art.part(n, Art.sph(2.0 + 0.4 * float(i % 2), 7), Art.C_LEAF if i % 2 == 0 else Art.C_LEAF_L, Vector3(cos(a) * 2.5, 5.2 + 0.4 * float(i % 3), sin(a) * 2.5), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.sph(2.6, 7), Art.C_LEAF_D, Vector3(0, 6.2, 0), Vector3.ZERO, true, 0.05)
	for i in range(7):
		var a2: float = TAU * float(i) / 7.0
		Art.part(n, Art.cap(0.05, 3.4, 5), Art.C_WOOD, Vector3(cos(a2) * 2.3, 3.4, sin(a2) * 2.3), Vector3.ZERO, false)
	if with_seat:
		Art.part(n, Art.cyl(2.0, 2.1, 0.5, 14), Art.C_STONE, Vector3(0, 0.25, 0), Vector3.ZERO, true, 0.06)
		Art.part(n, Art.cyl(1.0, 1.15, 0.52, 10), Art.C_WOOD_D, Vector3(0, 0.27, 0), Vector3.ZERO, false)
		Art.part(n, Art.prism(Vector3(0.6, 0.5, 0.1)), Art.C_ORANGE, Vector3(1.4, 1.3, 1.3), Vector3.ZERO, false)
	return n


static func make_banana() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(0.2, 0.3, 2.4, 8), Color("#9CCB6A"), Vector3(0, 1.2, 0), Vector3.ZERO, true, 0.05)
	for i in range(6):
		var a: float = TAU * float(i) / 6.0
		var lf := Art.group(n, Vector3(0, 2.4, 0), Vector3(0, rad_to_deg(a), 0))
		Art.part(lf, Art.box(Vector3(0.6, 0.05, 2.4)), Art.C_LEAF_L if i % 2 == 0 else Art.C_LEAF, Vector3(0, 0.15, 1.1), Vector3(-26, 0, 0), true, 0.04)
	for i in range(5):
		Art.part(n, Art.cap(0.1, 0.6, 5), Art.C_YELLOW, Vector3(0.3 + 0.09 * float(i), 1.9, 0.15 * float(i % 2)), Vector3(0, 0, -20), false)
	return n


static func make_palm() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cap(0.26, 5.5, 8), Color("#B58A5A"), Vector3(0.3, 2.7, 0), Vector3(0, 0, -6), true, 0.06)
	for i in range(7):
		var a: float = TAU * float(i) / 7.0
		var fr := Art.group(n, Vector3(0.6, 5.5, 0), Vector3(0, rad_to_deg(a), 0))
		Art.part(fr, Art.box(Vector3(0.55, 0.06, 2.6)), Art.C_LEAF if i % 2 == 0 else Art.C_LEAF_L, Vector3(0, -0.15, 1.2), Vector3(22, 0, 0), true, 0.04)
	Art.part(n, Art.sph(0.2, 6), Art.C_YELLOW.darkened(0.1), Vector3(0.7, 5.2, 0.3), Vector3.ZERO, false)
	Art.part(n, Art.sph(0.2, 6), Art.C_YELLOW.darkened(0.1), Vector3(0.45, 5.15, -0.25), Vector3.ZERO, false)
	return n


static func make_haystack() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(0.9, 1.8, 2.4, 12), Art.C_HAY, Vector3(0, 1.2, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.sph(0.95, 10), Art.C_HAY, Vector3(0, 2.4, 0), Vector3.ZERO, true, 0.07)
	Art.part(n, Art.cap(0.04, 1.2, 5), Art.C_WOOD_D, Vector3(0.1, 3.4, 0), Vector3(0, 0, 10), false)
	return n


static func make_scarecrow() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cap(0.07, 3.2, 5), Art.C_WOOD_D, Vector3(0, 1.6, 0), Vector3.ZERO, false)
	Art.part(n, Art.cap(0.07, 2.4, 5), Art.C_WOOD_D, Vector3(0, 2.3, 0), Vector3(0, 0, 90), false)
	Art.part(n, Art.cap(0.4, 1.2, 8), Art.C_PINK, Vector3(0, 2.2, 0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.sph(0.5, 8), Art.C_CLAY, Vector3(0, 3.35, 0), Vector3.ZERO, true, 0.05)
	Art.part(n, Art.cyl(0.0, 0.7, 0.6, 8), Art.C_YELLOW, Vector3(0, 3.95, 0), Vector3.ZERO, true, 0.04)
	Art.part(n, Art.sph(0.07, 5), Art.INK, Vector3(-0.17, 3.4, 0.45), Vector3.ZERO, false)
	Art.part(n, Art.sph(0.07, 5), Art.INK, Vector3(0.17, 3.4, 0.45), Vector3.ZERO, false)
	Art.part(n, Art.box(Vector3(0.3, 0.05, 0.05)), Art.INK, Vector3(0, 3.2, 0.48), Vector3.ZERO, false)
	return n


static func make_well() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(1.0, 1.1, 0.9, 12), Art.C_STONE, Vector3(0, 0.45, 0), Vector3.ZERO, true, 0.06)
	var wt := MeshInstance3D.new()
	wt.mesh = Art.cyl(0.75, 0.75, 0.03, 12)
	wt.material_override = Art.water_mat(Art.C_WATER)
	wt.position.y = 0.88
	n.add_child(wt)
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.cap(0.07, 2.6, 5), Art.C_WOOD_D, Vector3(float(sx) * 0.9, 1.7, 0), Vector3.ZERO, true, 0.03)
	Art.part(n, Art.cap(0.06, 2.0, 5), Art.C_WOOD, Vector3(0, 2.9, 0), Vector3(0, 0, 90), false)
	Art.part(n, Art.cyl(0.2, 0.15, 0.3, 8), Art.C_ORANGE, Vector3(0, 2.4, 0), Vector3.ZERO, true, 0.03)
	return n


static func make_bicycle() -> Node3D:
	var n := Node3D.new()
	var lean := Art.group(n, Vector3.ZERO, Vector3(0, 0, 9))
	var col: Color = [Art.C_RED, Art.C_BLUE, Art.C_GREEN, Art.C_PURPLE][randi() % 4]
	for zz in [-0.8, 0.8]:
		Art.part(lean, Art.cyl(0.5, 0.5, 0.1, 14), Art.C_TYRE, Vector3(0, 0.5, float(zz)), Vector3(0, 0, 90), true, 0.04)
		Art.part(lean, Art.cyl(0.38, 0.38, 0.12, 14), Art.C_RIM, Vector3(0, 0.5, float(zz)), Vector3(0, 0, 90), false)
	Art.part(lean, Art.cap(0.05, 1.5, 5), col, Vector3(0, 0.95, 0), Vector3(90, 0, 0), false)
	Art.part(lean, Art.cap(0.05, 1.2, 5), col, Vector3(0, 0.95, 0.4), Vector3(40, 0, 0), false)
	Art.part(lean, Art.cap(0.05, 0.9, 5), col, Vector3(0, 1.05, -0.7), Vector3(-10, 0, 0), false)
	Art.part(lean, Art.cap(0.04, 1.0, 5), Art.C_METAL, Vector3(0, 1.5, -0.78), Vector3(0, 0, 90), false)
	Art.part(lean, Art.box(Vector3(0.28, 0.08, 0.5)), Art.INK, Vector3(0, 1.45, 0.5), Vector3.ZERO, false)
	Art.part(lean, Art.cyl(0.3, 0.25, 0.35, 8), Color("#C99A5B"), Vector3(0, 1.25, -1.05), Vector3.ZERO, true, 0.03)
	return n


static func make_duck() -> Node3D:
	var n := Node3D.new()
	var b := Art.group(n)
	b.set_meta("y0", 0.0)
	Art.part(b, Art.sph(0.32, 8), Color.WHITE, Vector3(0, 0.22, 0), Vector3.ZERO, true, 0.03, Vector3(1, 0.8, 1.35))
	Art.part(b, Art.sph(0.2, 8), Color.WHITE, Vector3(0, 0.55, 0.3), Vector3.ZERO, true, 0.03)
	Art.part(b, Art.box(Vector3(0.14, 0.06, 0.2)), Art.C_ORANGE, Vector3(0, 0.52, 0.5), Vector3.ZERO, false)
	Art.part(b, Art.sph(0.04, 4), Art.INK, Vector3(-0.1, 0.6, 0.42), Vector3.ZERO, false)
	Art.part(b, Art.sph(0.04, 4), Art.INK, Vector3(0.1, 0.6, 0.42), Vector3.ZERO, false)
	n.set_meta("bob", b)
	n.set_meta("moving", true)
	n.set_meta("gait", 2.4)
	n.set_meta("bob_amp", 0.06)
	return n


static func make_lotus() -> Node3D:
	var n := Node3D.new()
	Art.part(n, Art.cyl(0.55, 0.55, 0.05, 10), Art.C_LEAF, Vector3(0, 0.08, 0), Vector3.ZERO, false)
	if randf() < 0.6:
		for i in range(5):
			var a: float = TAU * float(i) / 5.0
			Art.part(n, Art.cyl(0.0, 0.16, 0.4, 5), Art.C_PINK, Vector3(cos(a) * 0.15, 0.3, sin(a) * 0.15), Vector3(sin(a) * 25.0, 0, -cos(a) * 25.0), false)
	return n


static func make_bus_stop() -> Node3D:
	var n := Node3D.new()
	var bus := Props.make_bus()
	bus.position = Vector3(0, 0, 0)
	n.add_child(bus)
	var sh := Art.group(n, Vector3(-4.6, 0, 1.0))
	Art.part(sh, Art.box(Vector3(2.6, 0.18, 2.0)), Art.C_BLUE, Vector3(0, 3.0, 0), Vector3.ZERO, true, 0.05)
	for sx in [-1.0, 1.0]:
		Art.part(sh, Art.cyl(0.07, 0.07, 3.0, 6), Art.C_METAL, Vector3(float(sx) * 1.2, 1.5, -0.8), Vector3.ZERO, false)
	Art.part(sh, Art.box(Vector3(2.0, 0.12, 0.6)), Art.C_WOOD, Vector3(0, 0.6, -0.8), Vector3.ZERO, true, 0.03)
	return n


static func make_stall() -> Node3D:
	var n := Node3D.new()
	var c: Color = [Art.C_RED, Art.C_YELLOW, Art.C_TEAL, Art.C_PINK, Art.C_ORANGE][randi() % 5]
	Art.part(n, Art.box(Vector3(3.2, 0.9, 1.4)), Art.C_WOOD, Vector3(0, 0.45, 0), Vector3.ZERO, true, 0.05)
	for sx in [-1.0, 1.0]:
		Art.part(n, Art.cyl(0.06, 0.06, 3.2, 6), Art.C_WOOD_D, Vector3(float(sx) * 1.5, 1.6, -0.5), Vector3.ZERO, false)
	Art.part(n, Art.cyl(0.0, 2.4, 0.9, 8), c, Vector3(0, 3.5, -0.2), Vector3.ZERO, true, 0.06)
	Art.part(n, Art.cyl(2.45, 2.45, 0.2, 8), c.lightened(0.35), Vector3(0, 3.05, -0.2), Vector3.ZERO, false)
	var heap: Array = [Art.C_RED, Art.C_YELLOW, Art.C_ORANGE, Art.C_GREEN, Art.C_PURPLE]
	for i in range(5):
		var hc: Color = heap[i]
		Art.part(n, Art.sph(0.34, 8), hc, Vector3(-1.2 + 0.6 * float(i), 1.1, 0.1), Vector3.ZERO, true, 0.03, Vector3(1, 0.7, 1))
	return n


static func make_child() -> Node3D:
	var p := Props.make_person(randf() < 0.5)
	p.scale = Vector3(0.58, 0.58, 0.58)
	p.set_meta("hop", true)
	p.set_meta("ph", randf() * 6.0)
	return p


static func make_waver(female: bool) -> Node3D:
	var p := Props.make_person(female)
	p.scale = Vector3(0.9, 0.9, 0.9)
	var arms: Array = p.get_meta("arms", [])
	if arms.size() > 0:
		p.set_meta("wave", arms[arms.size() - 1])
	p.set_meta("ph", randf() * 6.0)
	return p


# ============================================================ slot logic

static func _item(key: String) -> Node3D:
	match key:
		"house":
			return make_house(density >= 0.9)
		"hut":
			return make_hut()
		"temple":
			return make_temple()
		"pump":
			return make_pump()
		"chai":
			return make_chai_stall()
		"kirana":
			return make_shop(Art.S_KIRANA)
		"mithai":
			return make_shop(Art.S_SWEET)
		"sabzi":
			return make_shop(Art.S_VEG)
		"puncture":
			return make_puncture_shop()
		"barber":
			return make_barber()
		"neem":
			return make_neem()
		"mango":
			return make_mango()
		"banyan":
			return make_banyan(true)
		"banana":
			return make_banana()
		"palm":
			return make_palm()
		"haystack":
			return make_haystack()
		"scarecrow":
			return make_scarecrow()
		"well":
			return make_well()
		"stall":
			return make_stall()
	return make_neem()


static func _add_life(root: Node3D, x: float, z: float, key: String) -> void:
	var s: float = 1.0 if x > 0.0 else -1.0
	var n: Node3D = null
	match key:
		"wave_m":
			n = make_waver(false)
		"wave_f":
			n = make_waver(true)
		"kids":
			for i in range(2):
				var k := make_child()
				_place(root, k, x - s * (1.0 + 1.2 * float(i)), z + 1.5 * float(i))
				_anim(root, k)
			return
		"goat":
			n = Props.make_goat()
			n.scale = Vector3(0.9, 0.9, 0.9)
		"cow":
			n = Props.make_cow()
			n.scale = Vector3(0.8, 0.8, 0.8)
		"buffalo":
			n = Props.make_buffalo(1)
			n.scale = Vector3(0.8, 0.8, 0.8)
		"dog":
			n = Props.make_dog()
		"chicken":
			n = Props.make_chicken()
		"bicycle":
			n = make_bicycle()
		"cart":
			n = Props.make_cart()
			n.scale = Vector3(0.8, 0.8, 0.8)
		"tractor":
			n = Props.make_tractor()
			n.scale = Vector3(0.85, 0.85, 0.85)
	if n == null:
		return
	_place(root, n, x, z)
	_anim(root, n)


static func _fill(root: Node3D, table: Array, extras: Array) -> void:
	var slots := [-17.0, -8.5, 0.0, 8.5, 17.0]
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		for z in slots:
			var key: String = table[randi() % table.size()]
			if key == "":
				continue
			var item := _item(key)
			var x: float = s * randf_range(10.8, 12.6)
			if key == "banyan" or key == "mango" or key == "neem" or key == "palm" or key == "haystack":
				x = s * randf_range(11.5, 14.0)
			_place(root, item, x, float(z) + randf_range(-1.2, 1.2), key != "palm" and key != "banana" and key != "neem" and key != "mango" and key != "banyan")
			if randf() < 0.65 * density and extras.size() > 0:
				var ex: String = extras[randi() % extras.size()]
				_add_life(root, s * randf_range(8.6, 9.6), float(z) + randf_range(-3.0, 3.0), ex)


static func _fields(root: Node3D, n_per_side: int) -> void:
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		for i in range(n_per_side):
			var z: float = -14.0 + 28.0 * float(i) / maxf(1.0, float(n_per_side - 1))
			var x: float = s * randf_range(20.0, 27.0)
			var mustard: bool = randf() < 0.35
			var base: Color = MUSTARD if mustard else GRASS_A
			var alt: Color = Color("#F2B91E") if mustard else GRASS_B
			var f := Node3D.new()
			f.position = Vector3(x, 0.0, z)
			Art.part(f, Art.box(Vector3(11.0, 0.1, 10.0)), SOIL, Vector3(0, 0.05, 0), Vector3.ZERO, false)
			var rows: int = 5 if density >= 0.9 else 3
			for r in range(rows):
				Art.part(f, Art.box(Vector3(1.2, 0.5, 9.4)), base if r % 2 == 0 else alt, Vector3(-4.4 + (8.8 / float(rows - 1)) * float(r), 0.3, 0), Vector3.ZERO, false)
			root.add_child(f)


# ============================================================ biomes

static func _village(root: Node3D) -> void:
	var table := ["house", "house", "house", "hut", "neem", "banana", "house", "kirana", "chai", "pump", "banyan", "temple", "puncture", "barber", "palm", "mango"]
	var extras := ["wave_m", "wave_f", "kids", "goat", "cow", "buffalo", "dog", "chicken", "bicycle", "cart"]
	_fill(root, table, extras)
	_side_street(root, 1.0 if randf() < 0.5 else -1.0, -4.0 + randf() * 8.0)
	if randf() < 0.4:
		_gate(root)


static func _side_street(root: Node3D, s: float, z: float) -> void:
	var st := MeshInstance3D.new()
	st.mesh = Art.box(Vector3(20.0, 0.03, 3.4))
	st.material_override = Art.mat(MUD)
	st.position = Vector3(s * 16.5, 0.03, z)
	st.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(st)
	var h := make_house(false)
	h.position = Vector3(s * 26.5, 0, z)
	h.rotation_degrees.y = 90.0 if s > 0.0 else -90.0
	root.add_child(h)
	var p := make_waver(randf() < 0.5)
	_place(root, p, s * 17.5, z)
	_anim(root, p)


static func _gate(root: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		Art.part(root, Art.box(Vector3(1.0, 8.0, 1.0)), Art.C_PINK, Vector3(float(sx) * 8.6, 4.0, 3.0), Vector3.ZERO, true, 0.07)
		Art.part(root, Art.sph(0.55, 8), Art.C_GOLD, Vector3(float(sx) * 8.6, 8.4, 3.0), Vector3.ZERO, true, 0.05)
	Art.part(root, Art.box(Vector3(18.6, 1.3, 0.9)), Art.C_ORANGE, Vector3(0, 8.1, 3.0), Vector3.ZERO, true, 0.07)
	Art.sign_board(root, Art.S_WELCOME, Vector3(0, 8.1, 3.55), 8.0, 1.0, Art.C_RED)
	for i in range(18):
		Art.part(root, Art.sph(0.16, 5), Art.C_ORANGE if i % 2 == 0 else Art.C_YELLOW, Vector3(-8.0 + 0.94 * float(i), 7.2 - 0.16 * sin(PI * float(i) / 17.0), 3.3), Vector3.ZERO, false)


static func _farm(root: Node3D) -> void:
	_fields(root, 3)
	var table := ["haystack", "banana", "palm", "mango", "neem", "scarecrow", "well", "hut", "house", ""]
	var extras := ["wave_m", "wave_f", "cow", "goat", "buffalo", "cart", "tractor", "dog"]
	_fill(root, table, extras)


static func _market(root: Node3D) -> void:
	var table := ["stall", "stall", "sabzi", "mithai", "kirana", "chai", "stall", "barber", "puncture", "house"]
	var extras := ["wave_m", "wave_f", "kids", "bicycle", "cow", "dog", "cart"]
	_fill(root, table, extras)
	for zz in [-9.0, 10.0]:
		for sx in [-1.0, 1.0]:
			Art.part(root, Art.cyl(0.08, 0.1, 8.0, 6), Art.C_WOOD_D, Vector3(float(sx) * 9.2, 4.0, float(zz)), Vector3.ZERO, true, 0.04)
		var cols := [Art.C_RED, Art.C_YELLOW, Art.C_TEAL, Art.C_PINK, Art.C_ORANGE, Art.C_PURPLE]
		for i in range(13):
			var fx: float = -9.0 + 1.5 * float(i)
			var fy: float = 7.6 - 0.7 * (1.0 - pow(fx / 9.0, 2.0))
			Art.part(root, Art.prism(Vector3(0.7, 0.9, 0.05)), cols[i % cols.size()], Vector3(fx, fy - 0.45, float(zz)), Vector3(0, 0, 180), false)
		Art.part(root, Art.cap(0.02, 18.4, 4), Art.INK, Vector3(0, 7.2, float(zz)), Vector3(0, 0, 90), false)
	if randf() < 0.5:
		var bs := make_bus_stop()
		var sd: float = 1.0 if randf() < 0.5 else -1.0
		bs.position = Vector3(sd * 13.0, 0, -6.0)
		root.add_child(bs)


static func _pond(root: Node3D) -> void:
	var s: float = 1.0 if randf() < 0.5 else -1.0
	var cx: float = s * 17.0
	var shore := MeshInstance3D.new()
	shore.mesh = Art.cyl(9.6, 9.6, 0.03, 20)
	shore.material_override = Art.mat(Color("#B88A4E"))
	shore.position = Vector3(cx, 0.03, 0)
	shore.scale = Vector3(1.0, 1.0, 1.7)
	shore.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(shore)
	var pw := MeshInstance3D.new()
	pw.mesh = Art.cyl(8.6, 8.6, 0.03, 20)
	pw.material_override = Art.water_mat(Art.C_WATER)
	pw.position = Vector3(cx, 0.05, 0)
	pw.scale = Vector3(1.0, 1.0, 1.7)
	pw.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(pw)
	var pads: int = int(8.0 * density)
	for i in range(pads):
		var lp := make_lotus()
		lp.position = Vector3(cx + randf_range(-6.0, 6.0), 0.05, randf_range(-11.0, 11.0))
		root.add_child(lp)
	for i in range(int(4.0 * density) + 1):
		var d := make_duck()
		d.position = Vector3(cx + randf_range(-5.0, 5.0), 0.06, randf_range(-9.0, 9.0))
		d.rotation_degrees.y = randf() * 360.0
		root.add_child(d)
		_anim(root, d)
	for i in range(int(10.0 * density)):
		var a: float = randf() * TAU
		var rd := Node3D.new()
		rd.position = Vector3(cx + cos(a) * 9.4, 0, sin(a) * 15.8)
		for k in range(3):
			Art.part(rd, Art.cyl(0.0, 0.08, 1.4 + 0.3 * float(k), 5), Art.C_LEAF_D, Vector3(0.12 * float(k), 0.7, 0), Vector3(0, 0, 6.0 * float(k - 1)), false)
		Art.part(rd, Art.cyl(0.1, 0.1, 0.5, 6), Color("#8A5A32"), Vector3(0.2, 1.55, 0), Vector3.ZERO, false)
		root.add_child(rd)
	var t := ["neem", "banana", "palm", "mango", "banyan"]
	for i in range(4):
		var tr := _item(t[randi() % t.size()])
		_place(root, tr, -s * randf_range(11.0, 14.0), -16.0 + 10.5 * float(i), false)
	var k := make_child()
	_place(root, k, s * 8.6, 4.0)
	_anim(root, k)
	var f := make_waver(false)
	_place(root, f, s * 9.0, -3.0)
	_anim(root, f)
	var buf := Props.make_buffalo(1)
	buf.scale = Vector3(0.9, 0.9, 0.9)
	_place(root, buf, s * 8.8, 9.0, false)
	_anim(root, buf)
	buf.rotation_degrees.y = -90.0 * s


static func _bridge(root: Node3D) -> void:
	var wt := MeshInstance3D.new()
	wt.mesh = Art.box(Vector3(120.0, 0.03, 20.0))
	wt.material_override = Art.water_mat(Art.C_WATER)
	wt.position = Vector3(0, 0.03, 0)
	wt.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(wt)
	var bank_a := MeshInstance3D.new()
	bank_a.mesh = Art.box(Vector3(120.0, 0.03, 4.0))
	bank_a.material_override = Art.mat(Color("#B88A4E"))
	bank_a.position = Vector3(0, 0.02, -11.5)
	root.add_child(bank_a)
	var bank_b := MeshInstance3D.new()
	bank_b.mesh = Art.box(Vector3(120.0, 0.03, 4.0))
	bank_b.material_override = Art.mat(Color("#B88A4E"))
	bank_b.position = Vector3(0, 0.02, 11.5)
	root.add_child(bank_b)
	var deck := MeshInstance3D.new()
	deck.mesh = Art.box(Vector3(13.5, 0.1, 22.0))
	deck.material_override = Art.mat(Color("#C99A66"))
	deck.position = Vector3(0, 0.0, 0)
	deck.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(deck)
	for sx in [-1.0, 1.0]:
		Art.part(root, Art.box(Vector3(0.5, 0.35, 22.0)), Art.C_STONE, Vector3(float(sx) * 7.0, 0.45, 0), Vector3.ZERO, true, 0.05)
		for i in range(8):
			var zz: float = -10.5 + 3.0 * float(i)
			Art.part(root, Art.box(Vector3(0.7, 1.3, 0.7)), Art.C_STONE, Vector3(float(sx) * 7.0, 0.65, zz), Vector3.ZERO, true, 0.05)
			Art.part(root, Art.box(Vector3(0.78, 0.2, 0.78)), Art.C_RED if i % 2 == 0 else Art.C_ORANGE, Vector3(float(sx) * 7.0, 1.4, zz), Vector3.ZERO, false)
	for i in range(int(6.0 * density)):
		var a: float = 1.0 if randf() < 0.5 else -1.0
		var rd := Node3D.new()
		rd.position = Vector3(a * randf_range(10.0, 20.0), 0, randf_range(-8.0, 8.0))
		for k in range(3):
			Art.part(rd, Art.cyl(0.0, 0.08, 1.4 + 0.3 * float(k), 5), Art.C_LEAF_D, Vector3(0.12 * float(k), 0.7, 0), Vector3(0, 0, 6.0 * float(k - 1)), false)
		root.add_child(rd)
	var t := ["neem", "banana", "palm", "banyan"]
	for sx in [-1.0, 1.0]:
		var tr := _item(t[randi() % t.size()])
		_place(root, tr, float(sx) * randf_range(12.0, 15.0), -15.0 + randf() * 3.0, false)
		var h := _item("house")
		_place(root, h, float(sx) * randf_range(11.0, 12.5), 16.5)
	var kid := make_child()
	_place(root, kid, 8.4, -13.0)
	_anim(root, kid)
	var ox := Props.make_ox()
	ox.scale = Vector3(0.8, 0.8, 0.8)
	_place(root, ox, -8.8, 15.0, false)
	ox.rotation_degrees.y = 90.0
	_anim(root, ox)


# ============================================================ distant hills

static func _far(root: Node3D, kind: String) -> void:
	for sx in [-1.0, 1.0]:
		var s: float = float(sx)
		var n: int = 2 if density >= 0.9 else 1
		for i in range(n):
			var h := MeshInstance3D.new()
			h.mesh = Art.sph(14.0, 10)
			var hc: Color = Color("#3FA65A") if randf() < 0.5 else Color("#5CB85C")
			h.material_override = Art.mat(hc)
			h.position = Vector3(s * randf_range(52.0, 70.0), -1.0, randf_range(-18.0, 18.0))
			h.scale = Vector3(randf_range(1.8, 2.6), randf_range(0.45, 0.75), randf_range(1.2, 1.8))
			h.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			root.add_child(h)
		if kind != "bridge" and density >= 0.9:
			for k in range(3):
				var tr := make_neem()
				tr.position = Vector3(s * randf_range(30.0, 44.0), 0, randf_range(-18.0, 18.0))
				tr.scale = Vector3(1.3, 1.3, 1.3)
				root.add_child(tr)
