extends RefCounted
## The phone controller. The TV app serves this page over plain HTTP and the
## page talks back over a WebSocket. Swipe left/right to change lane, swipe up
## (or tap) to jump, swipe down to drop fast. The taunt button roasts the
## other player on the TV.

const PAGE := """<!doctype html>
<html lang="hi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Bicycle Rush</title>
<style>
html,body{margin:0;height:100%;background:#1b1410;color:#fff6e0;font-family:system-ui,-apple-system,sans-serif;overflow:hidden;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent}
#app{position:fixed;left:0;top:0;right:0;bottom:0;display:flex;flex-direction:column}
#top{padding:10px 14px;display:flex;justify-content:space-between;align-items:center;font-size:16px;font-weight:600;background:#555;color:#1b1410}
#pad{flex:1;margin:10px 14px;border-radius:20px;background:rgba(255,255,255,.1);border:2px dashed rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;text-align:center;font-size:20px;line-height:1.5;padding:12px;touch-action:none;white-space:pre-line}
#btns{display:flex;gap:10px;padding:0 14px 10px}
#btns2{display:flex;padding:0 14px 14px}
button.small{padding:10px 6px;font-size:15px;font-weight:600;background:#d9c9a8}
button{flex:1;padding:18px 6px;border:0;border-radius:14px;font-size:20px;font-weight:700;color:#1b1410;background:#fff6e0;touch-action:manipulation}
button:active{transform:scale(.97)}
</style></head><body>
<div id="app">
<div id="top"><span id="who">Bicycle Rush</span><span id="conn">...</span></div>
<div id="pad"><span id="msg">जुड़ रहे हैं...</span></div>
<div id="btns"><button id="taunt">ताना मारो</button><button id="pause">रोको</button><button id="start">शुरू</button></div>
<div id="btns2"><button id="qual" class="small">क्वालिटी: बदलो</button></div>
</div>
<script>
(function(){
var WS_PORT = __WS_PORT__;
var id;
try { id = localStorage.getItem('br_id'); } catch (e) { id = null; }
if (!id) {
  id = Math.random().toString(36).slice(2) + Date.now().toString(36);
  try { localStorage.setItem('br_id', id); } catch (e) {}
}
var ws = null, full = false, msgTimer = null;
var who = document.getElementById('who');
var conn = document.getElementById('conn');
var topbar = document.getElementById('top');
var msg = document.getElementById('msg');
var pad = document.getElementById('pad');
var HELP = 'बाएँ / दाएँ स्वाइप: लेन बदलो\\nऊपर स्वाइप या टैप: कूदो\\nनीचे स्वाइप: तेज़ी से उतरो';

function send(o) { if (ws && ws.readyState === 1) { ws.send(JSON.stringify(o)); } }
function setMsg(t) { msg.textContent = t; }
function showMsg(t) {
  setMsg(t);
  if (msgTimer) { clearTimeout(msgTimer); }
  msgTimer = setTimeout(function () { setMsg(HELP); }, 3500);
}

function connect() {
  if (full) { return; }
  conn.textContent = '...';
  ws = new WebSocket('ws://' + location.hostname + ':' + WS_PORT);
  ws.onopen = function () { send({ t: 'join', id: id }); };
  ws.onmessage = function (e) {
    var m;
    try { m = JSON.parse(e.data); } catch (x) { return; }
    if (m.t === 'hello') {
      who.textContent = 'खिलाड़ी ' + (m.slot + 1);
      topbar.style.background = m.color;
      conn.textContent = 'जुड़ा हुआ';
      setMsg(HELP);
    } else if (m.t === 'full') {
      full = true;
      who.textContent = 'Bicycle Rush';
      conn.textContent = '';
      setMsg('दो खिलाड़ी पहले से हैं। अगली बार जल्दी आना!');
    } else if (m.t === 'vibe') {
      if (navigator.vibrate) { navigator.vibrate(m.ms || 200); }
    } else if (m.t === 'msg') {
      showMsg(m.text);
    }
  };
  ws.onclose = function () {
    conn.textContent = 'दोबारा जुड़ रहे हैं...';
    if (!full) { setTimeout(connect, 1000); }
  };
  ws.onerror = function () { try { ws.close(); } catch (x) {} };
}

var down = false, fired = false, sx = 0, sy = 0;
function dir(dx, dy) {
  if (Math.abs(dx) > Math.abs(dy)) { send({ t: 'swipe', d: dx > 0 ? 'r' : 'l' }); }
  else { send({ t: 'swipe', d: dy > 0 ? 'd' : 'u' }); }
}
pad.addEventListener('pointerdown', function (e) {
  down = true; fired = false; sx = e.clientX; sy = e.clientY;
  try { pad.setPointerCapture(e.pointerId); } catch (x) {}
  e.preventDefault();
});
pad.addEventListener('pointermove', function (e) {
  if (!down || fired) { return; }
  var dx = e.clientX - sx, dy = e.clientY - sy;
  if (Math.max(Math.abs(dx), Math.abs(dy)) >= 28) { fired = true; dir(dx, dy); }
});
pad.addEventListener('pointerup', function () {
  if (down && !fired) { send({ t: 'swipe', d: 'u' }); }
  down = false;
});
pad.addEventListener('pointercancel', function () { down = false; });
document.getElementById('taunt').addEventListener('click', function () { send({ t: 'taunt' }); });
document.getElementById('start').addEventListener('click', function () { send({ t: 'start' }); });
document.getElementById('pause').addEventListener('click', function () { send({ t: 'pause' }); });
var q = 'high';
document.getElementById('qual').addEventListener('click', function () {
  q = (q === 'high') ? 'low' : 'high';
  send({ t: 'quality', v: q });
  showMsg(q === 'low' ? 'क्वालिटी: कम (तेज़)' : 'क्वालिटी: ज़्यादा');
});
document.addEventListener('contextmenu', function (e) { e.preventDefault(); });

setMsg('जुड़ रहे हैं...');
connect();
})();
</script></body></html>"""


static func get_page(ws_port: int) -> String:
	return PAGE.replace("__WS_PORT__", str(ws_port))
