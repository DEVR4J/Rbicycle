extends RefCounted
## Paints the hand-painted Hindi signboards into small textures once at
## start-up (a SubViewport per sign) so 3D boards can use them as pictures.

const Art := preload("res://scripts/art.gd")

# text -> [background, text colour, border, wide]
const DESIGNS := {
	"कार्य प्रगति पर है": [Color("#2E6FE0"), Color("#FFFFFF"), Color("#FFC21F"), false],
	"चाय की दुकान": [Color("#8A4B1F"), Color("#FFF1CF"), Color("#FFC21F"), false],
	"स्वागतम्": [Color("#D93636"), Color("#FFE9A8"), Color("#FFC21F"), true],
	"मिठाई वाला": [Color("#E8408A"), Color("#FFFFFF"), Color("#FFE27A"), false],
	"सब्ज़ी मंडी": [Color("#2FA84F"), Color("#FFFFFF"), Color("#FFE27A"), false],
	"पंचर बनता है": [Color("#2B7BE0"), Color("#FFF1CF"), Color("#FF8A2B"), false],
	"किराना स्टोर": [Color("#D93636"), Color("#FFF1CF"), Color("#FFC21F"), false],
	"राम राम जी": [Color("#FFB81F"), Color("#7A1F1F"), Color("#D93636"), false],
	"बाल कटिंग": [Color("#FF8A2B"), Color("#FFFFFF"), Color("#2B1B14"), false],
	"राज ट्रैवल्स": [Color("#D93636"), Color("#FFF1CF"), Color("#FFC21F"), false],
}


static func build(host: Node, font: Font) -> void:
	for text in DESIGNS.keys():
		var d: Array = DESIGNS[text]
		var wide: bool = d[3]
		var size := Vector2i(1024, 128) if wide else Vector2i(512, 128)
		var vp := SubViewport.new()
		vp.size = size
		vp.disable_3d = true
		vp.transparent_bg = false
		vp.render_target_update_mode = SubViewport.UPDATE_ONCE
		host.add_child(vp)
		var border := ColorRect.new()
		border.color = d[2]
		border.size = Vector2(size)
		vp.add_child(border)
		var inner := ColorRect.new()
		inner.color = d[0]
		inner.position = Vector2(8, 8)
		inner.size = Vector2(size) - Vector2(16, 16)
		vp.add_child(inner)
		var lb := Label.new()
		lb.text = str(text)
		lb.add_theme_font_override("font", font)
		var chars: int = maxi(str(text).length(), 1)
		var fs: int = int(clampf(float(size.x) * 0.86 / (float(chars) * 0.58), 36.0, 92.0))
		lb.add_theme_font_size_override("font_size", fs)
		lb.add_theme_color_override("font_color", d[1])
		lb.add_theme_color_override("font_outline_color", Color(0.1, 0.05, 0.03, 0.9))
		lb.add_theme_constant_override("outline_size", 6)
		lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lb.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		lb.position = Vector2.ZERO
		lb.size = Vector2(size)
		vp.add_child(lb)
		Art.sign_tex[str(text)] = vp.get_texture()
