extends RefCounted
## Arcade-style HUD built from rounded panels with a gloss layer, plus icons
## drawn in code (coin, heart, shield, chai cup, clipboard, star, pause).

const CREAM := Color("#FFF3D6")
const INK := Color("#2B1B14")
const GOLD := Color("#FFC21F")
const P1_COL := Color("#FF5C93")
const P2_COL := Color("#3E7BFA")


class Icon extends Control:
	var kind: String = "coin"
	var tint: Color = Color.WHITE

	func _draw() -> void:
		var u: float = minf(size.x, size.y) / 20.0
		var c: Vector2 = size * 0.5
		match kind:
			"coin":
				draw_circle(c, 10.0 * u, Color("#C98A0A"))
				draw_circle(c, 8.6 * u, Color("#FFC21F"))
				draw_circle(c, 6.4 * u, Color("#FFE07A"))
				var rc := Color("#B26A00")
				var w: float = 1.7 * u
				draw_line(c + Vector2(-4.0, -5.4) * u, c + Vector2(4.2, -5.4) * u, rc, w)
				draw_line(c + Vector2(-4.0, -2.4) * u, c + Vector2(4.2, -2.4) * u, rc, w)
				draw_arc(c + Vector2(-0.5, -3.9) * u, 1.5 * u, -PI / 2.0, PI / 2.0, 10, rc, w)
				draw_line(c + Vector2(-3.4, -0.4) * u, c + Vector2(-0.5, -0.4) * u, rc, w)
				draw_line(c + Vector2(-2.8, -0.6) * u, c + Vector2(2.6, 6.0) * u, rc, w)
			"pause":
				draw_rect(Rect2(c + Vector2(-5.2, -6.0) * u, Vector2(3.6, 12.0) * u), tint)
				draw_rect(Rect2(c + Vector2(1.6, -6.0) * u, Vector2(3.6, 12.0) * u), tint)
			"heart":
				var hc := Color("#E8344B")
				draw_circle(c + Vector2(-3.4, -2.6) * u, 4.4 * u, hc)
				draw_circle(c + Vector2(3.4, -2.6) * u, 4.4 * u, hc)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-7.6, -1.2) * u, c + Vector2(7.6, -1.2) * u, c + Vector2(0, 9.0) * u]), hc)
				draw_circle(c + Vector2(-4.4, -3.6) * u, 1.3 * u, Color(1, 1, 1, 0.75))
			"heart_empty":
				var ec := Color(0.3, 0.2, 0.2, 0.55)
				draw_circle(c + Vector2(-3.4, -2.6) * u, 4.4 * u, ec)
				draw_circle(c + Vector2(3.4, -2.6) * u, 4.4 * u, ec)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-7.6, -1.2) * u, c + Vector2(7.6, -1.2) * u, c + Vector2(0, 9.0) * u]), ec)
			"shield":
				var pts := PackedVector2Array([c + Vector2(-8, -8) * u, c + Vector2(8, -8) * u, c + Vector2(8, 0) * u, c + Vector2(0, 9.5) * u, c + Vector2(-8, 0) * u])
				draw_colored_polygon(pts, Color("#1F4FB8"))
				var inner := PackedVector2Array([c + Vector2(-6, -6.2) * u, c + Vector2(6, -6.2) * u, c + Vector2(6, -0.6) * u, c + Vector2(0, 7.2) * u, c + Vector2(-6, -0.6) * u])
				draw_colored_polygon(inner, Color("#4FA3FF"))
				draw_rect(Rect2(c + Vector2(-1.2, -4.6) * u, Vector2(2.4, 9.0) * u), Color.WHITE)
				draw_rect(Rect2(c + Vector2(-4.2, -1.8) * u, Vector2(8.4, 2.4) * u), Color.WHITE)
			"chai":
				var cup := PackedVector2Array([c + Vector2(-6.5, -2) * u, c + Vector2(6.5, -2) * u, c + Vector2(4.8, 7.5) * u, c + Vector2(-4.8, 7.5) * u])
				draw_colored_polygon(cup, Color("#C9572B"))
				draw_rect(Rect2(c + Vector2(-6.5, -3.4) * u, Vector2(13, 2.4) * u), Color("#F2A56E"))
				draw_arc(c + Vector2(7.2, 2.6) * u, 3.0 * u, -PI / 2.0, PI / 2.0, 10, Color("#C9572B"), 1.8 * u)
				for k in range(2):
					var sx: float = -2.4 + 4.8 * float(k)
					var pl := PackedVector2Array()
					for j in range(7):
						pl.append(c + Vector2(sx + sin(float(j) * 1.3 + float(k)) * 1.1, -4.4 - 1.5 * float(j)) * u)
					draw_polyline(pl, Color(1, 1, 1, 0.9), 1.4 * u)
			"bolt":
				var bp := PackedVector2Array([c + Vector2(2, -9.5) * u, c + Vector2(-6, 1.2) * u, c + Vector2(-1, 1.2) * u, c + Vector2(-2.6, 9.5) * u, c + Vector2(6.5, -2.4) * u, c + Vector2(1, -2.4) * u])
				draw_colored_polygon(bp, Color("#FF8A2B"))
			"missions":
				draw_rect(Rect2(c + Vector2(-7.5, -8.2) * u, Vector2(15, 18) * u), Color("#D9A85B"))
				draw_rect(Rect2(c + Vector2(-6, -6.6) * u, Vector2(12, 15) * u), Color.WHITE)
				draw_rect(Rect2(c + Vector2(-3.2, -9.8) * u, Vector2(6.4, 3.4) * u), Color("#8A929C"))
				for k in range(3):
					var yy: float = -3.2 + 4.6 * float(k)
					draw_polyline(PackedVector2Array([c + Vector2(-4.6, yy) * u, c + Vector2(-3.6, yy + 1.2) * u, c + Vector2(-2.0, yy - 1.2) * u]), Color("#2FA84F"), 1.4 * u)
					draw_line(c + Vector2(-0.6, yy) * u, c + Vector2(4.6, yy) * u, Color("#B8B2A6"), 1.3 * u)
			"star":
				var sp := PackedVector2Array()
				for k in range(10):
					var r: float = 10.0 if k % 2 == 0 else 4.4
					var a: float = -PI / 2.0 + PI * float(k) / 5.0
					sp.append(c + Vector2(cos(a), sin(a)) * r * u)
				draw_colored_polygon(sp, Color("#FFD43B"))
				var op: PackedVector2Array = sp.duplicate()
				op.append(sp[0])
				draw_polyline(op, Color("#C98A0A"), 1.2 * u)


var font: Font
var root: Control
var coin_lbl: Label
var score_lbl: Label
var mult_lbl: Label
var mult_badge: Control
var hearts: Array = []
var chip_lbls: Array = []
var chip_panels: Array = []
var chip_shield: Array = []
var power_rows: Dictionary = {}
var speech_panel: Panel
var speech_lbl: Label
var toast_panel: Panel
var toast_lbl: Label
var count_lbl: Label
var overlay: Control
var ov_title: Label
var ov_body: Label
var ov_hint: Label
var mission_mini: Label
var last_mult := 1
var speech_tween: Tween
var toast_tween: Tween


func build(parent: Node, f: Font) -> void:
	font = f
	var layer := CanvasLayer.new()
	layer.layer = 5
	parent.add_child(layer)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)

	# top-left: pause, coins, lives
	var pb := _pill(root, Vector2(48, 36), Vector2(96, 96), Color("#FF8A2B"), 48)
	_icon(pb, "pause", Vector2(0, 0), Vector2(96, 96), CREAM)
	var cp := _pill(root, Vector2(164, 44), Vector2(280, 80), Color("#2D6FD6"), 40)
	_icon(cp, "coin", Vector2(10, 8), Vector2(64, 64))
	coin_lbl = _label(cp, "0", 46, CREAM, Vector2(84, 6), Vector2(180, 68), HORIZONTAL_ALIGNMENT_LEFT)
	for i in range(3):
		var h := _icon(root, "heart", Vector2(172 + 62 * i, 136), Vector2(56, 56))
		hearts.append(h)

	# top-centre: player chips
	var cols := [P1_COL, P2_COL]
	for i in range(2):
		var chip := _pill(root, Vector2(690 + 290 * i, 40), Vector2(260, 72), cols[i], 36)
		var lb := _label(chip, "", 34, CREAM, Vector2(14, 4), Vector2(232, 64), HORIZONTAL_ALIGNMENT_LEFT)
		var sh := _icon(chip, "shield", Vector2(196, 10), Vector2(52, 52))
		sh.visible = false
		chip_lbls.append(lb)
		chip_panels.append(chip)
		chip_shield.append(sh)

	# top-right: score and multiplier
	var sp := _pill(root, Vector2(1372, 36), Vector2(512, 108), Color("#2D6FD6"), 54)
	_label(sp, "SCORE", 26, Color("#BFE0FF"), Vector2(30, 6), Vector2(200, 34), HORIZONTAL_ALIGNMENT_LEFT)
	score_lbl = _label(sp, "0", 64, GOLD, Vector2(20, 22), Vector2(472, 84), HORIZONTAL_ALIGNMENT_RIGHT)
	mult_badge = _pill(root, Vector2(1640, 156), Vector2(244, 72), Color("#FF7A1A"), 36)
	_icon(mult_badge, "star", Vector2(12, 8), Vector2(56, 56))
	mult_lbl = _label(mult_badge, "x1", 44, CREAM, Vector2(72, 2), Vector2(160, 68), HORIZONTAL_ALIGNMENT_CENTER)

	# bottom-left: missions + power-ups
	var mb := _pill(root, Vector2(48, 900), Vector2(112, 112), Color("#7B4FC4"), 28)
	_icon(mb, "missions", Vector2(14, 8), Vector2(84, 84))
	_label(mb, "मिशन", 26, CREAM, Vector2(0, 78), Vector2(112, 32), HORIZONTAL_ALIGNMENT_CENTER)
	mission_mini = _label(root, "", 28, CREAM, Vector2(176, 940), Vector2(620, 40), HORIZONTAL_ALIGNMENT_LEFT)
	_power_row("boost", "चाय बूस्ट", "chai", Color("#FF8A2B"), Vector2(48, 770))
	_power_row("shield1", "ढाल: खिलाड़ी 1", "shield", P1_COL, Vector2(48, 696))
	_power_row("shield2", "ढाल: खिलाड़ी 2", "shield", P2_COL, Vector2(48, 622))

	# speech bubble
	speech_panel = _pill(root, Vector2(300, 884), Vector2(1320, 140), Color("#2A2118"), 40)
	speech_panel.modulate = Color(1, 1, 1, 0.96)
	speech_lbl = _label(speech_panel, "", 42, Color("#FFE6A8"), Vector2(30, 8), Vector2(1260, 124), HORIZONTAL_ALIGNMENT_CENTER)
	speech_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	speech_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	speech_lbl.add_theme_constant_override("outline_size", 0)
	speech_panel.visible = false

	# toast banner
	toast_panel = _pill(root, Vector2(560, 150), Vector2(800, 96), Color("#2FA84F"), 48)
	toast_lbl = _label(toast_panel, "", 42, CREAM, Vector2(20, 8), Vector2(760, 80), HORIZONTAL_ALIGNMENT_CENTER)
	toast_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	toast_panel.visible = false

	# countdown
	count_lbl = _label(root, "", 220, GOLD, Vector2(560, 300), Vector2(800, 320), HORIZONTAL_ALIGNMENT_CENTER)
	count_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	count_lbl.add_theme_constant_override("outline_size", 22)
	count_lbl.visible = false

	# overlay card
	overlay = Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.1, 0.06, 0.12, 0.55)
	dim.size = Vector2(1920, 1080)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(dim)
	var card := _pill(overlay, Vector2(210, 90), Vector2(1500, 900), Color("#FF8A2B"), 64)
	var inner := _pill(card, Vector2(18, 18), Vector2(1464, 864), Color("#FFF3D6"), 50)
	ov_title = _label(inner, "", 96, Color("#D93636"), Vector2(20, 24), Vector2(1424, 130), HORIZONTAL_ALIGNMENT_CENTER)
	ov_title.add_theme_color_override("font_outline_color", Color("#FFFFFF"))
	ov_body = _label(inner, "", 46, Color("#3A2208"), Vector2(60, 170), Vector2(1344, 540), HORIZONTAL_ALIGNMENT_CENTER)
	ov_body.add_theme_constant_override("outline_size", 0)
	ov_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ov_body.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	var hint := _pill(inner, Vector2(332, 730), Vector2(800, 100), Color("#2FA84F"), 50)
	ov_hint = _label(hint, "", 44, CREAM, Vector2(10, 8), Vector2(780, 84), HORIZONTAL_ALIGNMENT_CENTER)
	ov_hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var pulse := hint.create_tween()
	pulse.set_loops()
	pulse.tween_property(hint, "scale", Vector2(1.05, 1.05), 0.6).set_trans(Tween.TRANS_SINE)
	pulse.tween_property(hint, "scale", Vector2(1.0, 1.0), 0.6).set_trans(Tween.TRANS_SINE)
	hint.pivot_offset = hint.size * 0.5
	overlay.visible = false


# ------------------------------------------------------------ builders

func _pill(parent: Control, pos: Vector2, sz: Vector2, col: Color, radius: int) -> Panel:
	var p := Panel.new()
	p.position = pos
	p.size = sz
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(radius)
	sb.set_border_width_all(5)
	sb.border_color = col.darkened(0.38)
	sb.shadow_color = Color(0, 0, 0, 0.32)
	sb.shadow_size = 8
	sb.shadow_offset = Vector2(0, 5)
	p.add_theme_stylebox_override("panel", sb)
	var gl := Panel.new()
	gl.position = Vector2(6, 5)
	gl.size = Vector2(sz.x - 12.0, sz.y * 0.46)
	gl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var gs := StyleBoxFlat.new()
	gs.bg_color = Color(1, 1, 1, 0.2)
	gs.corner_radius_top_left = maxi(radius - 6, 2)
	gs.corner_radius_top_right = maxi(radius - 6, 2)
	gs.corner_radius_bottom_left = 6
	gs.corner_radius_bottom_right = 6
	gl.add_theme_stylebox_override("panel", gs)
	p.add_child(gl)
	parent.add_child(p)
	return p


func _label(parent: Control, text: String, fs: int, col: Color, pos: Vector2, sz: Vector2, align: HorizontalAlignment) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.size = sz
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", INK)
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l


func _icon(parent: Control, kind: String, pos: Vector2, sz: Vector2, tint: Color = Color.WHITE) -> Icon:
	var ic := Icon.new()
	ic.kind = kind
	ic.tint = tint
	ic.position = pos
	ic.size = sz
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(ic)
	return ic


func _power_row(key: String, title: String, icon_kind: String, col: Color, pos: Vector2) -> void:
	var row := _pill(root, pos, Vector2(430, 62), col, 31)
	_icon(row, icon_kind, Vector2(8, 4), Vector2(52, 52))
	_label(row, title, 28, CREAM, Vector2(66, 2), Vector2(240, 36), HORIZONTAL_ALIGNMENT_LEFT)
	var bar_bg := Panel.new()
	bar_bg.position = Vector2(70, 40)
	bar_bg.size = Vector2(340, 12)
	bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bsb := StyleBoxFlat.new()
	bsb.bg_color = Color(0, 0, 0, 0.4)
	bsb.set_corner_radius_all(6)
	bar_bg.add_theme_stylebox_override("panel", bsb)
	row.add_child(bar_bg)
	var bar := Panel.new()
	bar.position = Vector2(70, 40)
	bar.size = Vector2(340, 12)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fsb := StyleBoxFlat.new()
	fsb.bg_color = Color("#8CE85A")
	fsb.set_corner_radius_all(6)
	bar.add_theme_stylebox_override("panel", fsb)
	row.add_child(bar)
	row.visible = false
	power_rows[key] = {"row": row, "bar": bar}


# ------------------------------------------------------------ updates

func update_hud(coins: int, score: int, mult: int, lives: int, max_lives: int) -> void:
	coin_lbl.text = str(coins)
	score_lbl.text = _commas(score)
	mult_lbl.text = "x%d" % mult
	for i in range(hearts.size()):
		var h: Icon = hearts[i]
		var want: String = "heart" if i < lives else "heart_empty"
		if h.kind != want:
			h.kind = want
			h.queue_redraw()
		h.visible = i < max_lives
	if mult != last_mult:
		if mult > last_mult:
			mult_badge.pivot_offset = mult_badge.size * 0.5
			var tw := mult_badge.create_tween()
			tw.tween_property(mult_badge, "scale", Vector2(1.25, 1.25), 0.12)
			tw.tween_property(mult_badge, "scale", Vector2(1.0, 1.0), 0.18)
		last_mult = mult


func update_players(joined: Array, coins: Array, shield: Array) -> void:
	for i in range(2):
		var chip: Panel = chip_panels[i]
		chip.visible = bool(joined[i])
		var lb: Label = chip_lbls[i]
		lb.text = "P%d   सिक्के %d" % [i + 1, int(coins[i])]
		var sh: Control = chip_shield[i]
		sh.visible = bool(shield[i])


func set_power(key: String, remaining: float, total: float) -> void:
	if not power_rows.has(key):
		return
	var d: Dictionary = power_rows[key]
	var row: Control = d["row"]
	var bar: Control = d["bar"]
	var on: bool = remaining > 0.0
	row.visible = on
	if on:
		bar.size.x = 340.0 * clampf(remaining / maxf(total, 0.01), 0.0, 1.0)


func set_mission_line(text: String) -> void:
	mission_mini.text = text


func speech(text: String, secs: float = 3.8) -> void:
	speech_lbl.text = text
	speech_panel.visible = true
	speech_panel.pivot_offset = speech_panel.size * 0.5
	speech_panel.scale = Vector2(0.85, 0.85)
	if speech_tween != null and speech_tween.is_valid():
		speech_tween.kill()
	speech_tween = speech_panel.create_tween()
	speech_tween.tween_property(speech_panel, "scale", Vector2(1, 1), 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	speech_tween.tween_interval(secs)
	speech_tween.tween_callback(func() -> void: speech_panel.visible = false)


func toast(text: String, col: Color = Color("#2FA84F"), secs: float = 2.4) -> void:
	var sb: StyleBoxFlat = toast_panel.get_theme_stylebox("panel") as StyleBoxFlat
	if sb != null:
		sb.bg_color = col
		sb.border_color = col.darkened(0.38)
	toast_lbl.text = text
	toast_panel.visible = true
	toast_panel.pivot_offset = toast_panel.size * 0.5
	toast_panel.position.y = 90.0
	toast_panel.modulate.a = 0.0
	if toast_tween != null and toast_tween.is_valid():
		toast_tween.kill()
	toast_tween = toast_panel.create_tween()
	toast_tween.set_parallel(true)
	toast_tween.tween_property(toast_panel, "position:y", 150.0, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	toast_tween.tween_property(toast_panel, "modulate:a", 1.0, 0.2)
	toast_tween.chain().tween_interval(secs)
	toast_tween.chain().tween_property(toast_panel, "modulate:a", 0.0, 0.3)
	toast_tween.chain().tween_callback(func() -> void: toast_panel.visible = false)


func countdown(text: String, col: Color = GOLD) -> void:
	count_lbl.text = text
	count_lbl.add_theme_color_override("font_color", col)
	count_lbl.visible = true
	count_lbl.pivot_offset = count_lbl.size * 0.5
	count_lbl.scale = Vector2(1.7, 1.7)
	count_lbl.modulate.a = 1.0
	var tw := count_lbl.create_tween()
	tw.tween_property(count_lbl, "scale", Vector2(1, 1), 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(count_lbl, "modulate:a", 0.0, 0.35).set_delay(0.3)
	tw.tween_callback(func() -> void: count_lbl.visible = false)


func show_overlay(title: String, body: String, hint: String, title_col: Color = Color("#D93636")) -> void:
	ov_title.text = title
	ov_title.add_theme_color_override("font_color", title_col)
	ov_body.text = body
	ov_hint.text = hint
	overlay.visible = true


func hide_overlay() -> void:
	overlay.visible = false


func _commas(n: int) -> String:
	var s: String = str(absi(n))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "," + out
	return out
