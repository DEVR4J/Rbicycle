extends Node
## Tiny LAN server running inside the TV app.
##  - HTTP on port 8080 serves the controller page to phone browsers.
##  - WebSocket on port 8081 carries swipes/taps from phones to the game.
## Phones keep a random id in localStorage, so a phone that drops and
## reconnects gets its old player slot back.

const ControllerPage := preload("res://scripts/controller_page.gd")

signal player_message(slot: int, msg: Dictionary)
signal slot_changed(slot: int, connected: bool)

const HTTP_PORT := 8080
const WS_PORT := 8081
const COLORS := ["#FF5C93", "#3E7BFA"]
const RESERVE_MS := 15000

var _http := TCPServer.new()
var _wsrv := TCPServer.new()
var _page: PackedByteArray = PackedByteArray()
var _http_pending: Array = []   # {conn, req, age}
var _peers: Array = []          # {ws, slot, age}
var _slot_ws: Array = [null, null]
var _slot_id: Array = ["", ""]
var _slot_gone: Array = [0, 0]
var _running := false
var url := ""


func start() -> bool:
	_page = ControllerPage.get_page(WS_PORT).to_utf8_buffer()
	var e1: int = _http.listen(HTTP_PORT)
	var e2: int = _wsrv.listen(WS_PORT)
	if e1 != OK or e2 != OK:
		push_warning("PhoneServer: could not open ports %d/%d (errors %d/%d)" % [HTTP_PORT, WS_PORT, e1, e2])
		return false
	_running = true
	url = _make_url()
	return true


func _make_url() -> String:
	var best := ""
	var rank := 99
	for a in IP.get_local_addresses():
		var ip: String = str(a)
		if ip.contains(":") or ip.begins_with("127.") or ip.begins_with("169.254."):
			continue
		var r := 3
		if ip.begins_with("192.168."):
			r = 0
		elif ip.begins_with("10."):
			r = 1
		elif ip.begins_with("172."):
			r = 2
		if r < rank:
			rank = r
			best = ip
	if best == "":
		return "http://<TV-IP>:%d" % HTTP_PORT
	return "http://%s:%d" % [best, HTTP_PORT]


func send_to(slot: int, data: Dictionary) -> void:
	if slot < 0 or slot > 1:
		return
	var ws: WebSocketPeer = _slot_ws[slot]
	if ws != null and ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
		ws.send_text(JSON.stringify(data))


func _process(delta: float) -> void:
	if not _running:
		return
	_poll_http(delta)
	_accept_ws()
	_poll_ws(delta)


func _poll_http(delta: float) -> void:
	while _http.is_connection_available():
		var c: StreamPeerTCP = _http.take_connection()
		_http_pending.append({"conn": c, "req": "", "age": 0.0})
	for i in range(_http_pending.size() - 1, -1, -1):
		var item: Dictionary = _http_pending[i]
		var c: StreamPeerTCP = item["conn"]
		c.poll()
		item["age"] = float(item["age"]) + delta
		var st: int = c.get_status()
		var drop := false
		if st == StreamPeerTCP.STATUS_CONNECTED:
			var n: int = c.get_available_bytes()
			if n > 0:
				var r: Array = c.get_data(n)
				if int(r[0]) == OK:
					var chunk: PackedByteArray = r[1]
					item["req"] = str(item["req"]) + chunk.get_string_from_utf8()
			if str(item["req"]).contains("\r\n\r\n"):
				var head := ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" % _page.size()).to_utf8_buffer()
				c.put_data(head)
				c.put_data(_page)
				c.disconnect_from_host()
				drop = true
		elif st != StreamPeerTCP.STATUS_CONNECTING:
			drop = true
		if float(item["age"]) > 6.0:
			c.disconnect_from_host()
			drop = true
		if drop:
			_http_pending.remove_at(i)


func _accept_ws() -> void:
	while _wsrv.is_connection_available():
		var c: StreamPeerTCP = _wsrv.take_connection()
		var ws := WebSocketPeer.new()
		if ws.accept_stream(c) == OK:
			_peers.append({"ws": ws, "slot": -1, "age": 0.0})


func _poll_ws(delta: float) -> void:
	for i in range(_peers.size() - 1, -1, -1):
		var p: Dictionary = _peers[i]
		var ws: WebSocketPeer = p["ws"]
		ws.poll()
		p["age"] = float(p["age"]) + delta
		var st: int = ws.get_ready_state()
		if st == WebSocketPeer.STATE_OPEN:
			while ws.get_available_packet_count() > 0:
				var txt: String = ws.get_packet().get_string_from_utf8()
				_handle(p, txt)
		elif st == WebSocketPeer.STATE_CLOSED:
			_peer_gone(p)
			_peers.remove_at(i)
		elif float(p["age"]) > 10.0 and int(p["slot"]) < 0:
			ws.close()


func _peer_gone(p: Dictionary) -> void:
	var slot: int = int(p["slot"])
	if slot >= 0 and _slot_ws[slot] == p["ws"]:
		_slot_ws[slot] = null
		_slot_gone[slot] = Time.get_ticks_msec()
		slot_changed.emit(slot, false)


func _handle(p: Dictionary, txt: String) -> void:
	var j := JSON.new()
	if j.parse(txt) != OK:
		return
	if typeof(j.data) != TYPE_DICTIONARY:
		return
	var d: Dictionary = j.data
	var t: String = str(d.get("t", ""))
	if t == "join":
		_join(p, str(d.get("id", "")))
		return
	var slot: int = int(p["slot"])
	if slot >= 0:
		player_message.emit(slot, d)


func _join(p: Dictionary, id: String) -> void:
	var ws: WebSocketPeer = p["ws"]
	if id == "":
		ws.close()
		return
	var slot := -1
	for k in range(2):
		if _slot_id[k] == id:
			slot = k
	if slot < 0:
		var now: int = Time.get_ticks_msec()
		for k in range(2):
			if slot >= 0:
				break
			if _slot_id[k] == "":
				slot = k
			elif _slot_ws[k] == null and now - int(_slot_gone[k]) > RESERVE_MS:
				slot = k
	if slot < 0:
		ws.send_text(JSON.stringify({"t": "full"}))
		ws.close()
		return
	var old: WebSocketPeer = _slot_ws[slot]
	if old != null and old != ws:
		old.close()
	p["slot"] = slot
	_slot_ws[slot] = ws
	_slot_id[slot] = id
	ws.send_text(JSON.stringify({"t": "hello", "slot": slot, "color": COLORS[slot]}))
	slot_changed.emit(slot, true)
