extends RefCounted
## Particle bursts, floating text and small visual effects. Everything is
## one-shot and frees itself, so nothing piles up.

static var _pmesh: Dictionary = {}
static var _pmat: StandardMaterial3D = null


static func _material() -> StandardMaterial3D:
	if _pmat == null:
		_pmat = StandardMaterial3D.new()
		_pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_pmat.vertex_color_use_as_albedo = true
		_pmat.albedo_color = Color.WHITE
	return _pmat


static func _mesh(kind: String, size: float) -> Mesh:
	var key := "%s%.2f" % [kind, size]
	if _pmesh.has(key):
		return _pmesh[key] as Mesh
	var m: Mesh
	if kind == "box":
		var b := BoxMesh.new()
		b.size = Vector3(size, size, size)
		m = b
	else:
		var s := SphereMesh.new()
		s.radius = size * 0.5
		s.height = size
		s.radial_segments = 6
		s.rings = 3
		m = s
	m.material = _material()
	_pmesh[key] = m
	return m


## One-shot particle burst. kind: "ball" or "box".
static func burst(parent: Node, pos: Vector3, color: Color, count: int = 16, speed: float = 7.0, size: float = 0.22, gravity: float = -12.0, life: float = 0.7, kind: String = "ball", spread: float = 180.0) -> void:
	var p := CPUParticles3D.new()
	p.mesh = _mesh(kind, size)
	p.amount = count
	p.one_shot = true
	p.explosiveness = 1.0
	p.lifetime = life
	p.direction = Vector3(0, 1, 0)
	p.spread = spread
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, gravity, 0)
	p.scale_amount_min = 0.7
	p.scale_amount_max = 1.3
	var g := Gradient.new()
	g.set_color(0, color.lightened(0.35))
	g.set_color(1, Color(color.r, color.g, color.b, 0.0))
	p.color_ramp = g
	p.position = pos
	p.finished.connect(p.queue_free)
	parent.add_child(p)
	p.emitting = true


static func coin_burst(parent: Node, pos: Vector3) -> void:
	burst(parent, pos, Color("#FFC21F"), 10, 6.0, 0.2, -10.0, 0.55)


static func smash(parent: Node, pos: Vector3, color: Color) -> void:
	burst(parent, pos, color, 22, 9.0, 0.35, -16.0, 0.8, "box")
	burst(parent, pos, Color.WHITE, 10, 5.0, 0.2, -6.0, 0.5)


static func splash(parent: Node, pos: Vector3) -> void:
	burst(parent, pos, Color("#7CD4FF"), 20, 8.0, 0.2, -18.0, 0.7)


static func dust(parent: Node, pos: Vector3) -> void:
	burst(parent, pos, Color("#E8C9A0"), 12, 4.0, 0.45, -1.0, 0.8, "ball", 60.0)


static func ring(parent: Node, pos: Vector3, color: Color) -> void:
	var m := MeshInstance3D.new()
	var t := TorusMesh.new()
	t.inner_radius = 0.9
	t.outer_radius = 1.0
	t.rings = 20
	t.ring_segments = 4
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	t.material = mat
	m.mesh = t
	m.position = pos
	m.rotation_degrees = Vector3(90, 0, 0)
	m.scale = Vector3(0.3, 0.3, 0.3)
	parent.add_child(m)
	var tw := m.create_tween()
	tw.set_parallel(true)
	tw.tween_property(m, "scale", Vector3(3.2, 3.2, 3.2), 0.45).set_ease(Tween.EASE_OUT)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.45)
	tw.chain().tween_callback(m.queue_free)


## Floating word that rises and fades (Hindi comic words, +10, etc).
static func popup(parent: Node, pos: Vector3, text: String, color: Color, font: Font, size: int = 72, rise: float = 2.2) -> void:
	var l := Label3D.new()
	l.text = text
	if font != null:
		l.font = font
	l.font_size = size
	l.pixel_size = 0.011
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.fixed_size = false
	l.modulate = color
	l.outline_size = 18
	l.outline_modulate = Color("#2B1B14")
	l.position = pos
	l.scale = Vector3(0.4, 0.4, 0.4)
	parent.add_child(l)
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "scale", Vector3(1.0, 1.0, 1.0), 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "position:y", pos.y + rise, 0.95).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.4).set_delay(0.6)
	tw.chain().tween_callback(l.queue_free)


## A little ring of spinning yellow stars for a dizzy rider. Rotate it each frame.
static func make_stars(art_mat: Material) -> Node3D:
	var n := Node3D.new()
	for i in range(4):
		var a: float = TAU * float(i) / 4.0
		var m := MeshInstance3D.new()
		var b := BoxMesh.new()
		b.size = Vector3(0.34, 0.34, 0.1)
		m.mesh = b
		m.material_override = art_mat
		m.position = Vector3(cos(a) * 0.95, 0.0, sin(a) * 0.95)
		m.rotation_degrees = Vector3(0, 0, 45)
		n.add_child(m)
	n.visible = false
	return n
