Put NotoSansDevanagari-Regular.ttf here as hindi.ttf.
The GitHub workflow does this automatically.
