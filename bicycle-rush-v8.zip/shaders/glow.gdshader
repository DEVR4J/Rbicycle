shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_back;

// Soft additive glow shell (pickups, shield bubble). Curved like the world.

uniform vec4 glow_color : source_color = vec4(1.0, 0.8, 0.2, 1.0);
uniform float intensity = 0.6;

const float CURVE = 0.00012;
const float START = 12.0;

void vertex() {
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	float rim = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 2.0);
	float a = clamp((0.18 + rim) * intensity, 0.0, 1.0);
	ALBEDO = glow_color.rgb;
	ALPHA = a;
}
