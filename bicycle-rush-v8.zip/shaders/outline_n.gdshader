shader_type spatial;
render_mode unshaded, cull_front;

// Outline for skinned (animated) models: pushes the shell out along the
// normals by a fixed world-space width, whatever the model's scale is.

uniform vec4 line_color : source_color = vec4(0.17, 0.09, 0.07, 1.0);
uniform float line_width = 0.05;

const float CURVE = 0.00012;
const float START = 12.0;

void vertex() {
	float s = max(length(MODEL_MATRIX[0].xyz), 0.0001);
	vec3 p = VERTEX + NORMAL * (line_width / s);
	vec4 v = MODELVIEW_MATRIX * vec4(p, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	ALBEDO = line_color.rgb;
}
