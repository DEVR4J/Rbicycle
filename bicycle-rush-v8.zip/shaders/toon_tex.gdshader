shader_type spatial;
render_mode unshaded, cull_back;

// Textured quad (hand-painted signboards) with the same world curve.

uniform sampler2D tex : source_color, filter_linear;

const float CURVE = 0.00012;
const float START = 12.0;

void vertex() {
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	ALBEDO = texture(tex, UV).rgb;
}
