shader_type spatial;
render_mode unshaded, cull_back;

// Self-lit semi-realistic shading: soft light falloff, ground bounce, a soft
// highlight and gentle surface mottling (fur, plaster, bark) from object-space
// patterns. The light direction is fixed in view space so every device matches.

uniform vec4 albedo : source_color = vec4(1.0);
uniform float shade_strength = 0.5;

const float CURVE = 0.00012;
const float START = 12.0;
const vec3 L = vec3(-0.45, 0.75, 0.48);

varying vec3 opos;

void vertex() {
	opos = VERTEX;
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	vec3 n = normalize(NORMAL);
	float nl = dot(n, normalize(L));
	float lit = smoothstep(-0.35, 0.75, nl);
	float wy = (INV_VIEW_MATRIX * vec4(n, 0.0)).y;
	float bounce = 0.8 + 0.2 * clamp(wy * 0.5 + 0.5, 0.0, 1.0);
	float m1 = sin(opos.x * 9.0 + opos.y * 5.0) * sin(opos.z * 8.0 - opos.x * 3.0);
	float m2 = sin(opos.y * 23.0 + opos.z * 17.0) * sin(opos.x * 19.0 + opos.z * 11.0);
	float mott = 0.94 + 0.05 * m1 + 0.025 * m2;
	vec3 base = albedo.rgb * mott * (1.0 - shade_strength + shade_strength * 1.3 * lit) * bounce;
	vec3 warm = base * vec3(1.06, 1.02, 0.94);
	vec3 cool = base * vec3(0.86, 0.9, 1.06);
	vec3 col = mix(cool, warm, lit);
	vec3 r = reflect(-normalize(L), n);
	float spec = pow(max(dot(r, normalize(VIEW)), 0.0), 18.0) * 0.1;
	ALBEDO = clamp(col + vec3(spec), 0.0, 1.0);
}
