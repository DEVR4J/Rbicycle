# Bicycle Rush (Android TV, Godot 4.3)

Two players ride the same rural Indian road on one TV screen. Phones are the
controllers: they open a web page served by the TV app over the same Wi-Fi.
A Hindi commentator roasts everyone.

## Build the APK with GitHub Actions

1. Create a new GitHub repository and push the contents of this folder to it
   (keep the `.github/workflows/build.yml` path).
2. Open the repository's **Actions** tab. The workflow "Build Android TV APK"
   runs on every push to `main`/`master`, or press **Run workflow**.
3. When it finishes, download the `bicycle-rush-apk` artifact. It is a
   debug-signed `bicycle-rush.apk`.

## Install on the TV

- Enable Developer options and ADB debugging on the TV, then:
  `adb connect <tv-ip>` and `adb install bicycle-rush.apk`
- Or copy the APK to a USB stick / use a file-manager or "Send files to TV" app.

## Play

1. Open "Bicycle Rush" on the TV. The lobby shows a web address such as
   `http://192.168.1.20:8080`.
2. On each phone (same Wi-Fi) open that address in the browser.
   The first two phones become Player 1 (orange) and Player 2 (purple).
3. Swipe left/right to change lane, swipe up or tap to jump, swipe down to
   drop fast. "ताना मारो" roasts the other player on the TV.
4. Press "शुरू" on a phone, or OK on the TV remote, to start.

Solo test: with no phones, the TV remote D-pad controls Player 1.
On a PC: arrow keys = Player 1, WASD = Player 2, Enter = start.

## Co-op rules

- Shared 3 lives ("जान") and a shared score multiplier.
- Potholes and barricades can be jumped. Buffaloes and hay carts need a lane change.
- Coins raise the multiplier. A crash resets it and costs a life.
- A phone that drops becomes a harmless ghost for about 15 seconds so it can reconnect.

## Where things are

- `scripts/main.gd` game rules, world, HUD
- `scripts/art.gd` all low-poly props and the outline/curve materials
- `scripts/commentary.gd` the Hindi jokes. Add more lines here.
- `scripts/phone_server.gd`, `scripts/controller_page.gd` phone connection and the controller page
- `shaders/` toon + outline + curved-world shaders

## Notes

- The package name is `com.example.bicyclerush`. Change it in `export_presets.cfg`
  before any Play Store upload and switch to a release keystore.
- The workflow installs Noto Sans Devanagari as `fonts/hindi.ttf` so Hindi text renders.
- No sound yet. Next steps: audio, race mode, QR code in the lobby, more jokes.
