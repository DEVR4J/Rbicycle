shader_type spatial;
render_mode specular_disabled;

// Flat-colour material with a "small planet" curve: everything beyond START
// metres from the camera sinks away, which hides pop-in and gives the
// Messenger-style rolling-world look.

uniform vec4 albedo : source_color = vec4(1.0);

const float CURVE = 0.0016;
const float START = 12.0;

void vertex() {
	vec4 v = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	ALBEDO = albedo.rgb;
	ROUGHNESS = 1.0;
}
