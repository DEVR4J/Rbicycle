shader_type spatial;
render_mode unshaded, cull_front;

// Inverted-hull outline. The mesh is scaled about its centre so every face
// moves out by exactly line_width (no gaps at box corners). half_size is the
// mesh's half extent and is set per mesh from script.

uniform vec4 line_color : source_color = vec4(0.17, 0.11, 0.08, 1.0);
uniform vec3 half_size = vec3(1.0);
uniform float line_width = 0.05;

const float CURVE = 0.0016;
const float START = 12.0;

void vertex() {
	vec3 p = VERTEX * (half_size + vec3(line_width)) / half_size;
	vec4 v = MODELVIEW_MATRIX * vec4(p, 1.0);
	float d = max(0.0, -v.z - START);
	v.y -= d * d * CURVE;
	POSITION = PROJECTION_MATRIX * v;
}

void fragment() {
	ALBEDO = line_color.rgb;
}
