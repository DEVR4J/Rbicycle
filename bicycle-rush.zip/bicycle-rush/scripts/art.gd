extends RefCounted
## Procedural low-poly art: every prop is built from a few primitives with a
## flat toon material plus an inverted-hull outline. No external assets.

const TOON := preload("res://shaders/toon.gdshader")
const OUTLINE := preload("res://shaders/outline.gdshader")

static var font: Font = null
static var _mats: Dictionary = {}
static var _omats: Dictionary = {}
static var _meshes: Dictionary = {}

# Palette (muted, warm, a bit "indie")
const C_TYRE := Color("#3A332E")
const C_HUB := Color("#CFC7B8")
const C_SEAT := Color("#4A3B30")
const C_JEANS := Color("#35567F")
const C_HAIR := Color("#2A1F18")
const C_POTHOLE := Color("#6B4A2E")
const C_WATER := Color("#8BBBD9")
const C_BLUE := Color("#3F6FB5")
const C_YELLOW := Color("#F2C14E")
const C_CONE := Color("#EE7B2B")
const C_BUFFALO := Color("#51565E")
const C_BUFFALO_D := Color("#3C4047")
const C_HORN := Color("#E6DCC4")
const C_WOOD := Color("#8A5A2B")
const C_HAY := Color("#E3C15A")
const C_GOLD := Color("#F2B824")
const C_GOLD_L := Color("#FBDA6B")
const C_DASH := Color("#F1E2C0")
const C_TRUNK := Color("#6E4B2F")
const C_LEAF_A := Color("#4E7F3B")
const C_LEAF_B := Color("#6C9A48")
const C_WALL := Color("#E0A458")
const C_WALL_B := Color("#E58AA8")
const C_ROOF := Color("#B5532F")
const C_DOOR := Color("#5A3B24")
const C_TEMPLE := Color("#D98BA0")
const C_SAFFRON := Color("#E8913A")
const C_TEAL := Color("#2E9AA0")
const C_RED := Color("#C0392B")


# ---------- materials and meshes ----------

static func mat(c: Color) -> ShaderMaterial:
	var key := c.to_html()
	if _mats.has(key):
		return _mats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = TOON
	m.set_shader_parameter("albedo", c)
	_mats[key] = m
	return m


static func outline_mat(mesh: Mesh, lw: float) -> ShaderMaterial:
	var hs: Vector3 = mesh.get_aabb().size * 0.5
	var key := "%.3f,%.3f,%.3f,%.3f" % [hs.x, hs.y, hs.z, lw]
	if _omats.has(key):
		return _omats[key] as ShaderMaterial
	var m := ShaderMaterial.new()
	m.shader = OUTLINE
	m.set_shader_parameter("half_size", Vector3(maxf(hs.x, 0.01), maxf(hs.y, 0.01), maxf(hs.z, 0.01)))
	m.set_shader_parameter("line_width", lw)
	_omats[key] = m
	return m


static func box(s: Vector3) -> Mesh:
	var k := "b%s" % str(s)
	if not _meshes.has(k):
		var m := BoxMesh.new()
		m.size = s
		_meshes[k] = m
	return _meshes[k] as Mesh


static func cyl(rt: float, rb: float, h: float, seg: int = 10) -> Mesh:
	var k := "c%.3f_%.3f_%.3f_%d" % [rt, rb, h, seg]
	if not _meshes.has(k):
		var m := CylinderMesh.new()
		m.top_radius = rt
		m.bottom_radius = rb
		m.height = h
		m.radial_segments = seg
		m.rings = 1
		_meshes[k] = m
	return _meshes[k] as Mesh


static func ball(r: float, seg: int = 8) -> Mesh:
	var k := "s%.3f_%d" % [r, seg]
	if not _meshes.has(k):
		var m := SphereMesh.new()
		m.radius = r
		m.height = r * 2.0
		m.radial_segments = seg
		m.rings = maxi(seg / 2, 3)
		_meshes[k] = m
	return _meshes[k] as Mesh


static func prism(s: Vector3) -> Mesh:
	var k := "p%s" % str(s)
	if not _meshes.has(k):
		var m := PrismMesh.new()
		m.size = s
		m.left_to_right = 0.5
		_meshes[k] = m
	return _meshes[k] as Mesh


static func part(parent: Node3D, mesh: Mesh, color: Color, pos: Vector3 = Vector3.ZERO, rot: Vector3 = Vector3.ZERO, outline: bool = true, lw: float = 0.05) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat(color)
	mi.position = pos
	mi.rotation_degrees = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	if outline:
		var o := MeshInstance3D.new()
		o.mesh = mesh
		o.material_override = outline_mat(mesh, lw)
		o.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.add_child(o)
	return mi


static func sign_label(text: String, pos: Vector3, px: float, col: Color) -> Label3D:
	var lb := Label3D.new()
	lb.name = "sign"
	lb.text = text
	if font != null:
		lb.font = font
	lb.font_size = 64
	lb.pixel_size = px
	lb.modulate = col
	lb.outline_size = 0
	lb.position = pos
	lb.visible = false
	return lb


# ---------- riders ----------

static func make_bike(shirt: Color, band: Color, skin: Color, wheels: Array) -> Node3D:
	var n := Node3D.new()
	for zz in [-0.85, 0.85]:
		var w := Node3D.new()
		w.position = Vector3(0.0, 0.45, float(zz))
		n.add_child(w)
		part(w, cyl(0.45, 0.45, 0.12, 12), C_TYRE, Vector3.ZERO, Vector3(0, 0, 90), true, 0.04)
		part(w, box(Vector3(0.16, 0.78, 0.05)), C_HUB, Vector3.ZERO, Vector3.ZERO, false)
		wheels.append(w)
	part(n, box(Vector3(0.1, 0.1, 1.7)), shirt, Vector3(0, 0.85, 0))
	part(n, box(Vector3(0.1, 0.95, 0.1)), shirt, Vector3(0, 0.9, -0.85), Vector3(-18, 0, 0))
	part(n, box(Vector3(0.95, 0.08, 0.08)), C_SEAT, Vector3(0, 1.38, -0.78))
	part(n, box(Vector3(0.3, 0.08, 0.42)), C_SEAT, Vector3(0, 1.12, 0.4))
	part(n, box(Vector3(0.2, 0.75, 0.22)), C_JEANS, Vector3(-0.18, 1.2, 0.2), Vector3(-20, 0, 0))
	part(n, box(Vector3(0.2, 0.75, 0.22)), C_JEANS, Vector3(0.18, 1.2, 0.2), Vector3(-20, 0, 0))
	part(n, box(Vector3(0.62, 0.85, 0.42)), shirt, Vector3(0, 1.85, 0.1))
	part(n, box(Vector3(0.16, 0.16, 0.95)), shirt, Vector3(-0.4, 1.78, -0.38), Vector3(10, 0, 0))
	part(n, box(Vector3(0.16, 0.16, 0.95)), shirt, Vector3(0.4, 1.78, -0.38), Vector3(10, 0, 0))
	part(n, ball(0.3), skin, Vector3(0, 2.5, -0.02))
	part(n, ball(0.32), C_HAIR, Vector3(0, 2.57, 0.08))
	part(n, cyl(0.33, 0.33, 0.1, 10), band, Vector3(0, 2.52, -0.02), Vector3.ZERO, false)
	return n


# ---------- road items ----------

static func make_pothole() -> Node3D:
	var n := Node3D.new()
	part(n, cyl(1.25, 1.25, 0.04, 12), C_POTHOLE, Vector3(0, 0.04, 0), Vector3.ZERO, false)
	part(n, cyl(0.85, 0.85, 0.04, 12), C_WATER, Vector3(0, 0.07, 0), Vector3.ZERO, false)
	return n


static func make_barricade() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(0.14, 1.0, 0.14)), C_HUB, Vector3(-1.1, 0.5, 0))
	part(n, box(Vector3(0.14, 1.0, 0.14)), C_HUB, Vector3(1.1, 0.5, 0))
	part(n, box(Vector3(2.6, 1.0, 0.18)), C_BLUE, Vector3(0, 1.1, 0))
	part(n, box(Vector3(2.62, 0.1, 0.2)), C_YELLOW, Vector3(0, 1.55, 0), Vector3.ZERO, false)
	part(n, box(Vector3(2.62, 0.1, 0.2)), C_YELLOW, Vector3(0, 0.65, 0), Vector3.ZERO, false)
	part(n, cyl(0.02, 0.28, 0.65, 8), C_CONE, Vector3(-1.45, 0.33, 0.3))
	part(n, cyl(0.02, 0.28, 0.65, 8), C_CONE, Vector3(1.45, 0.33, 0.3))
	n.add_child(sign_label("कार्य प्रगति\nपर है", Vector3(0, 1.1, 0.12), 0.0055, Color.WHITE))
	n.set_meta("has_sign", true)
	return n


static func make_buffalo() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(1.2, 1.0, 2.0)), C_BUFFALO, Vector3(0, 1.15, 0.2))
	for lx in [-0.4, 0.4]:
		for lz in [-0.55, 0.85]:
			part(n, box(Vector3(0.25, 0.7, 0.25)), C_BUFFALO_D, Vector3(float(lx), 0.4, float(lz)), Vector3.ZERO, false)
	part(n, box(Vector3(0.75, 0.75, 0.85)), C_BUFFALO_D, Vector3(0, 1.5, -1.2))
	part(n, box(Vector3(0.5, 0.4, 0.3)), C_BUFFALO, Vector3(0, 1.25, -1.7), Vector3.ZERO, false)
	part(n, box(Vector3(0.6, 0.1, 0.1)), C_HORN, Vector3(-0.5, 1.95, -1.1), Vector3(0, 0, 28), false)
	part(n, box(Vector3(0.6, 0.1, 0.1)), C_HORN, Vector3(0.5, 1.95, -1.1), Vector3(0, 0, -28), false)
	part(n, box(Vector3(0.1, 0.1, 0.7)), C_BUFFALO_D, Vector3(0, 1.4, 1.3), Vector3(25, 0, 0), false)
	return n


static func make_cart() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(2.2, 0.3, 3.0)), C_WOOD, Vector3(0, 0.95, 0.2))
	part(n, box(Vector3(2.0, 1.2, 2.6)), C_HAY, Vector3(0, 1.7, 0.2))
	for sx in [-1.15, 1.15]:
		part(n, cyl(0.6, 0.6, 0.15, 10), C_TYRE, Vector3(float(sx), 0.6, 0.4), Vector3(0, 0, 90))
	part(n, box(Vector3(0.12, 0.12, 1.9)), C_WOOD, Vector3(-0.7, 0.85, -2.1), Vector3.ZERO, false)
	part(n, box(Vector3(0.12, 0.12, 1.9)), C_WOOD, Vector3(0.7, 0.85, -2.1), Vector3.ZERO, false)
	return n


static func make_coin(y: float = 1.0) -> Node3D:
	var n := Node3D.new()
	n.position.y = y
	part(n, cyl(0.42, 0.42, 0.1, 12), C_GOLD, Vector3.ZERO, Vector3(90, 0, 0), true, 0.04)
	part(n, cyl(0.28, 0.28, 0.13, 12), C_GOLD_L, Vector3.ZERO, Vector3(90, 0, 0), false)
	return n


static func make_dash() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(0.18, 0.03, 2.2)), C_DASH, Vector3(0, 0.05, 0), Vector3.ZERO, false)
	return n


# ---------- village scenery ----------

static func make_tree() -> Node3D:
	var n := Node3D.new()
	part(n, cyl(0.3, 0.45, 2.6, 7), C_TRUNK, Vector3(0, 1.3, 0), Vector3.ZERO, true, 0.06)
	part(n, ball(1.6), C_LEAF_A, Vector3(0, 3.7, 0), Vector3.ZERO, true, 0.08)
	part(n, ball(1.1), C_LEAF_B, Vector3(1.0, 3.1, 0.4), Vector3.ZERO, true, 0.08)
	part(n, ball(1.2), C_LEAF_B, Vector3(-1.0, 3.3, -0.3), Vector3.ZERO, true, 0.08)
	return n


static func make_banyan() -> Node3D:
	var n := Node3D.new()
	part(n, cyl(0.7, 0.95, 3.6, 8), C_TRUNK, Vector3(0, 1.8, 0), Vector3.ZERO, true, 0.08)
	part(n, ball(2.8), C_LEAF_A, Vector3(0, 5.3, 0), Vector3.ZERO, true, 0.1)
	part(n, ball(2.0), C_LEAF_B, Vector3(2.2, 4.6, 0.3), Vector3.ZERO, true, 0.1)
	part(n, ball(2.2), C_LEAF_B, Vector3(-2.2, 4.8, -0.2), Vector3.ZERO, true, 0.1)
	for rx in [-1.6, -0.5, 1.2, 2.1]:
		part(n, cyl(0.06, 0.06, 3.0, 5), C_TRUNK, Vector3(float(rx), 2.9, 1.2), Vector3.ZERO, false)
	return n


static func make_hut() -> Node3D:
	var n := Node3D.new()
	var wall: Color = C_WALL if randf() < 0.6 else C_WALL_B
	part(n, box(Vector3(4.0, 2.4, 4.0)), wall, Vector3(0, 1.2, 0))
	part(n, prism(Vector3(5.0, 1.6, 5.0)), C_ROOF, Vector3(0, 3.2, 0))
	part(n, box(Vector3(0.9, 1.6, 0.1)), C_DOOR, Vector3(0, 0.8, 2.03), Vector3.ZERO, false)
	return n


static func make_temple() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(3.2, 2.0, 3.2)), C_TEMPLE, Vector3(0, 1.0, 0))
	part(n, cyl(0.0, 1.9, 2.8, 8), C_SAFFRON, Vector3(0, 3.4, 0))
	part(n, ball(0.28), C_GOLD, Vector3(0, 5.0, 0), Vector3.ZERO, true, 0.04)
	part(n, box(Vector3(0.9, 1.4, 0.1)), C_DOOR, Vector3(0, 0.7, 1.63), Vector3.ZERO, false)
	return n


static func make_pole() -> Node3D:
	var n := Node3D.new()
	part(n, cyl(0.12, 0.17, 6.0, 6), C_TRUNK, Vector3(0, 3.0, 0))
	part(n, box(Vector3(2.0, 0.12, 0.12)), C_TRUNK, Vector3(0, 5.6, 0), Vector3.ZERO, false)
	return n


static func make_chai() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(4.2, 2.6, 2.4)), C_TEAL, Vector3(0, 1.3, -0.6))
	part(n, box(Vector3(4.8, 0.2, 3.4)), C_BLUE, Vector3(0, 2.85, 0.0), Vector3(8, 0, 0))
	part(n, box(Vector3(3.8, 0.9, 0.8)), C_WOOD, Vector3(0, 0.45, 1.0))
	part(n, box(Vector3(0.14, 3.4, 0.14)), C_TRUNK, Vector3(-1.8, 1.7, 1.2), Vector3.ZERO, false)
	part(n, box(Vector3(0.14, 3.4, 0.14)), C_TRUNK, Vector3(1.8, 1.7, 1.2), Vector3.ZERO, false)
	part(n, box(Vector3(3.2, 0.9, 0.18)), C_WOOD, Vector3(0, 3.5, 1.2))
	n.add_child(sign_label("चाय की दुकान", Vector3(0, 3.5, 1.32), 0.0055, Color("#FFF3D6")))
	n.set_meta("has_sign", true)
	return n


static func make_tractor() -> Node3D:
	var n := Node3D.new()
	part(n, box(Vector3(1.6, 1.1, 2.6)), C_RED, Vector3(0, 1.3, 0))
	part(n, box(Vector3(1.3, 1.1, 1.2)), C_RED, Vector3(0, 2.4, 0.7))
	part(n, cyl(0.1, 0.1, 0.9, 6), C_TYRE, Vector3(0.4, 2.2, -0.9), Vector3.ZERO, false)
	for sx in [-1.05, 1.05]:
		part(n, cyl(0.95, 0.95, 0.5, 10), C_TYRE, Vector3(float(sx), 0.95, 0.9), Vector3(0, 0, 90))
		part(n, cyl(0.55, 0.55, 0.4, 10), C_TYRE, Vector3(float(sx) * 0.9, 0.55, -1.0), Vector3(0, 0, 90))
	return n
