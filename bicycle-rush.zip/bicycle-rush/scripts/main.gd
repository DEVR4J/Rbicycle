extends Node3D
## Bicycle Rush: two riders on one shared road, controlled from phones.
## Everything (world, HUD, game rules) is built from code in this file.

const Art := preload("res://scripts/art.gd")
const PhoneServer := preload("res://scripts/phone_server.gd")
const Commentary := preload("res://scripts/commentary.gd")

const LANES := [-4.5, -1.5, 1.5, 4.5]
const SPAWN_Z := -80.0
const DESPAWN_Z := 16.0
const START_SPEED := 14.0
const MAX_SPEED := 30.0
const LOBBY_SPEED := 6.0
const GRAVITY := 26.0
const JUMP_V := 9.5
const START_LIVES := 3
const CAM_POS := Vector3(0.0, 5.6, 10.5)
const CAM_TARGET := Vector3(0.0, 1.0, -8.0)

const SKY := Color("#EFD7A8")
const GRASS := Color("#8DA65A")
const ROAD := Color("#C99A66")
const INK := Color("#2B1B14")
const CREAM := Color("#FFF3D6")

# hw / hz = half width / half length of the hit box, h = height (jump clears it if taller)
const OBST := {
	"pothole": {"hw": 1.0, "hz": 1.0, "h": 0.12},
	"barricade": {"hw": 1.3, "hz": 0.4, "h": 1.3},
	"buffalo": {"hw": 0.8, "hz": 1.2, "h": 2.2},
	"cart": {"hw": 1.1, "hz": 1.6, "h": 2.6},
}
const OBST_KINDS := ["pothole", "barricade", "buffalo", "cart"]

enum State { LOBBY, PLAYING, GAMEOVER }


class Rider:
	var idx := 0
	var node: Node3D
	var wheels: Array = []
	var lane := 0
	var y := 0.0
	var vy := 0.0
	var stun := 0.0
	var coins := 0
	var crashes := 0
	var connected := false
	var joined := false
	var taunt_cd := 0.0


var state: int = State.LOBBY
var speed := LOBBY_SPEED
var target_speed := LOBBY_SPEED
var world_dist := 0.0
var play_time := 0.0
var score_f := 0.0
var coins_total := 0
var multiplier := 1
var lives := START_LIVES
var next_row := 0.0
var next_scenery := 0.0
var next_dash := 0.0
var last_crash_time := -10.0
var lead_cd := 0.0
var speech_cd := 0.0
var speech_t := 0.0
var over_t := 0.0
var shake := 0.0
var time_now := 0.0
var hud_t := 0.0

var riders: Array = []
var movers: Array = []
var cam: Camera3D
var server: Node
var cmt: RefCounted = Commentary.new()
var font: Font

var hud_root: Control
var lbl_coins: Label
var lbl_score: Label
var lbl_lives: Label
var lbl_mult: Label
var speech_panel: Panel
var lbl_speech: Label
var overlay: Control
var lbl_over_title: Label
var lbl_over: Label


func _ready() -> void:
	randomize()
	font = _load_font()
	Art.font = font
	_build_environment()
	_build_ground()
	_build_riders()
	_build_hud()
	server = PhoneServer.new()
	add_child(server)
	server.player_message.connect(_on_player_message)
	server.slot_changed.connect(_on_slot_changed)
	if not server.start():
		push_warning("Phone server could not start. Phones will not be able to join.")
	var z := SPAWN_Z
	while z < 12.0:
		_spawn_scenery(z)
		z += 7.0
	z = SPAWN_Z
	while z < 12.0:
		_spawn_dash(z)
		z += 6.0
	_refresh_overlay()


# ---------------------------------------------------------------- setup

func _load_font() -> Font:
	var base: Font = ThemeDB.fallback_font
	if ResourceLoader.exists("res://fonts/hindi.ttf"):
		var f := load("res://fonts/hindi.ttf") as Font
		if f != null:
			var fv := FontVariation.new()
			fv.base_font = f
			fv.fallbacks = [base]
			return fv
	push_warning("res://fonts/hindi.ttf is missing, so Hindi text will not render.")
	return base


func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#FFF1D6")
	env.ambient_light_energy = 0.75
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -32.0, 0.0)
	sun.light_energy = 0.9
	sun.shadow_enabled = false
	add_child(sun)
	cam = Camera3D.new()
	cam.fov = 62.0
	add_child(cam)
	cam.look_at_from_position(CAM_POS, CAM_TARGET, Vector3.UP)


func _build_ground() -> void:
	var g := PlaneMesh.new()
	g.size = Vector2(90.0, 240.0)
	g.subdivide_width = 4
	g.subdivide_depth = 100
	var gi := MeshInstance3D.new()
	gi.mesh = g
	gi.material_override = Art.mat(GRASS)
	gi.position = Vector3(0.0, 0.0, -105.0)
	add_child(gi)
	var r := PlaneMesh.new()
	r.size = Vector2(13.5, 240.0)
	r.subdivide_width = 1
	r.subdivide_depth = 100
	var ri := MeshInstance3D.new()
	ri.mesh = r
	ri.material_override = Art.mat(ROAD)
	ri.position = Vector3(0.0, 0.02, -105.0)
	add_child(ri)


func _build_riders() -> void:
	var shirts := [Color("#F28C28"), Color("#7B4FC4")]
	var bands := [Color("#D8344B"), Color("#2BA35B")]
	var skins := [Color("#C98B5E"), Color("#B9794F")]
	for i in range(2):
		var r := Rider.new()
		r.idx = i
		r.lane = 1 + i
		r.node = Art.make_bike(shirts[i], bands[i], skins[i], r.wheels)
		r.node.position = Vector3(float(LANES[r.lane]), 0.0, 0.0)
		r.node.visible = false
		add_child(r.node)
		var t := Label3D.new()
		t.text = "P%d" % (i + 1)
		t.font = font
		t.font_size = 96
		t.pixel_size = 0.012
		t.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		t.no_depth_test = true
		t.modulate = shirts[i]
		t.outline_size = 16
		t.outline_modulate = INK
		t.position = Vector3(0.0, 3.4, 0.0)
		r.node.add_child(t)
		riders.append(r)


func _make_label(sz: int, align: int, pos: Vector2, box: Vector2, parent: Control = null) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", CREAM)
	l.add_theme_color_override("font_outline_color", INK)
	l.add_theme_constant_override("outline_size", 10)
	l.horizontal_alignment = align as HorizontalAlignment
	l.position = pos
	l.size = box
	if parent == null:
		hud_root.add_child(l)
	else:
		parent.add_child(l)
	return l


func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud_root = Control.new()
	layer.add_child(hud_root)

	lbl_coins = _make_label(46, HORIZONTAL_ALIGNMENT_LEFT, Vector2(64, 40), Vector2(520, 64))
	lbl_lives = _make_label(40, HORIZONTAL_ALIGNMENT_LEFT, Vector2(64, 104), Vector2(520, 60))
	lbl_score = _make_label(52, HORIZONTAL_ALIGNMENT_RIGHT, Vector2(1296, 40), Vector2(560, 70))
	lbl_mult = _make_label(40, HORIZONTAL_ALIGNMENT_RIGHT, Vector2(1296, 108), Vector2(560, 60))

	speech_panel = Panel.new()
	speech_panel.position = Vector2(260, 860)
	speech_panel.size = Vector2(1400, 160)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.165, 0.129, 0.094, 0.9)
	sb.set_corner_radius_all(28)
	speech_panel.add_theme_stylebox_override("panel", sb)
	speech_panel.visible = false
	hud_root.add_child(speech_panel)
	lbl_speech = _make_label(42, HORIZONTAL_ALIGNMENT_CENTER, Vector2(30, 10), Vector2(1340, 140), speech_panel)
	lbl_speech.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl_speech.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl_speech.add_theme_constant_override("outline_size", 0)
	lbl_speech.add_theme_color_override("font_color", Color("#FFE6A8"))

	overlay = Control.new()
	hud_root.add_child(overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.1, 0.07, 0.05, 0.6)
	dim.position = Vector2.ZERO
	dim.size = Vector2(1920, 1080)
	overlay.add_child(dim)
	lbl_over_title = _make_label(88, HORIZONTAL_ALIGNMENT_CENTER, Vector2(160, 150), Vector2(1600, 120), overlay)
	lbl_over = _make_label(46, HORIZONTAL_ALIGNMENT_CENTER, Vector2(160, 310), Vector2(1600, 660), overlay)
	lbl_over.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_update_hud()


# ---------------------------------------------------------------- input

func _unhandled_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k != null and k.pressed and not k.echo:
		match k.keycode:
			KEY_A:
				_local_input(1, "l")
			KEY_D:
				_local_input(1, "r")
			KEY_W:
				_local_input(1, "u")
			KEY_S:
				_local_input(1, "d")
	if event.is_action_pressed("ui_left"):
		_local_input(0, "l")
	elif event.is_action_pressed("ui_right"):
		_local_input(0, "r")
	elif event.is_action_pressed("ui_up"):
		_local_input(0, "u")
	elif event.is_action_pressed("ui_down"):
		_local_input(0, "d")
	elif event.is_action_pressed("ui_accept"):
		_try_start(true)


func _local_input(i: int, d: String) -> void:
	var r: Rider = riders[i]
	if not r.joined:
		r.joined = true
		r.connected = true
		r.node.visible = true
		_refresh_overlay()
	_apply_input(r, d)


func _on_player_message(slot: int, msg: Dictionary) -> void:
	var t: String = str(msg.get("t", ""))
	if t == "swipe":
		_apply_input(riders[slot], str(msg.get("d", "")))
	elif t == "taunt":
		_taunt(slot)
	elif t == "start":
		_try_start(false)


func _on_slot_changed(slot: int, online: bool) -> void:
	var r: Rider = riders[slot]
	r.connected = online
	if online:
		r.joined = true
		r.node.visible = true
		say("join", [slot + 1])
	_refresh_overlay()


func _apply_input(r: Rider, d: String) -> void:
	if state == State.GAMEOVER:
		return
	match d:
		"l":
			r.lane = maxi(0, r.lane - 1)
		"r":
			r.lane = mini(3, r.lane + 1)
		"u":
			if r.y <= 0.001 and r.vy == 0.0:
				r.vy = JUMP_V
		"d":
			if r.y > 0.0:
				r.vy = minf(r.vy, -14.0)


func _taunt(slot: int) -> void:
	var r: Rider = riders[slot]
	if r.taunt_cd > 0.0:
		return
	r.taunt_cd = 6.0
	var target: int = 1 - slot
	var line: String = cmt.pick("taunt") % [target + 1]
	_show_speech(line)
	speech_cd = 4.0
	server.send_to(target, {"t": "msg", "text": line})
	server.send_to(target, {"t": "vibe", "ms": 120})


func _try_start(from_tv: bool) -> void:
	if state == State.LOBBY:
		var any := false
		for r in riders:
			if r.joined:
				any = true
		if not any:
			if from_tv:
				_local_input(0, "")
			else:
				return
		_start_game()
	elif state == State.GAMEOVER and over_t <= 0.0:
		_start_game()


# ---------------------------------------------------------------- game flow

func _start_game() -> void:
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		var kind: String = str(n.get_meta("kind", ""))
		if kind == "obstacle" or kind == "coin":
			movers.remove_at(i)
			n.queue_free()
	state = State.PLAYING
	lives = START_LIVES
	multiplier = 1
	coins_total = 0
	score_f = 0.0
	play_time = 0.0
	speed = START_SPEED
	target_speed = START_SPEED
	lead_cd = 20.0
	next_row = world_dist + 40.0
	for r in riders:
		r.coins = 0
		r.crashes = 0
		r.stun = 0.0
		r.y = 0.0
		r.vy = 0.0
		r.node.visible = r.joined
	overlay.visible = false
	say("start", [], true)
	_update_hud()


func _game_over() -> void:
	state = State.GAMEOVER
	over_t = 2.5
	say("over", [], true)
	_refresh_overlay()


func _crash(r: Rider, otype: String) -> void:
	r.stun = 1.4
	r.crashes += 1
	lives -= 1
	multiplier = 1
	shake = 0.6
	speed = maxf(speed * 0.6, START_SPEED * 0.7)
	server.send_to(r.idx, {"t": "vibe", "ms": 350})
	var both: bool = time_now - last_crash_time < 2.5
	last_crash_time = time_now
	if lives <= 0:
		_game_over()
		return
	if both:
		say("both", [], true)
	else:
		say(otype, [], true)
	_update_hud()


func _collect(r: Rider, i: int, n: Node3D) -> void:
	movers.remove_at(i)
	n.queue_free()
	r.coins += 1
	coins_total += 1
	score_f += 10.0 * float(multiplier)
	if coins_total % 8 == 0:
		multiplier = mini(12, multiplier + 1)
	server.send_to(r.idx, {"t": "vibe", "ms": 15})
	if coins_total % 25 == 0:
		say("coins")
	_check_lead()


func _check_lead() -> void:
	if lead_cd > 0.0:
		return
	var a: Rider = riders[0]
	var b: Rider = riders[1]
	if not (a.joined and b.joined):
		return
	var diff: int = a.coins - b.coins
	if absi(diff) < 8:
		return
	var lead: int = 0 if diff > 0 else 1
	lead_cd = 25.0
	if randf() < 0.5:
		say("lead", [lead + 1, 2 - lead], true)
	else:
		say("lag", [2 - lead], true)
	server.send_to(1 - lead, {"t": "vibe", "ms": 80})


# ---------------------------------------------------------------- per-frame

func _process(delta: float) -> void:
	time_now += delta
	speech_cd = maxf(0.0, speech_cd - delta)
	lead_cd = maxf(0.0, lead_cd - delta)
	for r in riders:
		r.taunt_cd = maxf(0.0, r.taunt_cd - delta)
	if speech_t > 0.0:
		speech_t -= delta
		if speech_t <= 0.0:
			speech_panel.visible = false
	match state:
		State.LOBBY:
			speed = move_toward(speed, LOBBY_SPEED, 8.0 * delta)
			_move_world(delta)
			_update_riders(delta, false)
		State.PLAYING:
			play_time += delta
			target_speed = minf(MAX_SPEED, START_SPEED + play_time * 0.12)
			speed = move_toward(speed, target_speed, 8.0 * delta)
			_move_world(delta)
			score_f += speed * delta * float(multiplier) * 0.5
			_spawn_play_rows()
			_update_riders(delta, true)
		State.GAMEOVER:
			over_t -= delta
			speed = move_toward(speed, 0.0, 18.0 * delta)
			_move_world(delta)
			_update_riders(delta, false)
	_update_camera(delta)
	hud_t += delta
	if hud_t > 0.1:
		hud_t = 0.0
		_update_hud()


func _update_camera(_delta: float) -> void:
	var off := Vector3.ZERO
	if shake > 0.0:
		shake = maxf(0.0, shake - _delta * 1.6)
		off = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * shake * 0.25
	var cx := 0.0
	var count := 0
	for r in riders:
		if r.joined:
			cx += r.node.position.x
			count += 1
	if count > 0:
		cx = cx / float(count) * 0.15
	cam.look_at_from_position(CAM_POS + Vector3(cx, 0.0, 0.0) + off, CAM_TARGET + Vector3(cx * 0.5, 0.0, 0.0), Vector3.UP)


func _move_world(delta: float) -> void:
	var dz: float = speed * delta
	world_dist += dz
	while world_dist >= next_scenery:
		next_scenery += 7.0 + randf() * 4.0
		_spawn_scenery(SPAWN_Z)
	while world_dist >= next_dash:
		next_dash += 6.0
		_spawn_dash(SPAWN_Z)
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		if not is_instance_valid(n):
			movers.remove_at(i)
			continue
		n.position.z += dz
		if n.position.z > DESPAWN_Z:
			movers.remove_at(i)
			n.queue_free()
			continue
		var kind: String = str(n.get_meta("kind", ""))
		if kind == "coin":
			n.rotation.y += 3.0 * delta
		if n.has_meta("has_sign"):
			var s := n.get_node_or_null("sign") as Node3D
			if s != null:
				s.visible = n.position.z > -16.0


func _update_riders(delta: float, collide: bool) -> void:
	for r in riders:
		if not r.joined:
			continue
		var tx: float = LANES[r.lane]
		var x: float = r.node.position.x
		r.node.position.x = lerpf(x, tx, 1.0 - exp(-14.0 * delta))
		if r.y > 0.0 or r.vy > 0.0:
			r.vy -= GRAVITY * delta
			r.y += r.vy * delta
			if r.y <= 0.0:
				r.y = 0.0
				r.vy = 0.0
		r.node.position.y = r.y
		var roll: float = clampf((x - tx) * 0.12, -0.35, 0.35)
		if r.stun > 0.0:
			r.stun -= delta
			roll += sin(time_now * 40.0) * 0.25
			r.node.visible = int(r.stun * 14.0) % 2 == 0
			if r.stun <= 0.0:
				r.node.visible = true
		r.node.rotation.z = roll
		for w in r.wheels:
			w.rotation.x -= speed * delta / 0.45
		if collide:
			_check_collisions(r)


func _check_collisions(r: Rider) -> void:
	if r.stun > 0.0 or not r.connected:
		return
	var rx: float = r.node.position.x
	for i in range(movers.size() - 1, -1, -1):
		var n: Node3D = movers[i]
		var kind: String = str(n.get_meta("kind", ""))
		if kind != "obstacle" and kind != "coin":
			continue
		var dz: float = absf(n.position.z)
		if dz > 3.0:
			continue
		var dx: float = absf(n.position.x - rx)
		if kind == "coin":
			var cy: float = float(n.get_meta("cy", 1.0))
			if dx < 1.1 and dz < 1.2 and absf(cy - (r.y + 1.1)) < 1.3:
				_collect(r, i, n)
		else:
			var spec: Dictionary = OBST[str(n.get_meta("otype"))]
			if dx < float(spec["hw"]) + 0.45 and dz < float(spec["hz"]) + 0.6 and r.y < float(spec["h"]):
				_crash(r, str(n.get_meta("otype")))
				return


# ---------------------------------------------------------------- spawning

func _add_mover(n: Node3D, kind: String, x: float, z: float, otype: String = "") -> void:
	n.position = Vector3(x, n.position.y, z)
	n.set_meta("kind", kind)
	n.set_meta("otype", otype)
	add_child(n)
	movers.append(n)


func _spawn_play_rows() -> void:
	while world_dist >= next_row:
		var gap: float = lerpf(24.0, 15.0, clampf(play_time / 120.0, 0.0, 1.0))
		next_row += gap
		_spawn_row()


func _spawn_row() -> void:
	var lanes := [0, 1, 2, 3]
	lanes.shuffle()
	var r := randf()
	if r < 0.28:
		_spawn_coin_line(lanes[0], 6)
	elif r < 0.55:
		_spawn_obstacle(lanes[0], OBST_KINDS[randi() % 4])
		_spawn_coin_line(lanes[1], 4)
	elif r < 0.85:
		_spawn_obstacle(lanes[0], OBST_KINDS[randi() % 4])
		_spawn_obstacle(lanes[1], OBST_KINDS[randi() % 4])
		_spawn_coin_line(lanes[2], 5)
	else:
		for k in range(3):
			_spawn_obstacle(lanes[k], "barricade" if randf() < 0.5 else "pothole")
		for i in range(5):
			var c := Art.make_coin(1.0 + sin(PI * float(i) / 4.0) * 1.1)
			c.set_meta("cy", c.position.y)
			_add_mover(c, "coin", LANES[lanes[0]], SPAWN_Z - 3.0 + float(i) * 1.5)


func _spawn_obstacle(lane: int, otype: String) -> void:
	var n: Node3D
	match otype:
		"pothole":
			n = Art.make_pothole()
		"barricade":
			n = Art.make_barricade()
		"buffalo":
			n = Art.make_buffalo()
		_:
			n = Art.make_cart()
	_add_mover(n, "obstacle", LANES[lane], SPAWN_Z, otype)


func _spawn_coin_line(lane: int, count: int) -> void:
	for i in range(count):
		var c := Art.make_coin(1.0)
		c.set_meta("cy", 1.0)
		_add_mover(c, "coin", LANES[lane], SPAWN_Z - float(i) * 2.6)


func _spawn_scenery(z: float) -> void:
	for pass_i in range(2):
		var side: float = 1.0 if randf() < 0.5 else -1.0
		var r := randf()
		var x: float = side * randf_range(9.5, 17.0)
		var n: Node3D
		var turn := true
		if r < 0.30:
			n = Art.make_tree()
			turn = false
		elif r < 0.38:
			n = Art.make_banyan()
			x = side * randf_range(12.0, 17.0)
			turn = false
		elif r < 0.55:
			n = Art.make_hut()
		elif r < 0.68:
			n = Art.make_pole()
			x = side * 8.0
			turn = false
		elif r < 0.76:
			n = Art.make_temple()
		elif r < 0.86:
			n = Art.make_chai()
		else:
			n = Art.make_tractor()
		if turn:
			n.rotation_degrees.y = -45.0 * side + randf_range(-8.0, 8.0)
		_add_mover(n, "scenery", x, z - float(pass_i) * 3.5)


func _spawn_dash(z: float) -> void:
	for x in [-3.0, 0.0, 3.0]:
		_add_mover(Art.make_dash(), "dash", float(x), z)


# ---------------------------------------------------------------- HUD

func say(event: String, args: Array = [], force: bool = false) -> void:
	if not force and speech_cd > 0.0:
		return
	var s: String = cmt.pick(event)
	if s == "":
		return
	if args.size() > 0:
		s = s % args
	_show_speech(s)
	speech_cd = 4.5


func _show_speech(text: String) -> void:
	lbl_speech.text = text
	speech_panel.visible = true
	speech_t = 3.8


func _update_hud() -> void:
	lbl_coins.text = "₹ %d" % coins_total
	lbl_lives.text = "जान: %d" % maxi(lives, 0)
	lbl_score.text = "Score %d" % int(score_f)
	lbl_mult.text = "x%d" % multiplier
	var show_hud: bool = state != State.LOBBY
	lbl_coins.visible = show_hud
	lbl_lives.visible = show_hud
	lbl_score.visible = show_hud
	lbl_mult.visible = show_hud


func _slot_text(i: int) -> String:
	var r: Rider = riders[i]
	var st: String = "जुड़ गया" if r.joined else "इंतज़ार..."
	return "खिलाड़ी %d: %s" % [i + 1, st]


func _roast_text() -> String:
	var a: Rider = riders[0]
	var b: Rider = riders[1]
	if not (a.joined and b.joined):
		return "अकेले भी क्या खेलना! अगली बार दोस्त को बुलाओ।"
	var lines: Array = []
	if a.crashes == b.crashes:
		lines.append("दोनों ने %d-%d बार साइकिल ठोकी। बराबरी की टक्कर!" % [a.crashes, b.crashes])
	else:
		var worst: Rider = a if a.crashes > b.crashes else b
		lines.append("खिलाड़ी %d ने %d बार साइकिल ठोकी। बीमा वाले हाथ जोड़ रहे हैं।" % [worst.idx + 1, worst.crashes])
	if a.coins != b.coins:
		var rich: Rider = a if a.coins > b.coins else b
		lines.append("सिक्कों में खिलाड़ी %d आगे: %d-%d" % [rich.idx + 1, a.coins, b.coins])
	return "\n".join(lines)


func _refresh_overlay() -> void:
	if overlay == null:
		return
	match state:
		State.LOBBY:
			overlay.visible = true
			lbl_over_title.text = "Bicycle Rush  |  साइकिल रश"
			lbl_over.text = "फ़ोन के ब्राउज़र में खोलो (वही वाई-फ़ाई):\n%s\n\n%s\n%s\n\nफ़ोन पर \"शुरू\" दबाओ, या रिमोट का OK बटन" % [server.url, _slot_text(0), _slot_text(1)]
		State.GAMEOVER:
			overlay.visible = true
			lbl_over_title.text = "खेल ख़त्म!"
			lbl_over.text = "स्कोर: %d     सिक्के: %d\n\n%s\n\nफिर से खेलने के लिए \"शुरू\" या OK" % [int(score_f), coins_total, _roast_text()]
		_:
			overlay.visible = false
